// 社交（社区）学员端接口，挂载 /api/community。
// v1：帖子 / 评论 / 点赞 / 举报 / 概览；v2：广场五流、瞬间（24h）、匿名树洞、收藏、楼中楼，
// 以及通知与成长积分联动（通知/积分失败不影响主流程）。
// 纯文本 UGC：服务端校验、参数化 SQL、软删除、进程内频率限制。
const express = require('express');
const router = express.Router();
const db = require('../db');
const filter = require('../lib/community-filter');
const growth = require('../lib/community-growth');
const notify = require('../lib/community-notify');
const { currentStudent, requireStudentApi } = require('../middleware/student-auth');

const PAGE_SIZE_DEFAULT = 10;
const PAGE_SIZE_MAX = 20;
const COMMENT_PAGE_SIZE_DEFAULT = 20;
const COMMENT_PAGE_SIZE_MAX = 50;
const REPLY_PREVIEW_COUNT = 3;
const REPLY_ALL_COUNT = 50;
const ANONYMOUS_NAME = '匿名同学';

const FEED_TABS = ['recommend', 'following', 'peer', 'treehole', 'hot'];
const POST_KINDS = ['post', 'moment', 'checkin'];

// 频率限制：进程内滑动窗口（单实例足够；每次写前顺带回收过期键）。
// moment 单独计数：瞬间更轻量，允许比帖子略高频，但同样防刷。
const RATE_LIMITS = {
  post: { max: 5, windowMs: 10 * 60 * 1000 },
  moment: { max: 12, windowMs: 10 * 60 * 1000 },
  comment: { max: 15, windowMs: 10 * 60 * 1000 },
  report: { max: 10, windowMs: 10 * 60 * 1000 }
};
const rateBuckets = new Map();

router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

function fail(res, status, error) {
  return res.status(status).json({ ok: false, error });
}

function intParam(raw, fallback, min, max) {
  const n = parseInt(raw, 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function positiveId(raw) {
  const text = String(raw == null ? '' : raw);
  if (!/^[1-9]\d*$/.test(text)) return null;
  const n = Number(text);
  return Number.isSafeInteger(n) ? n : null;
}

function allowRate(action, sid) {
  const rule = RATE_LIMITS[action];
  const now = Date.now();
  // 清理所有过期桶，避免 Map 无界增长
  for (const [key, times] of rateBuckets) {
    const actionName = key.slice(0, key.indexOf(':'));
    const windowMs = RATE_LIMITS[actionName] ? RATE_LIMITS[actionName].windowMs : rule.windowMs;
    const alive = times.filter(t => now - t < windowMs);
    if (alive.length) rateBuckets.set(key, alive);
    else rateBuckets.delete(key);
  }
  const key = action + ':' + sid;
  const times = rateBuckets.get(key) || [];
  if (times.length >= rule.max) return false;
  times.push(now);
  rateBuckets.set(key, times);
  return true;
}

// 辅助动作（通知 / 积分）失败不影响主流程。
function safe(fn) {
  try {
    return fn();
  } catch (e) {
    console.error('[community]', e && e.message);
    return null;
  }
}

// ── 数据库能力探测：v1 库（仅 009 迁移）也要能跑，v2 字段/表缺失时自动降级。 ──
let schemaCache = null;
function tableColumns(table) {
  try {
    return db.query('SELECT name FROM pragma_table_info(?)', [table]).map(row => String(row.name));
  } catch (e) {
    return [];
  }
}
function tableNames() {
  try {
    return db.query("SELECT name FROM sqlite_master WHERE type='table'").map(row => String(row.name));
  } catch (e) {
    return [];
  }
}
function schema() {
  if (schemaCache) return schemaCache;
  const postColumns = tableColumns('community_posts');
  const commentColumns = tableColumns('community_comments');
  const studentColumns = tableColumns('students');
  const tables = tableNames();
  const hasTable = name => tables.indexOf(name) !== -1;
  const flags = {
    postsV2: ['kind', 'is_anonymous', 'expires_at', 'favorite_count'].every(name => postColumns.indexOf(name) !== -1),
    commentsV2: commentColumns.indexOf('parent_id') !== -1,
    studentProfile: studentColumns.indexOf('province_code') !== -1 && studentColumns.indexOf('exam_year') !== -1,
    follows: hasTable('community_follows'),
    favorites: hasTable('community_favorites'),
    notifications: hasTable('community_notifications'),
    growth: hasTable('student_growth'),
    growthEvents: hasTable('student_growth_events'),
    checkins: hasTable('community_checkins')
  };
  flags.v2 = flags.postsV2 && flags.commentsV2 && flags.favorites && flags.growth;
  schemaCache = flags;
  return flags;
}

function readTags(raw) {
  try {
    const list = JSON.parse(raw || '[]');
    if (!Array.isArray(list)) return [];
    return list.filter(t => typeof t === 'string' && filter.TAGS.includes(t));
  } catch (e) {
    return [];
  }
}

// 标签规范化：数组、白名单、去重、最多 3 个。
function normalizeTags(input) {
  if (input == null) return { ok: true, tags: [] };
  if (!Array.isArray(input)) return { ok: false, error: '标签格式不正确' };
  const tags = [];
  for (const item of input) {
    const tag = typeof item === 'string' ? item.trim() : '';
    if (!filter.TAGS.includes(tag)) return { ok: false, error: '标签不合法' };
    if (!tags.includes(tag)) tags.push(tag);
  }
  if (tags.length > 3) return { ok: false, error: '最多选择 3 个标签' };
  return { ok: true, tags };
}

function parseKind(raw) {
  if (raw == null || raw === '') return { ok: true, kind: 'post' };
  const kind = typeof raw === 'string' ? raw.trim() : '';
  if (kind !== 'post' && kind !== 'moment') return { ok: false, error: '内容类型不合法' };
  return { ok: true, kind };
}

function parseAnonymous(raw) {
  return raw === true || raw === 1 || raw === '1' || raw === 'true';
}

// ── 序列化 ──
function buildPostSelect() {
  const flags = schema();
  let sql = `SELECT p.*, s.name AS s_name, s.nickname AS s_nickname, s.avatar AS s_avatar,
  EXISTS(SELECT 1 FROM community_likes l WHERE l.post_id = p.id AND l.student_id = ?) AS liked`;
  if (flags.favorites) {
    sql += `,
  EXISTS(SELECT 1 FROM community_favorites f WHERE f.post_id = p.id AND f.student_id = ?) AS favorited`;
  }
  if (flags.growth) {
    sql += `,
  COALESCE(g.level, 1) AS author_level`;
  }
  sql += `
  FROM community_posts p LEFT JOIN students s ON s.id = p.student_id`;
  if (flags.growth) {
    sql += ` LEFT JOIN student_growth g ON g.student_id = p.student_id`;
  }
  return sql;
}

function postSelectParams(viewerId) {
  const flags = schema();
  const params = [viewerId || 0];
  if (flags.favorites) params.push(viewerId || 0);
  return params;
}

function mapPost(row, viewerId) {
  const anonymous = Number(row.is_anonymous) === 1;
  const authorId = Number(row.student_id) || 0;
  return {
    id: row.id,
    body: row.body,
    tags: readTags(row.tags),
    kind: row.kind || 'post',
    isAnonymous: anonymous,
    likeCount: Number(row.like_count) || 0,
    commentCount: Number(row.comment_count) || 0,
    favoriteCount: Number(row.favorite_count) || 0,
    liked: !!row.liked,
    favorited: !!row.favorited,
    isMine: !!viewerId && authorId === viewerId,
    createdAt: row.created_at,
    expiresAt: row.expires_at || null,
    authorId: anonymous ? 0 : authorId,
    authorName: anonymous ? ANONYMOUS_NAME : filter.displayName({ name: row.s_name, nickname: row.s_nickname }),
    authorAvatar: anonymous ? '' : (row.s_avatar || ''),
    authorLevel: anonymous ? 0 : (Number(row.author_level) || 1)
  };
}

const COMMENT_SELECT = `SELECT c.*, s.name AS s_name, s.nickname AS s_nickname, s.avatar AS s_avatar
  FROM community_comments c LEFT JOIN students s ON s.id = c.student_id`;

function mapCommentBase(row, viewerId, anonymous) {
  return {
    id: row.id,
    body: row.body,
    createdAt: row.created_at,
    authorName: anonymous ? ANONYMOUS_NAME : filter.displayName({ name: row.s_name, nickname: row.s_nickname }),
    authorAvatar: anonymous ? '' : (row.s_avatar || ''),
    isMine: !!viewerId && Number(row.student_id) === viewerId,
    isAnonymous: !!anonymous,
    replyCount: 0,
    replies: []
  };
}

// 帖子是否存在且可见（已发布；瞬间过期视为不存在）。
function findVisiblePost(postId, opts) {
  const flags = schema();
  let where = "id = ? AND status = 'published'";
  if (flags.postsV2 && !(opts && opts.includeExpired)) {
    where += " AND (kind <> 'moment' OR expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP)";
  }
  return db.get('SELECT * FROM community_posts WHERE ' + where, [postId]);
}

function currentViewerProfile(studentId) {
  const flags = schema();
  if (!flags.studentProfile) return null;
  const row = db.get('SELECT province_code, exam_year FROM students WHERE id=?', [studentId]);
  if (!row) return null;
  const province = String(row.province_code == null ? '' : row.province_code).trim();
  const year = String(row.exam_year == null ? '' : row.exam_year).trim();
  if (!province || !year) return null;
  return { province, year };
}

function emptyFeed(req, res, tab, page, pageSize) {
  return res.json({
    ok: true,
    page,
    pageSize,
    total: 0,
    tab,
    tags: filter.TAGS,
    posts: []
  });
}

// ── 帖子列表（v1 兼容） ──
router.get('/posts', (req, res) => {
  const viewer = currentStudent(req);
  const viewerId = viewer ? viewer.id : null;
  const rawTag = typeof req.query.tag === 'string' ? req.query.tag.trim() : '';
  const tag = filter.TAGS.includes(rawTag) ? rawTag : '';
  const page = intParam(req.query.page, 1, 1, 1000000);
  const pageSize = intParam(req.query.pageSize, PAGE_SIZE_DEFAULT, 1, PAGE_SIZE_MAX);

  let where = "p.status = 'published'";
  const params = [];
  if (tag) {
    where += ' AND p.tags LIKE ?';
    params.push('%"' + tag + '"%');
  }
  const totalRow = db.get('SELECT COUNT(*) AS c FROM community_posts p WHERE ' + where, params);
  const rows = db.query(
    buildPostSelect() + ' WHERE ' + where + ' ORDER BY p.created_at DESC, p.id DESC LIMIT ? OFFSET ?',
    postSelectParams(viewerId).concat(params, [pageSize, (page - 1) * pageSize])
  );
  res.json({
    ok: true,
    page,
    pageSize,
    total: Number(totalRow && totalRow.c) || 0,
    tags: filter.TAGS,
    posts: rows.map(row => mapPost(row, viewerId))
  });
});

// ── 广场五流（v2） ──
router.get('/feed', (req, res) => {
  const flags = schema();
  const viewer = currentStudent(req);
  const viewerId = viewer ? viewer.id : null;
  const rawTab = String(req.query.tab == null ? '' : req.query.tab).trim();
  const tab = FEED_TABS.indexOf(rawTab) >= 0 ? rawTab : 'recommend';
  const rawTag = typeof req.query.tag === 'string' ? req.query.tag.trim() : '';
  const tag = filter.TAGS.includes(rawTag) ? rawTag : '';
  const rawKind = String(req.query.kind == null ? '' : req.query.kind).trim();
  const kind = POST_KINDS.indexOf(rawKind) >= 0 ? rawKind : '';
  const page = intParam(req.query.page, 1, 1, 1000000);
  const pageSize = intParam(req.query.pageSize, PAGE_SIZE_DEFAULT, 1, PAGE_SIZE_MAX);

  if (tab === 'following' && !viewer) return fail(res, 401, '请先登录');
  if (tab === 'following' && !flags.follows) return emptyFeed(req, res, tab, page, pageSize);
  if (tab === 'treehole' && !flags.postsV2) return emptyFeed(req, res, tab, page, pageSize);
  if (kind && !flags.postsV2 && kind !== 'post') return emptyFeed(req, res, tab, page, pageSize);

  const viewerProfile = viewer ? currentViewerProfile(viewer.id) : null;
  if (tab === 'peer' && !viewerProfile) return emptyFeed(req, res, tab, page, pageSize);

  let where = "p.status = 'published'";
  const whereParams = [];
  if (tag) {
    where += ' AND p.tags LIKE ?';
    whereParams.push('%"' + tag + '"%');
  }
  if (kind) {
    if (flags.postsV2) {
      where += ' AND p.kind = ?';
      whereParams.push(kind);
    } else if (kind !== 'post') {
      return emptyFeed(req, res, tab, page, pageSize);
    }
  }
  // 瞬间 24h 过期后任何流都不再出现（含推荐/热门）。
  if (flags.postsV2) {
    where += " AND (p.kind <> 'moment' OR p.expires_at IS NULL OR p.expires_at > CURRENT_TIMESTAMP)";
  }

  let order = 'p.created_at DESC, p.id DESC';
  const orderParams = [];
  if (tab === 'following') {
    where += ' AND EXISTS(SELECT 1 FROM community_follows fw WHERE fw.follower_id = ? AND fw.following_id = p.student_id)';
    if (flags.postsV2) where += ' AND p.is_anonymous = 0';
    whereParams.push(viewer.id);
  } else if (tab === 'peer') {
    where += " AND COALESCE(CAST(s.province_code AS TEXT), '') = ? AND COALESCE(CAST(s.exam_year AS TEXT), '') = ?";
    if (flags.postsV2) where += ' AND p.is_anonymous = 0';
    whereParams.push(viewerProfile.province, viewerProfile.year);
  } else if (tab === 'treehole') {
    where += ' AND p.is_anonymous = 1';
  } else if (tab === 'hot') {
    where += " AND p.created_at >= datetime('now','-7 days')";
    order = '(COALESCE(p.like_count, 0) + COALESCE(p.comment_count, 0)) DESC, p.created_at DESC, p.id DESC';
  } else if (tab === 'recommend' && viewerProfile) {
    // 匿名帖不参与「同省同年」加权，避免通过排序暴露作者省份/年份线索。
    order = (flags.postsV2
      ? "CASE WHEN p.is_anonymous = 1 THEN 1 WHEN COALESCE(CAST(s.province_code AS TEXT), '') = ? AND COALESCE(CAST(s.exam_year AS TEXT), '') = ? THEN 0 ELSE 1 END"
      : "CASE WHEN COALESCE(CAST(s.province_code AS TEXT), '') = ? AND COALESCE(CAST(s.exam_year AS TEXT), '') = ? THEN 0 ELSE 1 END") + ', p.created_at DESC, p.id DESC';
    orderParams.push(viewerProfile.province, viewerProfile.year);
  }

  const totalRow = db.get(
    'SELECT COUNT(*) AS c FROM community_posts p LEFT JOIN students s ON s.id = p.student_id WHERE ' + where,
    whereParams
  );
  const rows = db.query(
    buildPostSelect() + ' WHERE ' + where + ' ORDER BY ' + order + ' LIMIT ? OFFSET ?',
    postSelectParams(viewerId).concat(whereParams, orderParams, [pageSize, (page - 1) * pageSize])
  );
  res.json({
    ok: true,
    page,
    pageSize,
    total: Number(totalRow && totalRow.c) || 0,
    tab,
    tags: filter.TAGS,
    posts: rows.map(row => mapPost(row, viewerId))
  });
});

// ── 发帖 / 发布瞬间 ──
router.post('/posts', requireStudentApi, (req, res) => {
  const sid = req.student.id;
  const flags = schema();
  const kindResult = parseKind(req.body && req.body.kind);
  if (!kindResult.ok) return fail(res, 400, kindResult.error);
  const kind = kindResult.kind;
  if (!allowRate(kind === 'moment' ? 'moment' : 'post', sid)) return fail(res, 429, '操作太频繁，请稍后再试');
  const checked = filter.checkPost(req.body && req.body.body);
  if (!checked.ok) return fail(res, 400, checked.error);
  const tagsResult = normalizeTags(req.body && req.body.tags);
  if (!tagsResult.ok) return fail(res, 400, tagsResult.error);
  const wantsAnonymous = parseAnonymous(req.body && req.body.anonymous);
  // 不允许静默降级成实名发布（隐私风险）：数据迁移未完成时明确拒绝。
  if (wantsAnonymous && !flags.postsV2) return fail(res, 400, '数据迁移未完成，暂不支持匿名发布');
  const anonymous = flags.postsV2 && wantsAnonymous;

  let id = null;
  db.atomic(() => {
    if (flags.postsV2) {
      const expiresSql = kind === 'moment' ? "datetime('now','+24 hours')" : 'NULL';
      id = db.run(
        'INSERT INTO community_posts (student_id, body, tags, status, kind, is_anonymous, expires_at) VALUES (?,?,?,?,?,?,' + expiresSql + ')',
        [sid, checked.body, JSON.stringify(tagsResult.tags), 'published', kind, anonymous ? 1 : 0]
      );
    } else {
      id = db.run(
        'INSERT INTO community_posts (student_id, body, tags, status) VALUES (?,?,?,?)',
        [sid, checked.body, JSON.stringify(tagsResult.tags), 'published']
      );
    }
    if (flags.growth) {
      safe(() => growth.award(db, sid, kind === 'moment' ? 'moment' : 'post'));
    }
  });
  const row = db.get('SELECT * FROM community_posts WHERE id=?', [id]) || {};
  const myGrowthRow = flags.growth ? db.get('SELECT level FROM student_growth WHERE student_id=?', [sid]) : null;
  const myLevel = myGrowthRow ? Number(myGrowthRow.level) || 1 : 1;
  res.json({
    ok: true,
    post: {
      id,
      body: checked.body,
      tags: tagsResult.tags,
      kind: flags.postsV2 ? kind : 'post',
      isAnonymous: !!anonymous,
      likeCount: 0,
      commentCount: 0,
      favoriteCount: 0,
      liked: false,
      favorited: false,
      isMine: true,
      createdAt: row.created_at || null,
      expiresAt: flags.postsV2 ? (row.expires_at || null) : null,
      authorId: anonymous ? 0 : sid,
      authorName: anonymous ? ANONYMOUS_NAME : filter.displayName(req.student),
      authorAvatar: anonymous ? '' : (req.student.avatar || ''),
      authorLevel: anonymous ? 0 : myLevel
    }
  });
});

// ── 单帖详情 ──
router.get('/posts/:id', (req, res) => {
  const id = positiveId(req.params.id);
  if (!id) return fail(res, 404, '帖子不存在');
  const flags = schema();
  const viewer = currentStudent(req);
  const viewerId = viewer ? viewer.id : null;
  let where = "p.id = ? AND p.status = 'published'";
  if (flags.postsV2) {
    where += " AND (p.kind <> 'moment' OR p.expires_at IS NULL OR p.expires_at > CURRENT_TIMESTAMP)";
  }
  const row = db.get(buildPostSelect() + ' WHERE ' + where, postSelectParams(viewerId).concat([id]));
  if (!row) return fail(res, 404, '帖子不存在');
  res.json({ ok: true, post: mapPost(row, viewerId) });
});

// ── 删除自己的帖子（软删） ──
router.delete('/posts/:id', requireStudentApi, (req, res) => {
  const id = positiveId(req.params.id);
  if (!id) return fail(res, 404, '帖子不存在');
  const post = db.get('SELECT id, student_id, status FROM community_posts WHERE id=?', [id]);
  if (!post || post.status !== 'published') return fail(res, 404, '帖子不存在');
  if (Number(post.student_id) !== req.student.id) return fail(res, 404, '帖子不存在');
  db.run("UPDATE community_posts SET status='deleted', updated_at=CURRENT_TIMESTAMP WHERE id=?", [id]);
  res.json({ ok: true });
});

// ── 点赞 / 取消点赞（v1 行为兼容；v2 通知作者并加被赞积分） ──
router.post('/posts/:id/like', requireStudentApi, (req, res) => {
  const id = positiveId(req.params.id);
  if (!id) return fail(res, 404, '帖子不存在');
  const post = db.get('SELECT * FROM community_posts WHERE id=?', [id]);
  if (!post || post.status !== 'published') return fail(res, 404, '帖子不存在');
  // 过期瞬间与隐藏/删除一致视为不存在（详情/评论/收藏已如此）。
  if (post.kind === 'moment' && post.expires_at && String(post.expires_at) <= new Date().toISOString().slice(0, 19).replace('T', ' ')) {
    return fail(res, 404, '帖子不存在');
  }
  const flags = schema();
  const sid = req.student.id;
  const authorId = Number(post.student_id) || 0;
  let liked = false;
  db.atomic(() => {
    const existing = db.get('SELECT 1 AS x FROM community_likes WHERE post_id=? AND student_id=?', [id, sid]);
    if (existing) {
      db.run('DELETE FROM community_likes WHERE post_id=? AND student_id=?', [id, sid]);
      db.run('UPDATE community_posts SET like_count = CASE WHEN like_count > 0 THEN like_count - 1 ELSE 0 END WHERE id=?', [id]);
      liked = false;
    } else {
      db.run('INSERT INTO community_likes (post_id, student_id) VALUES (?,?)', [id, sid]);
      db.run('UPDATE community_posts SET like_count = like_count + 1 WHERE id=?', [id]);
      liked = true;
      // 自己赞自己不产生通知 / 积分，防自刷。
      if (authorId && authorId !== sid) {
        if (flags.notifications) {
          safe(() => notify.notify(db, {
            studentId: authorId,
            actorId: sid,
            type: 'like',
            targetType: 'post',
            targetId: id,
            content: '赞了你的帖子'
          }));
        }
        if (flags.growth) {
          safe(() => growth.award(db, authorId, 'like_received'));
        }
      }
    }
  });
  const latest = db.get('SELECT like_count FROM community_posts WHERE id=?', [id]);
  res.json({ ok: true, liked, likeCount: Number(latest && latest.like_count) || 0 });
});

// ── 收藏切换（v2） ──
router.post('/posts/:id/favorite', requireStudentApi, (req, res) => {
  const flags = schema();
  if (!flags.favorites || !flags.postsV2) return fail(res, 404, '帖子不存在');
  const id = positiveId(req.params.id);
  if (!id) return fail(res, 404, '帖子不存在');
  const post = findVisiblePost(id);
  if (!post) return fail(res, 404, '帖子不存在');
  const sid = req.student.id;
  const authorId = Number(post.student_id) || 0;
  let favorited = false;
  db.atomic(() => {
    const existing = db.get('SELECT 1 AS x FROM community_favorites WHERE post_id=? AND student_id=?', [id, sid]);
    if (existing) {
      db.run('DELETE FROM community_favorites WHERE post_id=? AND student_id=?', [id, sid]);
      db.run('UPDATE community_posts SET favorite_count = CASE WHEN favorite_count > 0 THEN favorite_count - 1 ELSE 0 END WHERE id=?', [id]);
      favorited = false;
    } else {
      db.run('INSERT INTO community_favorites (post_id, student_id) VALUES (?,?)', [id, sid]);
      db.run('UPDATE community_posts SET favorite_count = favorite_count + 1 WHERE id=?', [id]);
      favorited = true;
      if (authorId && authorId !== sid) {
        if (flags.growth) safe(() => growth.award(db, authorId, 'favorite_received'));
        if (flags.notifications) {
          safe(() => notify.notify(db, {
            studentId: authorId,
            actorId: sid,
            type: 'favorite',
            targetType: 'post',
            targetId: id,
            content: '收藏了你的帖子'
          }));
        }
      }
    }
  });
  const latest = db.get('SELECT favorite_count FROM community_posts WHERE id=?', [id]);
  res.json({ ok: true, favorited, favoriteCount: Number(latest && latest.favorite_count) || 0 });
});

// ── 我的收藏（v2） ──
router.get('/favorites', requireStudentApi, (req, res) => {
  const flags = schema();
  const page = intParam(req.query.page, 1, 1, 1000000);
  const pageSize = intParam(req.query.pageSize, PAGE_SIZE_DEFAULT, 1, PAGE_SIZE_MAX);
  if (!flags.favorites || !flags.postsV2) {
    return res.json({ ok: true, page, pageSize, total: 0, posts: [] });
  }
  const viewerId = req.student.id;
  let where = "p.status = 'published' AND f.student_id = ?";
  where += " AND (p.kind <> 'moment' OR p.expires_at IS NULL OR p.expires_at > CURRENT_TIMESTAMP)";
  const totalRow = db.get(
    'SELECT COUNT(*) AS c FROM community_favorites f JOIN community_posts p ON p.id = f.post_id WHERE ' + where,
    [viewerId]
  );
  let sql = `SELECT p.*, s.name AS s_name, s.nickname AS s_nickname, s.avatar AS s_avatar,
    1 AS favorited,
    EXISTS(SELECT 1 FROM community_likes l WHERE l.post_id = p.id AND l.student_id = ?) AS liked`;
  if (flags.growth) sql += `, COALESCE(g.level, 1) AS author_level`;
  sql += `
    FROM community_favorites f
    JOIN community_posts p ON p.id = f.post_id
    LEFT JOIN students s ON s.id = p.student_id`;
  if (flags.growth) sql += ` LEFT JOIN student_growth g ON g.student_id = p.student_id`;
  sql += ' WHERE ' + where + ' ORDER BY f.created_at DESC, p.id DESC LIMIT ? OFFSET ?';
  const rows = db.query(sql, [viewerId, viewerId, pageSize, (page - 1) * pageSize]);
  res.json({
    ok: true,
    page,
    pageSize,
    total: Number(totalRow && totalRow.c) || 0,
    posts: rows.map(row => mapPost(row, viewerId))
  });
});

// ── 评论列表：一级评论 + 楼中楼回复（v1 rows 字段保留） ──
router.get('/posts/:id/comments', (req, res) => {
  const postId = positiveId(req.params.id);
  if (!postId) return fail(res, 404, '帖子不存在');
  const flags = schema();
  const post = findVisiblePost(postId);
  if (!post) return fail(res, 404, '帖子不存在');
  const viewer = currentStudent(req);
  const viewerId = viewer ? viewer.id : null;
  const anonymous = Number(post.is_anonymous) === 1;
  const page = intParam(req.query.page, 1, 1, 1000000);
  const pageSize = intParam(req.query.pageSize, COMMENT_PAGE_SIZE_DEFAULT, 1, COMMENT_PAGE_SIZE_MAX);

  if (!flags.commentsV2) {
    const totalRow = db.get(
      "SELECT COUNT(*) AS c FROM community_comments WHERE post_id=? AND status='published'",
      [postId]
    );
    const rows = db.query(
      COMMENT_SELECT + " WHERE c.post_id=? AND c.status='published' ORDER BY c.created_at ASC, c.id ASC LIMIT ? OFFSET ?",
      [postId, pageSize, (page - 1) * pageSize]
    );
    const mapped = rows.map(row => mapCommentBase(row, viewerId, anonymous));
    return res.json({
      ok: true,
      page,
      pageSize,
      total: Number(totalRow && totalRow.c) || 0,
      rows: mapped,
      comments: mapped
    });
  }

  const totalRow = db.get(
    "SELECT COUNT(*) AS c FROM community_comments WHERE post_id=? AND status='published' AND parent_id=0",
    [postId]
  );
  const topRows = db.query(
    COMMENT_SELECT + " WHERE c.post_id=? AND c.status='published' AND c.parent_id=0 ORDER BY c.created_at ASC, c.id ASC LIMIT ? OFFSET ?",
    [postId, pageSize, (page - 1) * pageSize]
  );

  // ?replies=all 返回全部回复（默认只带前 3 条预览 + replyCount，供前端「展开全部」使用）。
  const replyLimit = String(req.query.replies || '') === 'all' ? REPLY_ALL_COUNT : REPLY_PREVIEW_COUNT;
  const replyGroups = new Map();
  if (topRows.length) {
    const placeholders = topRows.map(() => '?').join(',');
    const replies = db.query(
      COMMENT_SELECT + " WHERE c.post_id=? AND c.status='published' AND c.parent_id IN (" + placeholders + ') ORDER BY c.created_at ASC, c.id ASC',
      [postId].concat(topRows.map(row => row.id))
    );
    for (const reply of replies) {
      const key = Number(reply.parent_id) || 0;
      if (!replyGroups.has(key)) replyGroups.set(key, []);
      replyGroups.get(key).push(reply);
    }
  }

  const mapped = topRows.map(row => {
    const item = mapCommentBase(row, viewerId, anonymous);
    const children = replyGroups.get(Number(row.id)) || [];
    item.replyCount = children.length;
    item.replies = children.slice(0, replyLimit).map(child => mapCommentBase(child, viewerId, anonymous));
    return item;
  });

  res.json({
    ok: true,
    page,
    pageSize,
    total: Number(totalRow && totalRow.c) || 0,
    rows: mapped,
    comments: mapped
  });
});

// ── 发评论 / 回复（v2 楼中楼，parentId 必须是一级评论且属于同帖） ──
router.post('/posts/:id/comments', requireStudentApi, (req, res) => {
  const sid = req.student.id;
  if (!allowRate('comment', sid)) return fail(res, 429, '操作太频繁，请稍后再试');
  const checked = filter.checkComment(req.body && req.body.body);
  if (!checked.ok) return fail(res, 400, checked.error);
  const postId = positiveId(req.params.id);
  if (!postId) return fail(res, 404, '帖子不存在');
  const flags = schema();
  const post = findVisiblePost(postId);
  if (!post) return fail(res, 404, '帖子不存在');

  const rawParent = req.body && req.body.parentId;
  let parentId = 0;
  let parent = null;
  if (rawParent !== undefined && rawParent !== null && rawParent !== '') {
    if (!flags.commentsV2) return fail(res, 400, '回复的评论不合法');
    parentId = positiveId(rawParent);
    if (!parentId) return fail(res, 400, '回复的评论不合法');
    parent = db.get("SELECT id, post_id, student_id, parent_id FROM community_comments WHERE id=? AND status='published'", [parentId]);
    if (!parent || Number(parent.post_id) !== postId || Number(parent.parent_id || 0) !== 0) {
      return fail(res, 400, '回复的评论不合法');
    }
  }

  const postAuthorId = Number(post.student_id) || 0;
  const anonymous = Number(post.is_anonymous) === 1;
  let commentId = null;
  db.atomic(() => {
    if (flags.commentsV2) {
      commentId = db.run(
        'INSERT INTO community_comments (post_id, student_id, body, status, parent_id) VALUES (?,?,?,?,?)',
        [postId, sid, checked.body, 'published', parentId]
      );
    } else {
      commentId = db.run(
        'INSERT INTO community_comments (post_id, student_id, body, status) VALUES (?,?,?,?)',
        [postId, sid, checked.body, 'published']
      );
    }
    db.run('UPDATE community_posts SET comment_count = comment_count + 1 WHERE id=?', [postId]);
    if (flags.growth) safe(() => growth.award(db, sid, 'comment'));
    if (flags.notifications) {
      // 帖子作者收到「评论」；被回复者收到「回复」（同一人只发一条，避免重复打扰）。
      if (postAuthorId && postAuthorId !== sid && (!parent || Number(parent.student_id) !== postAuthorId)) {
        safe(() => notify.notify(db, {
          studentId: postAuthorId,
          actorId: sid,
          type: 'comment',
          targetType: 'post',
          targetId: postId,
          content: '评论了你的帖子：' + checked.body.slice(0, 80)
        }));
      }
      if (parent && Number(parent.student_id) !== sid) {
        safe(() => notify.notify(db, {
          studentId: Number(parent.student_id),
          actorId: sid,
          type: 'reply',
          targetType: 'comment',
          targetId: Number(parent.id),
          content: '回复了你的评论：' + checked.body.slice(0, 80)
        }));
      }
    }
  });
  const row = db.get(COMMENT_SELECT + ' WHERE c.id=?', [commentId]);
  const latest = db.get('SELECT comment_count FROM community_posts WHERE id=?', [postId]);
  res.json({
    ok: true,
    comment: row ? mapCommentBase(row, sid, anonymous) : null,
    commentCount: Number(latest && latest.comment_count) || 0
  });
});

// ── 删除自己的评论（软删；v2 删除一级评论时连带其回复） ──
router.delete('/comments/:id', requireStudentApi, (req, res) => {
  const flags = schema();
  const id = positiveId(req.params.id);
  if (!id) return fail(res, 404, '评论不存在');
  const comment = db.get('SELECT * FROM community_comments WHERE id=?', [id]);
  if (!comment || comment.status !== 'published') return fail(res, 404, '评论不存在');
  if (Number(comment.student_id) !== req.student.id) return fail(res, 404, '评论不存在');
  let removed = 1;
  db.atomic(() => {
    if (flags.commentsV2 && Number(comment.parent_id || 0) === 0) {
      const replyRow = db.get(
        "SELECT COUNT(*) AS c FROM community_comments WHERE parent_id=? AND status='published'",
        [id]
      );
      const replies = Number(replyRow && replyRow.c) || 0;
      if (replies > 0) {
        db.run("UPDATE community_comments SET status='deleted' WHERE parent_id=? AND status='published'", [id]);
        removed += replies;
      }
    }
    db.run("UPDATE community_comments SET status='deleted' WHERE id=?", [id]);
    db.run(
      'UPDATE community_posts SET comment_count = CASE WHEN comment_count > ? THEN comment_count - ? ELSE 0 END WHERE id=?',
      [removed, removed, comment.post_id]
    );
  });
  const latest = db.get('SELECT comment_count FROM community_posts WHERE id=?', [comment.post_id]);
  res.json({ ok: true, commentCount: Number(latest && latest.comment_count) || 0 });
});

// ── 举报 ──
router.post('/reports', requireStudentApi, (req, res) => {
  const sid = req.student.id;
  if (!allowRate('report', sid)) return fail(res, 429, '操作太频繁，请稍后再试');
  const body = req.body || {};
  const targetType = String(body.targetType == null ? '' : body.targetType).trim();
  if (targetType !== 'post' && targetType !== 'comment') return fail(res, 400, '举报目标类型不合法');
  const targetId = positiveId(body.targetId);
  if (!targetId) return fail(res, 400, '举报目标不合法');
  const reasonCheck = filter.checkReportReason(body.reason);
  if (!reasonCheck.ok) return fail(res, 400, reasonCheck.error);
  const reason = String(body.reason).trim();
  if (body.detail !== undefined && body.detail !== null && typeof body.detail !== 'string') return fail(res, 400, '补充说明格式不正确');
  const detail = String(body.detail == null ? '' : body.detail).trim();
  if (Array.from(detail).length > 200) return fail(res, 400, '补充说明最多 200 字');

  const target = targetType === 'post'
    ? db.get("SELECT id FROM community_posts WHERE id=? AND status='published'", [targetId])
    : db.get("SELECT id FROM community_comments WHERE id=? AND status='published'", [targetId]);
  if (!target) return fail(res, 404, '举报目标不存在');

  const recent = db.get(
    "SELECT id FROM community_reports WHERE student_id=? AND target_type=? AND target_id=? AND created_at > datetime('now','-1 day')",
    [sid, targetType, targetId]
  );
  if (recent) return fail(res, 429, '已提交过举报，请勿重复提交');

  db.run(
    "INSERT INTO community_reports (target_type, target_id, student_id, reason, detail, status) VALUES (?,?,?,?,?,'open')",
    [targetType, targetId, sid, reason, detail]
  );
  res.json({ ok: true });
});

// ── 社区概览 ──
router.get('/summary', (req, res) => {
  const viewer = currentStudent(req);
  const posts = db.get("SELECT COUNT(*) AS c FROM community_posts WHERE status='published'");
  const today = db.get("SELECT COUNT(*) AS c FROM community_posts WHERE status='published' AND date(created_at)=date('now')");
  const comments = db.get("SELECT COUNT(*) AS c FROM community_comments WHERE status='published'");
  const myPosts = viewer
    ? db.get("SELECT COUNT(*) AS c FROM community_posts WHERE status='published' AND student_id=?", [viewer.id])
    : null;
  res.json({
    ok: true,
    posts: Number(posts && posts.c) || 0,
    today: Number(today && today.c) || 0,
    comments: Number(comments && comments.c) || 0,
    myPosts: Number(myPosts && myPosts.c) || 0,
    signedIn: !!viewer
  });
});

// 统一 JSON 404 与异常兜底：社区接口任何情况下都返回 JSON，不落 HTML 错误页。
router.use((req, res) => fail(res, 404, '接口不存在'));
router.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  console.error('[community]', err && err.message);
  fail(res, 500, '服务器错误');
});

module.exports = router;
