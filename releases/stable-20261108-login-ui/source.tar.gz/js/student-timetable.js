(function(){
 'use strict';
 var panel=document.querySelector('.workspace-timetable'),data=document.getElementById('myTimetableData');if(!panel||!data)return;
 var lessons;try{lessons=JSON.parse(data.textContent);}catch(e){lessons=[];}
 var parts={};new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date()).forEach(function(p){parts[p.type]=p.value;});
 var today=parts.year+'-'+parts.month+'-'+parts.day,start=new Date(today+'T00:00:00Z');start.setUTCDate(start.getUTCDate()-(start.getUTCDay()+6)%7);
 function key(date){return date.toISOString().slice(0,10);}
 function day(n){var d=new Date(start);d.setUTCDate(d.getUTCDate()+n);return key(d);}
 function el(tag,cls,text){var node=document.createElement(tag);if(cls)node.className=cls;if(text!==undefined)node.textContent=text;return node;}
 var rows=lessons.map(function(l){var m=String(l.time||'').match(/^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})/);return m?{lesson:l,day:m[1],clock:m[2]}:null;}).filter(Boolean).sort(function(a,b){return a.clock.localeCompare(b.clock)||Number(a.lesson.id)-Number(b.lesson.id);});
 var host=panel.querySelector('[data-timetable-content]');
 function render(){var grid=el('div','student-calendar-grid student-week-grid');host.replaceChildren();
 panel.querySelector('[data-timetable-range]').textContent=day(0).replace(/-/g,'.')+' — '+day(6).slice(5).replace('-','.');
 for(var i=0;i<7;i++){var date=day(i),header=el('div','student-calendar-weekday'+(date===today?' is-today':''));header.appendChild(el('span','','星期'+['一','二','三','四','五','六','日'][i]));header.appendChild(el('small','',date.slice(5).replace('-','/')));grid.appendChild(header);}
 for(var j=0;j<7;j++){
  var dateKey=day(j),cell=el('div','student-week-day'+(dateKey===today?' is-today':'')),items=rows.filter(function(r){return r.day===dateKey;});cell.setAttribute('aria-label',dateKey+'，'+items.length+'个课次');
  var card=el('div','student-week-day-card');cell.appendChild(card);
  if(!items.length)card.appendChild(el('span','student-week-empty','暂无课程'));
  items.forEach(function(r){var l=r.lesson,event=el('article','student-week-event'),time=el('time','',r.clock);time.dateTime=dateKey+'T'+r.clock+':00+08:00';event.appendChild(time);event.appendChild(el('strong','',l.course));event.appendChild(el('span','',l.title));if(l.teacher)event.appendChild(el('span','',l.teacher));
   if(l.live||l.replay){var link=el('a','',l.live?'进入直播':'观看回放');link.href=l.live?'/live/student/live-watch/'+Number(l.courseId):'/live/student/replay-duo/'+Number(l.courseId)+'?lesson='+Number(l.id)+'&v=2';link.target='_blank';link.rel='noopener';event.appendChild(link);}else event.appendChild(el('span','',dateKey<today?'暂无回放':'待上课'));card.appendChild(event);
  });grid.appendChild(cell);
 }host.appendChild(grid);
 }
 panel.addEventListener('click',function(event){if(event.target.closest('[data-week-today]')){start=new Date(today+'T00:00:00Z');start.setUTCDate(start.getUTCDate()-(start.getUTCDay()+6)%7);render();return;}var button=event.target.closest('[data-week-step]');if(!button)return;start.setUTCDate(start.getUTCDate()+Number(button.dataset.weekStep)*7);render();});render();
})();
