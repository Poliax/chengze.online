(function(){
 function compact(text) {
  const value=String(text||'').replace(/\s+/g,' ').trim();
  if(!value)return '';
  const rules=[
   [/请先阅读并同意|请先同意.*协议/,'请先同意相关协议'],
   [/密码已重设/,'密码已重设，请登录'],
   [/验证码已发送/,'验证码已发送'],
   [/尝试次数过多|频繁|限流/,'操作频繁，请稍后重试'],
   [/手机号已注册|该手机号已注册/,'手机号已注册，请登录'],
   [/微信登录暂未开通/,'请使用手机号登录'],
   [/登录状态保存失败|登录暂不可用/,'登录暂不可用，请重试'],
   [/账号未开通后台权限或已停用/,'账号或密码错误'],
   [/该教师账号已停用/,'账号或密码错误'],
   [/请输入用户名和密码/,'请输入账号和密码'],
   [/^(?:密码错误|用户名或密码错误)$/,'账号或密码错误']
  ];
  for(const [pattern,message] of rules)if(pattern.test(value))return message;
  const width=Array.from(value).reduce((n,c)=>n+(/[\u0000-\u007f]/.test(c)?.55:1),0);
  return width<=14?value:'操作失败，请重试';
 }
 if(typeof module!=='undefined'&&module.exports)module.exports={compact};
 if(typeof document==='undefined')return;
 if(document.documentElement.dataset.czAuthFeedbackReady)return;
 document.documentElement.dataset.czAuthFeedbackReady='true';
 // Keep initial focus away from credentials; Safari may restore it on navigation.
 const loginTitle=document.querySelector('.login-card .login-header h1');
 if(loginTitle){
  let interacted=false;
  const interact=()=>{interacted=true;};
  document.addEventListener('pointerdown',interact,{capture:true,once:true});
  document.addEventListener('keydown',interact,{capture:true,once:true});
  const initialFocus=()=>{if(!interacted){const active=document.activeElement;if(active&&active.closest('.login-card')&&typeof active.blur==='function')active.blur();}};
  document.addEventListener('focusin',initialFocus,true);
  initialFocus();
  window.addEventListener('pageshow',initialFocus);
 }

 function init(){
  for(const id of ['authMsg','authMsg2','smsLoginMessage','resetMessage','authV2Message']){
   const message=document.getElementById(id);if(!message)continue;
   const normalize=()=>{const text=compact(message.textContent);if(text!==message.textContent)message.textContent=text;};
   normalize();new MutationObserver(normalize).observe(message,{childList:true,subtree:true,characterData:true});
  }
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
