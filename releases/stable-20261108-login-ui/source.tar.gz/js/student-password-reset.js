(function () {
 'use strict';
 var panel=document.getElementById('authReset');
 if(!panel)return;
 var phone=document.getElementById('resetPhone'),code=document.getElementById('resetCode'),password=document.getElementById('resetPassword');
 var send=document.getElementById('resetSendCode'),submit=document.getElementById('resetSubmit'),message=document.getElementById('resetMessage');
 var busy=false,deadline=0,timer;
 function notice(text){message.textContent=text;}
 function update(){var left=Math.max(0,Math.ceil((deadline-Date.now())/1000));send.disabled=busy||left>0;submit.disabled=busy;send.textContent=left?left+'秒后重发':'获取验证码';submit.textContent=busy?'请稍候…':'重设密码';if(!left&&timer){clearInterval(timer);timer=null;}}
 function validPhone(){if(/^1\d{10}$/.test(phone.value.trim()))return true;notice('请输入正确的手机号');phone.focus();return false;}
 async function post(url,body){var r=await fetch(url,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});var data=await r.json();if(!r.ok||!data.success||data.devCode)throw Error(data.devCode?'短信服务暂不可用':data.error||'操作失败，请重试');return data;}
 window.openPasswordReset=function(){
  var value=document.getElementById('loginPhone').value.trim();
  window.switchAuth('login');
  document.getElementById('authLogin').style.display='none';panel.style.display='';
  if(phone.value!==value){phone.value=value;code.value='';}password.value='';notice('');
  document.getElementById('authTitle').textContent='重设登录密码';
  if(window.positionAuthAgreement)window.positionAuthAgreement('authReset');
  document.querySelector('#authModal .auth-intro').style.display='none';
  phone.focus();update();
 };
 phone.addEventListener('input',function(){code.value='';});
 send.addEventListener('click',async function(){
  if(send.disabled||!validPhone())return;
  busy=true;notice('');update();
  try {await post('/api/auth/send-code',{phone:phone.value.trim()});deadline=Date.now()+60000;timer=setInterval(update,1000);notice('验证码已发送，5分钟内有效');code.focus();}
  catch(e){notice(e.message);}finally{busy=false;update();}
 });
 panel.addEventListener('submit',async function(event){
  event.preventDefault();if(busy||!validPhone())return;
  if(!/^\d{6}$/.test(code.value.trim())){notice('请输入6位短信验证码');code.focus();return;}
  if(password.value.length<6||password.value.length>64||!password.value.trim()){notice('请设置6至64位新密码');password.focus();return;}
  busy=true;notice('');update();
  try {
   await post('/api/auth/reset-password',{phone:phone.value.trim(),code:code.value.trim(),password:password.value});
   try{localStorage.removeItem('cz_remember_login');}catch(e){}
   document.getElementById('loginPhone').value=phone.value.trim();document.getElementById('loginPassword').value='';
   code.value='';password.value='';window.switchAuth('login');
   document.getElementById('authMsg').textContent='密码已重设，请使用新密码登录';document.getElementById('loginPassword').focus();
  }catch(e){notice(e.message);}finally{busy=false;update();}
 });
 update();
}());
