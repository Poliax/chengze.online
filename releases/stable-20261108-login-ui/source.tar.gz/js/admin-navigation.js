(function(){
 const TYPE='application/x-cz-admin-view';
 function adminPath(path,host='admin.chengze.online') {
  if (host==='admin.chengze.online' && path==='/') return true;
  return /^\/(?:admin\/)?(?:dashboard|workspace|accounts(?:-manage)?|technical-center|provinces(?:-manage)?|teachers(?:-manage)?|courses(?:-manage)?|packages(?:-manage)?|live(?:-manage)?|replays(?:-manage)?|questions(?:-manage)?|course-materials|community(?:-manage)?|users(?:-manage)?|students(?:-manage)?|orders(?:-manage)?|logistics(?:-manage)?|ads(?:-manage)?)(?:\/|$)/.test(path) && !/^\/(?:admin\/)?live\/(?:studio|api|student)(?:\/|$)/.test(path);
 }
 if(typeof module!=='undefined'&&module.exports)module.exports={adminPath};
 if(typeof document==='undefined')return;
 let content=document.querySelector('.teacher-main > .teacher-content');
 if(!content||!document.getElementById('sidebar')||!adminPath(location.pathname,location.hostname))return;
 const own=Object.prototype.hasOwnProperty;
 const commonCSS=new Set(['/css/style.css','/css/backend.css','/public/css/ui-actions.css','/public/css/student-controls.css','/public/css/backend-typography.css','/public/css/table-standard.css','/public/css/calendar-standard.css','/public/css/auth-feedback.css']);
 const canceled=new WeakSet();window.addEventListener('unhandledrejection',event=>{if(event.reason&&typeof event.reason==='object'&&canceled.has(event.reason))event.preventDefault();});
 const sources=new Map(), vendors=new Set(Array.from(document.querySelectorAll('script[data-admin-vendor][src]'),s=>s.src));
 let version=0,pending=null,active=null,rendered=location.href,dirty=false,booting=true;
 const positions=new Map();
 const overlays=document.createElement('div');overlays.id='admin-view-overlays';document.body.append(overlays);
 const notice=document.createElement('div');notice.className='admin-navigation-status';notice.setAttribute('role','status');notice.setAttribute('aria-live','polite');document.body.append(notice);
 const statusStyle=document.createElement('style');statusStyle.textContent='.admin-navigation-status{display:none;position:fixed;top:72px;right:24px;z-index:200;padding:7px 12px;background:#fff;border:1px solid #DCE1E6;border-radius:8px;color:#64748b;font-size:12px}.admin-navigation-status:not(:empty){display:block}';document.head.append(statusStyle);
 function full(url) { const next=new URL(url,location.href);next.searchParams.set('__admin_full','1');location.assign(next.href); }
 function pageScripts(doc){return Array.from(doc.querySelectorAll('script[data-admin-view-script]'));}
 function extras(doc){
  const main=doc.querySelector('.teacher-main');
  return [...Array.from(doc.body.children),...Array.from(main?.children||[])].filter(el=>el!==main&&el!==content&&!el.matches('#sidebar,.teacher-content,[data-admin-shell],script,style,link,#admin-view-overlays,.admin-navigation-status'));
 }
 function lifecycle() {
  const cleanups=[],ready=[],values=Object.create(null),exports=Object.create(null),controller=new AbortController();let live=true,collect=true,observer;
  const track=fn=>{cleanups.push(fn);return fn;};
  const canceledError=()=>{const error=new DOMException('View closed','AbortError');canceled.add(error);return error;};
  function listen(target,type,fn,options){
   if(type==='DOMContentLoaded'||(target===window&&type==='load')){ready.push(()=>{if(live)fn.call(target,new Event(type));});return;}
   target.addEventListener(type,fn,options);track(()=>target.removeEventListener(type,fn,options));
  }
  function timer(method,clear){return (fn,delay,...args)=>{const id=window[method]((...a)=>{if(live)typeof fn==='function'?fn(...a):evaluate(String(fn),window);},delay,...args);track(()=>window[clear](id));return id;};}
  const timeout=timer('setTimeout','clearTimeout'),interval=timer('setInterval','clearInterval');
  const frame=fn=>{const id=requestAnimationFrame(time=>{if(live)fn(time);});track(()=>cancelAnimationFrame(id));return id;};
  const observed=Class=>class extends Class{constructor(...args){super(...args);track(()=>this.disconnect());}};
  const managedFetch=(input,options={})=>{
   const abort=new AbortController(),cancel=()=>abort.abort();controller.signal.addEventListener('abort',cancel,{once:true});options.signal?.addEventListener('abort',cancel,{once:true});
   if(!live||options.signal?.aborted)abort.abort();
   return fetch(input,{...options,signal:abort.signal}).then(response=>{if(!live)throw canceledError();return new Proxy(response,{get(target,key){const value=Reflect.get(target,key,target);if(['json','text','blob','arrayBuffer'].includes(key))return (...args)=>value.apply(target,args).then(result=>{if(!live)throw canceledError();return result;});return typeof value==='function'?value.bind(target):value;}});}).finally(()=>{controller.signal.removeEventListener('abort',cancel);options.signal?.removeEventListener('abort',cancel);}).catch(error=>{if(!live&&error&&typeof error==='object')canceled.add(error);throw error;});
  };
  function proxy(target,isWindow){return new Proxy(target,{
   get(object,key){
    if(isWindow&&['window','self','globalThis'].includes(key))return win;
    if(key==='document')return doc;
    if(key==='addEventListener')return (type,fn,options)=>listen(target,type,fn,options);
    if(key==='removeEventListener')return target.removeEventListener.bind(target);
    if(!isWindow&&key==='readyState'&&collect)return 'loading';
    if(isWindow&&own.call(values,key))return values[key];
    if(isWindow&&own.call(exports,key))return exports[key];
    const value=Reflect.get(object,key,object);
    return typeof value==='function'&&!/^[A-Z]/.test(String(key))?value.bind(object):value;
   },
   set(object,key,value){
    if(/^on/.test(String(key))){if(typeof value==='function')listen(target,String(key).slice(2),value);return true;}
    if(isWindow){exports[key]=value;return true;}
    return Reflect.set(object,key,value,object);
   }
  });}
  const doc=proxy(document,false),win=proxy(window,true);
  Object.assign(values,{setTimeout:timeout,setInterval:interval,clearTimeout,clearInterval,requestAnimationFrame:frame,cancelAnimationFrame,fetch:managedFetch,MutationObserver:observed(MutationObserver)});
  if(window.ResizeObserver)values.ResizeObserver=observed(ResizeObserver);
  let evaluate;
  const wired=new WeakMap();
  function bindInline(root){
   const nodes=root.nodeType===1?[root,...root.querySelectorAll('*')]:Array.from(root.querySelectorAll?.('*')||[]);
   for(const el of nodes)for(const attr of Array.from(el.attributes||[])){
    if(!/^on[a-z]+$/i.test(attr.name))continue;
    const saved=wired.get(el)||new Map();if(saved.get(attr.name)===attr.value)continue;saved.set(attr.name,attr.value);wired.set(el,saved);
    const code=attr.value;el[attr.name.toLowerCase()]=function(event){return evaluate(code,this,event);};
   }
  }
  return {
   async start(code){
    const setup=new Function('document','window','globalThis','setTimeout','setInterval','clearTimeout','clearInterval','requestAnimationFrame','cancelAnimationFrame','MutationObserver','ResizeObserver','fetch','__exports','__register',
     'function __handler(code,element,event){with(__exports){return eval("(function(event){"+code+"\\n})").call(element,event);}}\n__register(__handler);\n'+code+'\n');
    setup.call(win,doc,win,win,timeout,interval,clearTimeout,clearInterval,frame,cancelAnimationFrame,values.MutationObserver,values.ResizeObserver,managedFetch,exports,handler=>{
     evaluate=handler;bindInline(content);bindInline(overlays);
     observer=new MutationObserver(records=>{for(const record of records){if(record.type==='attributes')bindInline(record.target);else for(const node of record.addedNodes)if(node.nodeType===1)bindInline(node);}});
     observer.observe(content,{childList:true,subtree:true,attributes:true});observer.observe(overlays,{childList:true,subtree:true,attributes:true});track(()=>observer.disconnect());
    });
    collect=false;for(const fn of ready)fn();
   },
   stop(){if(!live)return;live=false;controller.abort();for(const cleanup of cleanups.reverse())try{cleanup();}catch{};},
   get live(){return live;}
  };
 }
 async function scriptText(script) {
  if(!script.src)return script.textContent;
  const url=new URL(script.getAttribute('src'),location.href);if(url.origin!==location.origin)throw Error('Unsupported page script');
  if(!sources.has(url.href))sources.set(url.href,fetch(url,{credentials:'same-origin'}).then(r=>{if(!r.ok)throw Error('Script failed');return r.text();}).catch(error=>{sources.delete(url.href);throw error;}));
  return sources.get(url.href);
 }
 async function vendor(script) {
  const src=new URL(script.getAttribute('src'),location.href).href;if(vendors.has(src))return;
  await new Promise((resolve,reject)=>{const el=document.createElement('script');el.src=src;el.onload=resolve;el.onerror=reject;document.head.append(el);});vendors.add(src);
 }
 async function prepare(doc) {
  for(const script of doc.querySelectorAll('script[data-admin-vendor][src]'))await vendor(script);
  const code=(await Promise.all(pageScripts(doc).map(scriptText))).join('\n;\n');
  return {code,styles:Array.from(doc.querySelectorAll('style[data-admin-view-style]')),css:Array.from(doc.querySelectorAll('link[rel="stylesheet"]')).filter(el=>!commonCSS.has(new URL(el.getAttribute('href'),location.href).pathname))};
 }
 function highlight(doc) {
  const states=new Map(Array.from(doc.querySelectorAll('#sidebar .sidebar-nav a[href]'),a=>[new URL(a.getAttribute('href'),location.href).pathname,a.classList.contains('active')]));
  for(const link of document.querySelectorAll('#sidebar .sidebar-nav a[href]'))link.classList.toggle('active',!!states.get(new URL(link.href).pathname));
 }
 async function styles(prepared) {
  const fresh=[];
  for(const original of prepared.css){
   const link=document.createElement('link');link.rel='stylesheet';link.href=new URL(original.getAttribute('href'),location.href).href;link.dataset.adminActiveAsset='';link.media='not all';
   fresh.push(link);await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Stylesheet timeout')),12000);link.onload=()=>{clearTimeout(timer);resolve();};link.onerror=()=>{clearTimeout(timer);reject(Error('Stylesheet failed'));};document.head.append(link);});
  }
  return fresh;
 }
 async function mount(doc,prepared,url,{initial=false,pop=false,isCurrent=()=>true}={}) {
  const links=initial?[]:await styles(prepared);
  if(!isCurrent()){for(const link of links)link.remove();return false;}
  const source=doc.querySelector('.teacher-main > .teacher-content');if(!source)throw Error('No page content');
  if(!initial){
   active?.stop();
   document.querySelectorAll('[data-admin-active-asset]').forEach(el=>{if(!links.includes(el))el.remove();});
   for(const link of links)link.media='all';
   content.replaceWith(source);content=source;
   overlays.replaceChildren(...extras(doc));
   for(const style of prepared.styles){const el=document.createElement('style');el.textContent=style.textContent;el.dataset.adminActiveAsset='';document.head.append(el);}
   document.body.className=doc.body.className;document.title=doc.title;
  } else {
   for(const style of prepared.styles)style.dataset.adminActiveAsset='';
   for(const link of prepared.css)link.dataset.adminActiveAsset='';
   for(const el of extras(document))overlays.append(el);
  }
  active=lifecycle();await active.start(prepared.code);dirty=false;
  if(!initial){if(!pop)history.pushState({adminView:true},'',url.href);highlight(doc);const pos=pop?positions.get(url.href):null;content.scrollTo(pos?.x||0,pos?.y||0);}
  rendered=url.href;
  document.getElementById('sidebar')?.classList.remove('open');document.getElementById('adminNavOverlay')?.setAttribute('hidden','');
 }
 async function navigate(url,{pop=false}={}) {
  if(booting)return;
  if(!pop&&url.href===rendered)return;
  if(dirty&&!confirm('当前内容尚未保存，确定切换页面吗？')){if(pop)history.pushState({adminView:true},'',rendered);return;}
  if(pending)pending.abort();const controller=new AbortController(),id=++version;pending=controller;
  positions.set(rendered,{x:content.scrollLeft,y:content.scrollTop});content.setAttribute('aria-busy','true');
  const timer=setTimeout(()=>{if(id===version)notice.textContent='加载中…';},150);
  try{
   const response=await fetch(url,{credentials:'same-origin',cache:'no-store',signal:controller.signal,headers:{Accept:'text/html','X-Admin-Navigation':'1'}});
   const finalURL=new URL(response.url||url.href);if([401,403].includes(response.status)||finalURL.pathname==='/login'||finalURL.pathname==='/admin/login'){location.assign(finalURL.pathname.includes('login')?finalURL.href:'/login');return;}
   if(!response.ok||finalURL.origin!==location.origin||!response.headers.get('content-type')?.includes('text/html'))throw Error('Navigation failed');
   const doc=new DOMParser().parseFromString(await response.text(),'text/html');
   if(!doc.getElementById('cz-admin-navigation')||!doc.querySelector('.teacher-main > .teacher-content')){location.assign(finalURL.href);return;}
   const prepared=await prepare(doc);if(id!==version)return;
   await mount(doc,prepared,finalURL,{pop,isCurrent:()=>id===version});notice.textContent='';
  }catch(error){if(controller.signal.aborted)return;console.error('Admin navigation:',error);if(id===version)full(url.href);}
  finally{clearTimeout(timer);if(id===version){pending=null;content.removeAttribute('aria-busy');notice.textContent='';}}
 }
 document.addEventListener('click',event=>{
  const link=event.target.closest('#sidebar a[href]');if(booting)return;if(!link||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey||link.target||link.hasAttribute('download'))return;
  const url=new URL(link.href,location.href);if(url.origin!==location.origin||!adminPath(url.pathname,location.hostname))return;
  event.preventDefault();navigate(url);
 });
 function changed(event){const form=event.target.closest('form');if(form&&!form.matches('.toolbar-form,[data-client-filter]'))dirty=true;}
 document.addEventListener('input',event=>{if(event.target.closest('.teacher-content,#admin-view-overlays'))changed(event);});document.addEventListener('change',event=>{if(event.target.closest('.teacher-content,#admin-view-overlays'))changed(event);});
 window.addEventListener('popstate',()=>{const url=new URL(location.href);if(adminPath(url.pathname,location.hostname))navigate(url,{pop:true});else location.reload();});
 window.addEventListener('pagehide',()=>active?.stop());
 (async()=>{try{history.replaceState({adminView:true},'',location.href);await mount(document,await prepare(document),new URL(location.href),{initial:true});booting=false;}catch(error){console.error('Admin initialization:',error);full(location.href);}})();
})();
