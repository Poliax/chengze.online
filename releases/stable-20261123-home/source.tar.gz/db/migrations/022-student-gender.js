module.exports=function(db){
 const info=db.exec('PRAGMA table_info(students)');
 if(!info.length)throw Error('students table required');
 if(!info[0].values.some(row=>row[1]==='gender'))db.run("ALTER TABLE students ADD COLUMN gender TEXT NOT NULL DEFAULT 'unknown'");
};
