module.exports = function (db) {
  db.run(`CREATE TABLE IF NOT EXISTS practice_paper_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    paper_id TEXT NOT NULL,
    snapshot TEXT NOT NULL,
    answers TEXT NOT NULL DEFAULT '{}',
    revision INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'open',
    started_at INTEGER NOT NULL,
    deadline INTEGER NOT NULL,
    submitted_at INTEGER,
    result TEXT
  )`);
  db.run('CREATE INDEX IF NOT EXISTS practice_paper_runs_student ON practice_paper_runs(student_id, paper_id, status)');
};
