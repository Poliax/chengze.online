module.exports=function(db){
 db.run('BEGIN IMMEDIATE');try{
  db.run(`CREATE TABLE IF NOT EXISTS prep_admission_plans(province_id INTEGER NOT NULL,year INTEGER NOT NULL,major_code TEXT NOT NULL,school_code TEXT NOT NULL,school_name TEXT NOT NULL,total INTEGER NOT NULL,ordinary INTEGER NOT NULL,veteran INTEGER NOT NULL,special INTEGER NOT NULL,source_url TEXT NOT NULL,PRIMARY KEY(province_id,year,major_code,school_code))`);
  db.run(`CREATE TABLE IF NOT EXISTS prep_admission_scores(province_id INTEGER NOT NULL,year INTEGER NOT NULL,major_code TEXT NOT NULL,school_code TEXT NOT NULL,school_name TEXT NOT NULL,category TEXT NOT NULL,stage TEXT NOT NULL,score TEXT NOT NULL,source_url TEXT NOT NULL,PRIMARY KEY(province_id,year,major_code,school_code,category,stage))`);
  const seed=require('../../data/prep-admissions-shaanxi-2026.json'),p=db.exec("SELECT id FROM provinces WHERE name IN ('陕西','陕西省') OR code='61' ORDER BY id LIMIT 1");
  if(p.length){const id=Number(p[0].values[0][0]);
   if(!db.exec(`SELECT 1 FROM prep_imports WHERE province_id=${id} AND year=2026 AND type='plans' LIMIT 1`).length){
    for(const r of seed.plans)db.run('INSERT OR IGNORE INTO prep_admission_plans VALUES(?,?,?,?,?,?,?,?,?,?)',[id,seed.year,r.major_code,r.school_code,r.school_name,r.total,r.ordinary,r.veteran,r.special,seed.plan_source]);
    db.run('INSERT INTO prep_imports(province_id,year,type,row_count,source_url,actor) VALUES(?,?,?,?,?,?)',[id,seed.year,'plans',seed.plans.length,seed.plan_source,'官方首批数据']);
   }
   if(!db.exec(`SELECT 1 FROM prep_imports WHERE province_id=${id} AND year=2026 AND type='scores' LIMIT 1`).length){
    for(const r of seed.scores)db.run('INSERT OR IGNORE INTO prep_admission_scores VALUES(?,?,?,?,?,?,?,?,?)',[id,seed.year,r.major_code,r.school_code,r.school_name,r.category,r.stage,r.score,r.source_url]);
    db.run('INSERT INTO prep_imports(province_id,year,type,row_count,source_url,actor) VALUES(?,?,?,?,?,?)',[id,seed.year,'scores',seed.scores.length,seed.score_index,'官方首批数据']);
   }
  }
  db.run('COMMIT');
 }catch(e){db.run('ROLLBACK');throw e;}
};
