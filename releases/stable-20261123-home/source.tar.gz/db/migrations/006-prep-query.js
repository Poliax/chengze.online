module.exports=function(db){
 db.run('BEGIN IMMEDIATE');
 try{
  db.run(`CREATE TABLE IF NOT EXISTS prep_majors(province_id INTEGER NOT NULL,year INTEGER NOT NULL,code TEXT NOT NULL,name TEXT NOT NULL,kind TEXT NOT NULL,common_subjects TEXT DEFAULT '',professional_subjects TEXT DEFAULT '',subject_note TEXT DEFAULT '',subject_source TEXT DEFAULT '',common_source TEXT DEFAULT '',PRIMARY KEY(province_id,year,code))`);
  db.run(`CREATE TABLE IF NOT EXISTS prep_mappings(province_id INTEGER NOT NULL,year INTEGER NOT NULL,junior_name TEXT NOT NULL,junior_key TEXT NOT NULL,major_code TEXT NOT NULL,source_url TEXT NOT NULL,PRIMARY KEY(province_id,year,junior_key,major_code),FOREIGN KEY(province_id,year,major_code) REFERENCES prep_majors(province_id,year,code))`);
  db.run(`CREATE INDEX IF NOT EXISTS prep_junior_lookup ON prep_mappings(province_id,year,junior_key)`);
  db.run(`CREATE TABLE IF NOT EXISTS prep_imports(id INTEGER PRIMARY KEY AUTOINCREMENT,province_id INTEGER NOT NULL,year INTEGER NOT NULL,type TEXT NOT NULL,row_count INTEGER NOT NULL,source_url TEXT NOT NULL,actor TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP)`);
  const seed=require('../../data/prep-shaanxi-2026.json'),p=db.exec("SELECT id FROM provinces WHERE name IN ('陕西','陕西省') OR code='61' ORDER BY id LIMIT 1");
  if(p.length){const id=p[0].values[0][0];const exists=db.exec(`SELECT 1 FROM prep_imports WHERE province_id=${Number(id)} AND year=2026 LIMIT 1`);
   if(!exists.length){
    for(const m of seed.majors)db.run('INSERT OR IGNORE INTO prep_majors(province_id,year,code,name,kind,common_subjects,professional_subjects,subject_note,subject_source,common_source) VALUES(?,?,?,?,?,?,?,?,?,?)',[id,seed.year,m.code,m.name,m.kind,m.common_subjects.join('、'),m.professional_subjects.join('、'),[m.subject_note,seed.note].filter(Boolean).join(' '),seed.subject_source,seed.common_source]);
    for(const [junior,code] of seed.mappings)db.run('INSERT OR IGNORE INTO prep_mappings(province_id,year,junior_name,junior_key,major_code,source_url) VALUES(?,?,?,?,?,?)',[id,seed.year,junior,require('../../lib/prep-data').key(junior),code,seed.mapping_source]);
    db.run('INSERT INTO prep_imports(province_id,year,type,row_count,source_url,actor) VALUES(?,?,?,?,?,?)',[id,seed.year,'mapping',seed.mappings.length,seed.mapping_source,'官方首批数据']);
    db.run('INSERT INTO prep_imports(province_id,year,type,row_count,source_url,actor) VALUES(?,?,?,?,?,?)',[id,seed.year,'subjects',seed.majors.length,seed.subject_source,'官方首批数据']);
   }
  }
  db.run('COMMIT');
 }catch(e){db.run('ROLLBACK');throw e;}
};
