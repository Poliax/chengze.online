module.exports=db=>{
 const result=db.exec('PRAGMA table_info(students)');
 const names=result.length?result[0].values.map(row=>row[1]):[];
 if(!names.includes('cancelled_phone'))db.run('ALTER TABLE students ADD COLUMN cancelled_phone TEXT');
};
