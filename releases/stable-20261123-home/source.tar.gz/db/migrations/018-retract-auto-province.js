// Retract only the untouched row created by the withdrawn 017 release.
module.exports=function(db){
 const result=db.exec("SELECT * FROM provinces WHERE id=15 AND code='14' AND name='山西' AND created_at='2026-10-30 07:10:59'");
 if(!result.length)return;
 const {columns,values}=result[0],row=Object.fromEntries(columns.map((c,i)=>[c,values[0][i]]));
 if(Object.entries(row).some(([key,value])=>!['id','code','name','created_at'].includes(key)&&value!=null&&!['','[]','{}'].includes(String(value))))return;
 const tables=db.exec("SELECT name FROM sqlite_master WHERE type='table'")[0];
 for(const [name] of tables.values){
  const quote='"'+name.replace(/"/g,'""')+'"',info=db.exec('PRAGMA table_info('+quote+')')[0];
  for(const column of info.values.map(v=>v[1]).filter(c=>['province_id','province_code'].includes(c))){
   const value=column==='province_id'?15:'14';
   if(db.exec('SELECT 1 FROM '+quote+' WHERE "'+column+'"=? LIMIT 1',[value]).length)return;
  }
 }
 db.run("DELETE FROM provinces WHERE id=15 AND code='14' AND created_at='2026-10-30 07:10:59'");
};
