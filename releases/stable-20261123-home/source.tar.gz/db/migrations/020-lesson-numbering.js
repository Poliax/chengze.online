module.exports=db=>{
 const columns=db.exec('PRAGMA table_info(lessons)');if(!columns.length)return;
 for(const name of ['course_lesson_number','stage_lesson_number'])if(!columns[0].values.some(r=>r[1]===name))db.run('ALTER TABLE lessons ADD COLUMN '+name+' INTEGER');
};
