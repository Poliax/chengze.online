module.exports = function (db) {
  db.run(`CREATE TABLE IF NOT EXISTS sms_send_limits (
    phone TEXT PRIMARY KEY,
    day INTEGER NOT NULL,
    count INTEGER NOT NULL,
    last_sent_at INTEGER NOT NULL
  )`);
};
