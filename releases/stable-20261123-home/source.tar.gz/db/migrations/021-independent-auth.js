// Additive migration. Keep person IDs and all existing course relationships.
module.exports = function migrate(db) {
  const columns = name => new Set(db.exec('PRAGMA table_info(' + name + ')')[0].values.map(row => row[1]));
  const adminColumns = columns('admin_accounts'), teacherColumns = columns('teachers');
  const firstTeacherMigration = !teacherColumns.has('portal_enabled');
  for (const [name,type] of [['login_username',"TEXT NOT NULL DEFAULT ''"],['login_password_hash',"TEXT NOT NULL DEFAULT ''"],['login_display_name',"TEXT NOT NULL DEFAULT ''"],['login_avatar',"TEXT NOT NULL DEFAULT ''"]]) {
    if (!adminColumns.has(name)) db.run('ALTER TABLE admin_accounts ADD COLUMN ' + name + ' ' + type);
  }
  for (const [name,type] of [['portal_enabled','INTEGER NOT NULL DEFAULT 1'],['portal_session_version','INTEGER NOT NULL DEFAULT 1']]) {
    if (!teacherColumns.has(name)) db.run('ALTER TABLE teachers ADD COLUMN ' + name + ' ' + type);
  }
  // Copy only once: later teacher password/name changes must never overwrite backend credentials.
  if (!adminColumns.has('login_username')) {
    const field = (name,fallback) => teacherColumns.has(name) ? '(SELECT ' + name + ' FROM teachers WHERE id=admin_accounts.teacher_id)' : fallback;
    db.run('UPDATE admin_accounts SET login_username=COALESCE('+field('username',"''")+",''), login_password_hash=COALESCE("+field('password_hash',"''")+",''), login_display_name=COALESCE("+field('display_name',"''")+",''), login_avatar=COALESCE("+field('avatar',"''")+",'')");
  }
  if (firstTeacherMigration) {
    // Only explicitly assigned teachers retain a portal identity; a super-account is not automatically a teacher.
    const access = require('../../lib/admin-access');
    const result = db.exec('SELECT * FROM admin_accounts')[0];
    if (result) for (const values of result.values) {
      const row = Object.fromEntries(result.columns.map((column,i) => [column,values[i]]));
      if (!access.assignedRoles(row).includes('teacher')) db.run('UPDATE teachers SET portal_enabled=0 WHERE id=?',[row.teacher_id]);
    }
  }
  db.run("CREATE UNIQUE INDEX IF NOT EXISTS admin_login_username_unique ON admin_accounts(login_username) WHERE login_username<>''");
};
