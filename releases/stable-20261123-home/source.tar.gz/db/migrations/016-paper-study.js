// Exam and study progress are isolated; historical runs remain timed exams.
module.exports=function(db){
 const rows=db.exec('PRAGMA table_info(practice_paper_runs)'),columns=rows.length?rows[0].values.map(r=>r[1]):[];
 if(!columns.includes('mode'))db.run("ALTER TABLE practice_paper_runs ADD COLUMN mode TEXT NOT NULL DEFAULT 'exam'");
 db.run('CREATE INDEX IF NOT EXISTS paper_runs_mode ON practice_paper_runs(student_id,paper_id,mode,status)');
 db.run(`CREATE TABLE IF NOT EXISTS paper_study_words (
  student_id INTEGER NOT NULL,word TEXT NOT NULL,definition TEXT NOT NULL,context TEXT NOT NULL DEFAULT '',paper_id TEXT NOT NULL,question_id TEXT NOT NULL,
  stage INTEGER NOT NULL DEFAULT 0,due_at INTEGER NOT NULL DEFAULT 0,revision INTEGER NOT NULL DEFAULT 0,updated_at INTEGER NOT NULL,PRIMARY KEY(student_id,word))`);
 db.run('CREATE TABLE IF NOT EXISTS paper_grammar_cache (id TEXT PRIMARY KEY,result TEXT NOT NULL,created_at INTEGER NOT NULL)');
};
