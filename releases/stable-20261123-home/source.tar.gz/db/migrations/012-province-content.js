module.exports=function(db){
 db.run('BEGIN IMMEDIATE');
 try{
  db.run(`CREATE TABLE IF NOT EXISTS province_resources(id INTEGER PRIMARY KEY AUTOINCREMENT,province_id INTEGER NOT NULL,kind TEXT NOT NULL,title TEXT NOT NULL,url TEXT NOT NULL,year INTEGER NOT NULL DEFAULT 0,subject_id INTEGER,source_url TEXT DEFAULT '',status TEXT NOT NULL DEFAULT 'draft',sort_order INTEGER NOT NULL DEFAULT 0,origin_key TEXT UNIQUE,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(province_id) REFERENCES provinces(id) ON DELETE CASCADE)`);
  db.run(`CREATE INDEX IF NOT EXISTS province_resources_scope ON province_resources(province_id,status,kind,year)`);
  db.run(`CREATE TABLE IF NOT EXISTS prep_mapping_visibility(province_id INTEGER NOT NULL,year INTEGER NOT NULL,junior_key TEXT NOT NULL,major_code TEXT NOT NULL,hidden INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(province_id,year,junior_key,major_code))`);
  const read=q=>{const r=db.exec(q)[0];return r?r.values.map(v=>Object.fromEntries(r.columns.map((k,i)=>[k,v[i]]))):[];};
  const url=v=>typeof v==='string'?v.replace(/^\/provinces\//,'/public/provinces/'):'';
  function seed(p,kind,value,title,key,sid){
   let list=value;try{if(typeof value==='string'&&value.trim().startsWith('['))list=JSON.parse(value);}catch{return;}
   if(!Array.isArray(list))list=[list];
   list.forEach((v,i)=>{const link=url(typeof v==='string'?v:v&&v.url);if(!/^(?:https?:\/\/|\/public\/provinces\/)/i.test(link))return;db.run('INSERT OR IGNORE INTO province_resources(province_id,kind,title,url,year,subject_id,status,origin_key) VALUES(?,?,?,?,?,?,?,?)',[p,kind,String(v&&v.title||v&&v.name||title),link,Number(v&&v.year)||0,sid||null,'published',key+(i?':'+i:'')]);});
  }
  for(const p of read('SELECT id,name,outline_file,papers_file,official_docs FROM provinces')){
   seed(p.id,'syllabus',p.outline_file,p.name+'考试大纲','province:'+p.id+':outline');seed(p.id,'papers',p.papers_file,p.name+'历年真题','province:'+p.id+':papers');
   let docs=[];try{docs=JSON.parse(p.official_docs||'[]');}catch{}
   if(Array.isArray(docs))docs.filter(d=>d&&typeof d==='object').forEach((d,i)=>seed(p.id,/大纲/.test(d.title)?'syllabus':/真题/.test(d.title)?'papers':'notice',[d],d.title||'官方公告','official:'+p.id+':'+i));
  }
  for(const s of read('SELECT id,province_id,name,outline_file,papers_file FROM province_subjects')){seed(s.province_id,'syllabus',s.outline_file,s.name+'考试大纲','subject:'+s.id+':outline',s.id);seed(s.province_id,'papers',s.papers_file,s.name+'历年真题','subject:'+s.id+':papers',s.id);}
  db.run('COMMIT');
 }catch(e){db.run('ROLLBACK');throw e;}
};
