// 练习模块：作答流水、模考快照、错题本。幂等迁移，不种子数据。
module.exports = function (db) {
  db.run('BEGIN IMMEDIATE');
  try {
    db.run(`CREATE TABLE IF NOT EXISTS practice_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      question_id INTEGER NOT NULL,
      selected INTEGER,
      correct INTEGER NOT NULL DEFAULT 0,
      mode TEXT NOT NULL DEFAULT 'practice',
      exam_id INTEGER,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )`);
    db.run('CREATE INDEX IF NOT EXISTS practice_attempts_student ON practice_attempts(student_id, created_at)');
    db.run('CREATE INDEX IF NOT EXISTS practice_attempts_question ON practice_attempts(student_id, question_id)');

    db.run(`CREATE TABLE IF NOT EXISTS practice_exams (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      question_count INTEGER NOT NULL,
      score INTEGER NOT NULL DEFAULT 0,
      duration_seconds INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'open',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      submitted_at TEXT
    )`);
    db.run('CREATE INDEX IF NOT EXISTS practice_exams_student ON practice_exams(student_id, created_at)');

    db.run(`CREATE TABLE IF NOT EXISTS practice_exam_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      exam_id INTEGER NOT NULL,
      question_id INTEGER NOT NULL,
      position INTEGER NOT NULL,
      selected INTEGER,
      correct INTEGER,
      UNIQUE(exam_id, position)
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS practice_wrong_book (
      student_id INTEGER NOT NULL,
      question_id INTEGER NOT NULL,
      wrong_count INTEGER NOT NULL DEFAULT 1,
      last_wrong_at TEXT DEFAULT CURRENT_TIMESTAMP,
      resolved INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (student_id, question_id)
    )`);

    db.run('COMMIT');
  } catch (error) {
    db.run('ROLLBACK');
    throw error;
  }
};
