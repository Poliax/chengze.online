module.exports = db => db.run(`CREATE TABLE IF NOT EXISTS student_learning_activity (
 student_id INTEGER NOT NULL REFERENCES students(id), study_date TEXT NOT NULL,
 lesson_id INTEGER NOT NULL REFERENCES lessons(id), seconds REAL NOT NULL DEFAULT 0,
 PRIMARY KEY(student_id,study_date,lesson_id)
);`);
