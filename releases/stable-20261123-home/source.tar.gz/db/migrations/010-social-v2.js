// 社区 v2（参考 Soul 的互动机制，做专升本业务适配）：
// 关注关系、匿名树洞、学习搭子、私信、通知、打卡、积分等级/排行榜、个人资料扩展。
// 幂等迁移：只加列/建表，不种子数据，不删改既有数据。
module.exports = function migrateSocialV2(db) {
  function tableInfo(name) {
    const info = db.exec(`PRAGMA table_info(${name})`);
    return info.length ? info[0].values.map(row => row[1]) : null;
  }

  const students = tableInfo('students');
  if (!students) throw Error('community v2 migration requires students table');
  const posts = tableInfo('community_posts');
  if (!posts) throw Error('community v2 migration requires community_posts table (run 009 first)');
  const comments = tableInfo('community_comments');
  if (!comments) throw Error('community v2 migration requires community_comments table (run 009 first)');

  const studentMissing = ['target_school', 'target_major', 'bio', 'study_tags'].filter(name => !students.includes(name));
  const postMissing = ['kind', 'is_anonymous', 'expires_at', 'favorite_count'].filter(name => !posts.includes(name));
  const commentMissing = ['parent_id'].filter(name => !comments.includes(name));

  db.run('BEGIN IMMEDIATE');
  try {
    for (const name of studentMissing) {
      const ddl = name === 'study_tags' ? "TEXT NOT NULL DEFAULT '[]'" : "TEXT NOT NULL DEFAULT ''";
      db.run(`ALTER TABLE students ADD COLUMN ${name} ${ddl}`);
    }
    for (const name of postMissing) {
      const ddl = name === 'kind' ? "TEXT NOT NULL DEFAULT 'post'"
        : name === 'is_anonymous' ? 'INTEGER NOT NULL DEFAULT 0'
        : name === 'favorite_count' ? 'INTEGER NOT NULL DEFAULT 0'
        : 'TEXT';
      db.run(`ALTER TABLE community_posts ADD COLUMN ${name} ${ddl}`);
    }
    for (const name of commentMissing) {
      db.run(`ALTER TABLE community_comments ADD COLUMN ${name} INTEGER NOT NULL DEFAULT 0`);
    }

    // 瞬间（24h 过期）索引：按 kind + 创建时间取流
    db.run('CREATE INDEX IF NOT EXISTS community_posts_kind ON community_posts(kind, status, created_at)');

    db.run(`CREATE TABLE IF NOT EXISTS community_follows(
      follower_id INTEGER NOT NULL,
      following_id INTEGER NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY(follower_id, following_id)
    )`);
    db.run('CREATE INDEX IF NOT EXISTS community_follows_following ON community_follows(following_id, created_at)');

    db.run(`CREATE TABLE IF NOT EXISTS community_favorites(
      post_id INTEGER NOT NULL,
      student_id INTEGER NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY(post_id, student_id)
    )`);
    db.run('CREATE INDEX IF NOT EXISTS community_favorites_student ON community_favorites(student_id, created_at)');

    db.run(`CREATE TABLE IF NOT EXISTS community_notifications(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      actor_id INTEGER NOT NULL DEFAULT 0,
      type TEXT NOT NULL,
      target_type TEXT NOT NULL DEFAULT '',
      target_id INTEGER NOT NULL DEFAULT 0,
      content TEXT NOT NULL DEFAULT '',
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )`);
    db.run('CREATE INDEX IF NOT EXISTS community_notifications_inbox ON community_notifications(student_id, is_read, created_at)');

    db.run(`CREATE TABLE IF NOT EXISTS community_messages(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sender_id INTEGER NOT NULL,
      receiver_id INTEGER NOT NULL,
      body TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )`);
    db.run('CREATE INDEX IF NOT EXISTS community_messages_pair ON community_messages(sender_id, receiver_id, created_at)');
    db.run('CREATE INDEX IF NOT EXISTS community_messages_inbox ON community_messages(receiver_id, is_read, created_at)');

    db.run(`CREATE TABLE IF NOT EXISTS community_checkins(
      student_id INTEGER NOT NULL,
      day TEXT NOT NULL,
      note TEXT NOT NULL DEFAULT '',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY(student_id, day)
    )`);
    db.run('CREATE INDEX IF NOT EXISTS community_checkins_day ON community_checkins(day)');

    db.run(`CREATE TABLE IF NOT EXISTS student_growth(
      student_id INTEGER PRIMARY KEY,
      points INTEGER NOT NULL DEFAULT 0,
      week_points INTEGER NOT NULL DEFAULT 0,
      week_key TEXT NOT NULL DEFAULT '',
      level INTEGER NOT NULL DEFAULT 1,
      checkin_streak INTEGER NOT NULL DEFAULT 0,
      checkin_total INTEGER NOT NULL DEFAULT 0,
      last_checkin_day TEXT NOT NULL DEFAULT '',
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )`);
    db.run('CREATE INDEX IF NOT EXISTS student_growth_points ON student_growth(points)');
    db.run('CREATE INDEX IF NOT EXISTS student_growth_week ON student_growth(week_points)');

    db.run(`CREATE TABLE IF NOT EXISTS student_growth_events(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      action TEXT NOT NULL,
      points INTEGER NOT NULL DEFAULT 0,
      day TEXT NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )`);
    db.run('CREATE INDEX IF NOT EXISTS student_growth_events_day ON student_growth_events(student_id, day, action)');

    db.run('COMMIT');
  } catch (error) {
    db.run('ROLLBACK');
    throw error;
  }
};
