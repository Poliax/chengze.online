module.exports=function(db){
 const rows=db.exec('PRAGMA table_info(live_chats)');
 if(!rows.length)return;
 const columns=new Set(rows[0].values.map(row=>row[1]));
 for(const name of ['author_role','author_id','avatar'])if(!columns.has(name))db.run("ALTER TABLE live_chats ADD COLUMN "+name+" TEXT DEFAULT ''");
};
