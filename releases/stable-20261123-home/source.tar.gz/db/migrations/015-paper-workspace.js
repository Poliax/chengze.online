// Durable review marks and notes, additive for existing answer sheets.
module.exports = function (db) {
  const rows = db.exec('PRAGMA table_info(practice_paper_runs)');
  const columns = rows.length ? rows[0].values.map(row => row[1]) : [];
  if (!columns.includes('workspace')) db.run("ALTER TABLE practice_paper_runs ADD COLUMN workspace TEXT NOT NULL DEFAULT '{}' ");
};
