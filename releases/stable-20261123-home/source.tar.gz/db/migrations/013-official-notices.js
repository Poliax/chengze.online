module.exports = function(db) {
  db.run(`CREATE TABLE IF NOT EXISTS notice_sources (
    key TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1,
    last_run TEXT DEFAULT '', last_success TEXT DEFAULT '', last_error TEXT DEFAULT '', last_result TEXT DEFAULT '')`);
  for (const key of ['shaanxi', 'shandong']) db.run('INSERT OR IGNORE INTO notice_sources(key) VALUES(?)', [key]);
  db.run(`CREATE TABLE IF NOT EXISTS notice_items (
    resource_id INTEGER PRIMARY KEY REFERENCES province_resources(id) ON DELETE CASCADE,
    source_key TEXT NOT NULL, source_url TEXT NOT NULL UNIQUE,
    publisher TEXT NOT NULL, published_on TEXT DEFAULT '', category TEXT DEFAULT '',
    summary TEXT DEFAULT '', fingerprint TEXT DEFAULT '', review_reason TEXT DEFAULT '',
    manually_managed INTEGER NOT NULL DEFAULT 0, checked_at TEXT DEFAULT CURRENT_TIMESTAMP)`);
};
