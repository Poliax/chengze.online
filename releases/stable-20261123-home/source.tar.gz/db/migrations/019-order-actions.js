module.exports = function (db) {
  db.run(`
    CREATE TABLE IF NOT EXISTS order_customer_state (
      order_id INTEGER PRIMARY KEY REFERENCES orders(id),
      deleted_at TEXT
    );
    CREATE TABLE IF NOT EXISTS order_refunds (
      order_id INTEGER PRIMARY KEY REFERENCES orders(id),
      request_no TEXT NOT NULL UNIQUE,
      amount REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'requested',
      reason TEXT NOT NULL,
      review_note TEXT NOT NULL DEFAULT '',
      reviewer_id INTEGER,
      revoke_access INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS order_payment_grants (
      order_id INTEGER PRIMARY KEY REFERENCES orders(id),
      enrollment_id INTEGER NOT NULL,
      created_by_payment INTEGER NOT NULL DEFAULT 0
    );
  `);
};
