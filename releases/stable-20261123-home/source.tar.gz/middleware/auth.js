function requireTeacher(req, res, next) {
  if (req.session && req.session.teacherId) {
    if (req.adminAccount) return next();
    const db=require('../db'), access=require('../lib/admin-access');
    const account=access.sessionAccount(db,req.session);
    if (!account) return res.status(401).send('后台登录已失效，请重新登录');
    // These legacy routers are also mounted outside /admin; protect both aliases.
    const key=req.baseUrl==='/packages' ? 'packages' : req.baseUrl==='/provinces' ? 'provinces' : access.routeModule(req.originalUrl);
    if ((!key && account.role!=='ceo') || (key && !access.can(account,key,access.isWrite(req)))) return res.status(403).send('没有此功能权限');
    next();
  } else {
    res.redirect('/admin/login');
  }
}

function requirePortal(req, res, next) {
  if (req.session && req.session.teacherPortalId) {
    if (!require('../lib/portal-account').sessionAccount(require('../db'),req.session)) {
      for (const key of require('../lib/auth-session').portalKeys) delete req.session[key];
      return res.status(401).send('教师登录已失效，请重新登录');
    }
    next();
  } else {
    res.redirect('/teach/login');
  }
}

module.exports = { requireTeacher, requirePortal };
