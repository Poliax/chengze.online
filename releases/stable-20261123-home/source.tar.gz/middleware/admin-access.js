const crypto = require('crypto');
const db = require('../db');
const access = require('../lib/admin-access');
module.exports = function(req, res, next) {
  if (/^\/(login|logout)\/?$/.test(req.path)) return next();
  if (!req.session.teacherId) {
    if (req.session.teacherPortalId && (/^\/live\/studio\//.test(req.path) || /^\/live-manage\/\d+\/status\/?$/.test(req.path))) return next();
    return res.redirect('/admin/login');
  }
  const account = access.load(db, req.session.teacherId);
  // Only the original admin's pre-migration session may be upgraded in place.
  if (account && account.username === 'admin' && req.session.adminVersion == null && account.session_version === 1) req.session.adminVersion = 1;
  if (!account || account.status !== 'active' || account.session_version !== req.session.adminVersion) {
    delete req.session.teacherId; delete req.session.adminVersion;
    return res.status(401).send('账号已停用或权限已变更，请重新登录。<a href="/login">重新登录</a>');
  }
  // A linked person record may not be deleted, but teacher credentials are independent.
  const staffDelete=req.method==='POST' && req.path.match(/^\/teachers-manage\/([1-9]\d*)\/delete\/?$/);
  if (staffDelete && access.load(db,Number(staffDelete[1]))) return res.status(403).send('该教师资料关联后台身份，请停用教师端账号以保留关联资料。');
  req.adminAccount = account;
  req.session.teacherName = account.display_name;
  res.locals.teacherName = account.display_name;
  res.locals.adminAccount = account;
  res.locals.canAdmin = (key, write) => access.can(account, key, write);
  res.locals.canAdminPath = url => url === '/admin/dashboard' ? account.role === 'ceo' : url === '/admin/workspace' || access.can(account, access.routeModule(url));
  if (!req.session.accountCsrf) req.session.accountCsrf = crypto.randomBytes(32).toString('hex');
  res.locals.accountCsrf = req.session.accountCsrf;
  res.set('Cache-Control','private, no-store');
  if (req.path === '/workspace') return res.render('teacher/account-dashboard', { title:'工作台 · 管理后台', access });
  if (req.path === '/' || req.path === '/dashboard') {
    if (account.role !== 'ceo') return res.status(403).send('控制台仅限超级账号访问。<a href="/workspace">进入工作台</a>');
    return next();
  }
  const key = access.routeModule('/admin' + req.path);
  // Unknown legacy endpoints stay ceo-only, never implicitly grant access.
  if ((!key && account.role !== 'ceo') || (key && !access.can(account, key, access.isWrite(req)))) return res.status(403).send('无权访问此功能。<a href="/dashboard">返回控制台</a>');
  next();
};
