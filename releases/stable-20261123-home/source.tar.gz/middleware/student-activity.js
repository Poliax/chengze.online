const actions={
 '/api/auth/register':'注册账号','/api/auth/login':'密码登录','/api/auth/login-code':'验证码登录','/api/auth/login-wechat':'微信登录','/api/auth/logout':'退出登录','/api/auth/profile':'修改个人资料','/api/auth/account-details':'修改个人资料','/api/auth/avatar':'更换头像','/api/auth/phone-change':'修改手机号','/api/auth/password':'修改登录密码','/api/auth/reset-password':'重设登录密码','/api/auth/cancel-account':'注销账号'
};
module.exports=function(db){return function(req,res,next){
 const path=req.originalUrl.split('?')[0],action=actions[path];
 const adminGrant=req.method==='POST'&&path.match(/^\/(?:admin\/users-manage|users)\/(\d+)\/course-grants$/);
 const adminCreate=req.method==='POST'&&/^\/(?:admin\/(?:users|students)-manage|users|students)\/new$/.test(path);
 if(adminGrant||adminCreate){
  const redirect=res.redirect;
  function record(){const account=req.adminAccount;if(!account)return;const sid=adminGrant?Number(adminGrant[1]):(db.get('SELECT id FROM students WHERE phone=?',[String(req.body.phone||'').trim()])||{}).id;if(!sid)return;
   const kind=adminCreate?'后台创建账号':req.body.action==='revoke'?'取消课程开通':'后台赠送课程';
   const detail=adminGrant?(['package','course'].includes(req.body.kind)?(req.body.kind==='package'?'课程包':'课程')+' ID：'+(Number(req.body.item_id)||0):''):'';
   try{db.run('INSERT INTO student_activity_log(student_id,action,source,detail) VALUES(?,?,?,?)',[sid,kind,'管理员：'+(account.display_name||account.username||'')+'（ID '+account.teacher_id+'）',detail]);}catch{console.error('Admin student activity audit write failed');}}
  res.redirect=function(status,url){const dest=typeof status==='string'?status:url;if(adminCreate||/\?(?:saved|revoked)=1$/.test(String(dest)))record();return redirect.apply(this,arguments);};
  const json=res.json;res.json=function(data){if(data&&data.success===true&&res.statusCode<400)record();return json.call(this,data);};return next();
 }
 if(req.method==='GET'&&/^\/live\/student\/(?:live-watch|vod-replay|replay-duo)\/\d+$/.test(path)){
  const sid=req.session&&req.session.studentId;
  if(sid)res.once('finish',()=>{if(res.statusCode!==200)return;try{db.run('INSERT INTO student_activity_log(student_id,action,detail) VALUES(?,?,?)',[sid,path.includes('/live-watch/')?'打开直播课堂':'打开课程回放','记录ID：'+path.split('/').pop()]);}catch{console.error('Student classroom activity audit write failed');}});return next();
 }
 if(req.method!=='POST'||!action)return next();
 const originalId=req.session&&req.session.studentId,json=res.json;
 res.json=function(data){
  if(data&&data.success===true&&res.statusCode<400){
   const studentId=originalId||(req.session&&req.session.studentId)||((path==='/api/auth/reset-password'&&typeof req.body.phone==='string')?(db.get('SELECT id FROM students WHERE phone=?',[req.body.phone.trim()])||{}).id:null);
   if(studentId){try{db.run('INSERT INTO student_activity_log(student_id,action) VALUES(?,?)',[studentId,action]);}catch{console.error('Student activity audit write failed');}}
  }
  return json.call(this,data);
 };next();
};};
