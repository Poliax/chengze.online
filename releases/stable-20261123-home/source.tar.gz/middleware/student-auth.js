const db = require('../db');

function studentId(req) {
  const raw = req && req.session ? req.session.studentId : null;
  if (!/^[1-9]\d*$/.test(String(raw))) return null;
  const n = Number(raw);
  return Number.isSafeInteger(n) ? n : null;
}

function currentStudent(req) {
  const id = studentId(req);
  if (!id) return null;
  const row = db.get('SELECT id, name, nickname, avatar, status FROM students WHERE id=?', [id]);
  if (!row || row.status === 'disabled') return null;
  return row;
}

function requireStudentApi(req, res, next) {
  const student = currentStudent(req);
  if (!student) {
    res.set('Cache-Control', 'no-store');
    return res.status(401).json({ ok: false, error: '请先登录' });
  }
  req.student = student;
  next();
}

module.exports = { studentId, currentStudent, requireStudentApi };
