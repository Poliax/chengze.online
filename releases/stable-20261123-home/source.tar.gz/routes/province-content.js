const express=require('express'),multer=require('multer'),path=require('path'),fs=require('fs'),crypto=require('crypto');
const db=require('../db'),content=require('../lib/province-content');
const notices=require('../lib/official-notices');
const router=express.Router({mergeParams:true});
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:25*1024*1024,files:1,fields:16}}).single('file');
router.use((req,res,next)=>{req.province=db.get('SELECT * FROM provinces WHERE id=?',[req.params.id]);if(!req.province)return res.status(404).send('省份不存在');next();});
function csrf(req,res,next){if(!req.session.accountCsrf||req.body._csrf!==req.session.accountCsrf)return res.status(403).send('页面已过期，请刷新后重试');next();}
function section(req){return req.query.section==='majors'?'majors':'resources';}
function page(req,res,error='',status=200){
 const province=req.province,id=province.id;
 const years=db.query('SELECT DISTINCT year FROM prep_mappings WHERE province_id=? ORDER BY year DESC',[id]).map(r=>r.year);
 const requested=Number(req.query.year),year=Number.isInteger(requested)&&requested>=2020&&requested<=2100?requested:years[0]||new Date().getFullYear();
 const subjects=db.query('SELECT id,name FROM province_subjects WHERE province_id=? ORDER BY order_index,id',[id]);
 const resources=db.query('SELECT r.*,s.name AS subject_name FROM province_resources r LEFT JOIN province_subjects s ON s.id=r.subject_id AND s.province_id=r.province_id WHERE r.province_id=? ORDER BY r.sort_order,r.year DESC,r.id DESC',[id]);
 const q=String(req.query.q||'').trim().slice(0,80),pageNo=Math.max(1,Math.min(10000,Number.parseInt(req.query.page)||1));
 const filter=q?' AND (r.junior_name LIKE ? OR m.name LIKE ? OR m.code LIKE ?)':'',args=q?[id,year,...Array(3).fill('%'+q+'%')]:[id,year];
 const base=' FROM prep_mappings r JOIN prep_majors m ON m.province_id=r.province_id AND m.year=r.year AND m.code=r.major_code LEFT JOIN prep_mapping_visibility v ON v.province_id=r.province_id AND v.year=r.year AND v.junior_key=r.junior_key AND v.major_code=r.major_code WHERE r.province_id=? AND r.year=?'+filter;
 const count=db.get('SELECT COUNT(*) AS n'+base,args).n;
 const mappings=db.query('SELECT r.junior_name,r.junior_key,r.major_code,r.source_url,m.name,m.kind,m.common_subjects,m.professional_subjects,m.subject_note,COALESCE(v.hidden,0) AS hidden'+base+' ORDER BY r.junior_name,m.code LIMIT 10 OFFSET ?',[...args,(pageNo-1)*10]);
 const editId=Number(req.query.edit)||0,editResource=resources.find(r=>r.id===editId)||null;
 const editMapping=req.query.code&&req.query.junior?db.get('SELECT r.*,m.name,m.kind,m.common_subjects,m.professional_subjects,m.subject_note FROM prep_mappings r JOIN prep_majors m ON m.province_id=r.province_id AND m.year=r.year AND m.code=r.major_code WHERE r.province_id=? AND r.year=? AND r.junior_key=? AND r.major_code=?',[id,year,String(req.query.junior),String(req.query.code)]):null;
 const source=notices.SOURCES.find(s=>s.code===province.code||s.name===province.name||s.name+'省'===province.name);
 const noticeSource=source?{...source,...db.get('SELECT * FROM notice_sources WHERE key=?',[source.key]),running:notices.service(db).running.has(source.key)}:null;
 const noticeItems=db.query('SELECT n.* FROM notice_items n JOIN province_resources r ON r.id=n.resource_id WHERE r.province_id=?',[id]);
 res.status(status).render('teacher/province-content',{title:province.name+' · 资料与专业查询管理',province,subjects,resources,kinds:content.kinds,section:section(req),years,year,q,pageNo,count,mappings,editResource,editMapping,error,noticeSource,noticeItems});
}
router.get('/',(req,res)=>page(req,res));
router.post('/notices/sync',csrf,(req,res)=>{
 const source=notices.SOURCES.find(s=>s.code===req.province.code||s.name===req.province.name||s.name+'省'===req.province.name);
 if(!source)return page(req,res,'当前仅支持陕西、山东官方公告',400);
 if(!db.get('SELECT enabled FROM notice_sources WHERE key=?',[source.key])?.enabled)return page(req,res,'请先开启本省公告采集',400);
 if(notices.service(db).running.has(source.key))return page(req,res,'本省公告正在采集中，请稍后查看',409);
 notices.service(db).sync(source.key).catch(e=>console.error('[official-notices]',source.key,e.message));
 res.redirect('/admin/provinces-manage/'+req.province.id+'/content?section=resources');
});
router.post('/notices/settings',csrf,(req,res)=>{
 const source=notices.SOURCES.find(s=>s.code===req.province.code||s.name===req.province.name||s.name+'省'===req.province.name);
 if(!source||!['0','1'].includes(req.body.enabled))return res.status(400).send('公告采集设置无效');
 db.run('UPDATE notice_sources SET enabled=? WHERE key=?',[Number(req.body.enabled),source.key]);
 res.redirect('/admin/provinces-manage/'+req.province.id+'/content?section=resources');
});
router.get('/test',(req,res)=>res.json(require('../lib/prep-data').lookup(db,req.province.code,String(req.query.year||''),String(req.query.q||'').slice(0,80))));
router.post('/resources',(req,res)=>upload(req,res,err=>{
 if(err)return page(req,res,'上传失败，请选择25MB以内的文件',400);
 csrf(req,res,()=>{
  let written='';
  try{
   const id=Number(req.body.resource_id)||0;
   const captured=id?db.get("SELECT name FROM sqlite_master WHERE type='table' AND name='notice_items'")&&db.get('SELECT * FROM notice_items WHERE resource_id=?',[id]):null;
   if(captured){
    if(req.file||req.body.kind!=='notice')throw Error('采集公告请保留官方公告分类和原文链接');
    req.body.url=captured.source_url;req.body.source_url=captured.source_url;
    if(req.body.status==='published'&&!notices.recentDate(req.body.notice_date||''))throw Error('发布前请核对近24个月内的有效发布日期');
    if(String(req.body.notice_summary||'').length>600)throw Error('公告导读请控制在600字以内');
   }
   if(req.file){
    const ext=path.extname(req.file.originalname).toLowerCase(),b=req.file.buffer;
    if(!['.pdf','.doc','.docx'].includes(ext)||!((ext==='.pdf'&&b.subarray(0,5).toString()==='%PDF-')||(ext==='.docx'&&b.subarray(0,2).toString()==='PK')||(ext==='.doc'&&b.subarray(0,4).toString('hex')==='d0cf11e0')))throw Error('请选择有效的PDF、Word文档');
    const filename=req.province.code+'_resource_'+crypto.randomBytes(12).toString('hex')+ext;
    req.body.url='/public/provinces/'+filename;
    const old=id?db.get('SELECT * FROM province_resources WHERE id=? AND province_id=?',[id,req.province.id]):null;
    if(id&&!old)throw Error('当前省份不存在这条资料');
    content.resource(db,req.province.id,req.body,old);
    written=path.join(__dirname,'../public/provinces',filename);fs.mkdirSync(path.dirname(written),{recursive:true});fs.writeFileSync(written,b,{flag:'wx',mode:0o644});
   }
   const savedId=content.saveResource(db,req.province.id,id,req.body);
   if(captured)db.run('UPDATE notice_items SET manually_managed=1,published_on=?,summary=? WHERE resource_id=?',[req.body.notice_date||'',String(req.body.notice_summary||captured.summary).trim(),savedId]);
   res.redirect('/admin/provinces-manage/'+req.province.id+'/content?section=resources&saved=1');
  }catch(e){if(written){try{fs.unlinkSync(written);}catch{}}page(req,res,/[\u4e00-\u9fff]/.test(e.message)?e.message:'保存未完成，请稍后重试',400);}
 });
}));
router.post('/resources/:resourceId/status',csrf,(req,res)=>{
 const status=req.body.status;if(!['published','draft','archived'].includes(status))return res.status(400).send('状态无效');
 if(!db.get('SELECT id FROM province_resources WHERE id=? AND province_id=?',[req.params.resourceId,req.province.id]))return res.status(404).send('资料不存在');
 const captured=db.get("SELECT name FROM sqlite_master WHERE type='table' AND name='notice_items'")&&db.get('SELECT * FROM notice_items WHERE resource_id=?',[req.params.resourceId]);
 if(captured&&status==='published'&&!notices.recentDate(captured.published_on))return page(req,res,'发布前请编辑公告，核对近24个月内的有效发布日期',400);
 db.atomic(()=>{
  db.run('UPDATE province_resources SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND province_id=?',[status,req.params.resourceId,req.province.id]);
  if(captured)db.run('UPDATE notice_items SET manually_managed=1 WHERE resource_id=?',[req.params.resourceId]);
 });
 res.redirect('/admin/provinces-manage/'+req.province.id+'/content?section=resources');
});
router.post('/mappings',csrf,(req,res)=>{
 req.query.section='majors';req.query.year=req.body.year;
 try{content.saveMapping(db,req.province.id,req.body,req.session.teacherId);res.redirect('/admin/provinces-manage/'+req.province.id+'/content?section=majors&year='+Number(req.body.year)+'&saved=1');}catch(e){page(req,res,e.message,400);}
});
router.post('/mappings/status',csrf,(req,res)=>{
 const year=Number(req.body.year),hidden=Number(req.body.hidden);
 const row=db.get('SELECT source_url FROM prep_mappings WHERE province_id=? AND year=? AND junior_key=? AND major_code=?',[req.province.id,year,req.body.junior_key,req.body.major_code]);
 if(!['0','1'].includes(String(req.body.hidden))||!row)return res.status(404).send('对应关系不存在');
 db.atomic(()=>{
  db.run(`INSERT INTO prep_mapping_visibility(province_id,year,junior_key,major_code,hidden) VALUES(?,?,?,?,?) ON CONFLICT(province_id,year,junior_key,major_code) DO UPDATE SET hidden=excluded.hidden`,[req.province.id,year,req.body.junior_key,req.body.major_code,hidden]);
  db.run('INSERT INTO prep_imports(province_id,year,type,row_count,source_url,actor) VALUES(?,?,?,?,?,?)',[req.province.id,year,'visibility',1,row.source_url,String(req.session.teacherId)]);
 });
 res.redirect('/admin/provinces-manage/'+req.province.id+'/content?section=majors&year='+year);
});
module.exports=router;
