const express=require('express'),multer=require('multer'),crypto=require('crypto'),XLSX=require('xlsx');
const db=require('../db'),prep=require('../lib/prep-data'),{requireTeacher}=require('../middleware/auth');
const router=express.Router(),previews=new Map();
router.use(requireTeacher);
function csrf(req,res,next){if(!req.session.accountCsrf||req.get('X-CSRF-Token')!==req.session.accountCsrf)return res.status(403).send('页面已过期，请刷新后重试');next();}
function view(req,res,extra={}){
 const provinces=db.query('SELECT id,name FROM provinces ORDER BY id');
 const selectedProvince=provinces.find(p=>Number(p.id)===Number(req.query.province))||null;
 const selectedYear=/^(20\d{2}|2100)$/.test(String(req.query.year||''))?Number(req.query.year):2026;
 const imports=db.query('SELECT i.*,p.name AS province FROM prep_imports i JOIN provinces p ON p.id=i.province_id'+(selectedProvince?' WHERE i.province_id=?':'')+' ORDER BY i.id DESC LIMIT 30',selectedProvince?[selectedProvince.id]:[]);
 res.render('teacher/prep-query',{title:'专业查询管理',provinces,imports,selectedProvince,selectedYear,...extra});
}
router.get('/',(req,res)=>view(req,res));
router.get('/template',(req,res)=>{
 const type=['mapping','subjects','plans','scores'].includes(req.query.type)?req.query.type:'mapping',headers={mapping:['专科专业','本科专业代码','本科专业名称','科类'],subjects:['本科专业代码','本科专业名称','科类','公共课考试科目','专业课考试科目','备注'],plans:['本科专业代码','院校代码','招生院校','招生人数合计','普通计划人数','专项计划人数','退役士兵计划人数'],scores:['本科专业代码','院校代码','招生院校','招生类别','录取阶段','录取最低分']}[type];
 const book=XLSX.utils.book_new();XLSX.utils.book_append_sheet(book,XLSX.utils.aoa_to_sheet([headers]),({mapping:'专业对应关系',subjects:'考试科目',plans:'招生计划',scores:'录取线'})[type]);
 res.attachment('prep-'+type+'-template.xlsx').send(XLSX.write(book,{type:'buffer',bookType:'xlsx'}));
});
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:6*1024*1024,files:1,fields:5}}).single('file');
router.post('/preview',csrf,(req,res)=>upload(req,res,error=>{
 try{
  if(error)throw Error('上传失败，请选择6MB以内的Excel文件');
  if(!req.file||!req.file.originalname.toLowerCase().endsWith('.xlsx'))throw Error('请选择.xlsx文件');
  const type=req.body.type,year=+req.body.year,provinceId=+req.body.provinceId,url=prep.source(req.body.source);
  if(!url||!Number.isInteger(year)||year<2020||year>2100||!db.get('SELECT id FROM provinces WHERE id=?',[provinceId]))throw Error('请填写有效的省份、年份和官方来源网址');
  const rows=prep.parse(req.file.buffer,type);
  for(const [token,item] of previews)if(item.expires<Date.now())previews.delete(token);
  if(previews.size>=20)throw Error('预览任务较多，请稍后重试');
  const token=crypto.randomBytes(24).toString('hex'),revision=db.get('SELECT MAX(id) AS id FROM prep_imports WHERE province_id=? AND year=?',[provinceId,year]).id||0;
  previews.set(token,{provinceId,year,type,rows,url,actor:String(req.session.teacherId),expires:Date.now()+15*60*1000,revision});
  res.json({token,count:rows.length,preview:rows.slice(0,10),province:db.get('SELECT name FROM provinces WHERE id=?',[provinceId]).name,year,type});
 }catch(e){res.status(400).json({error:e.message});}
}));
router.post('/confirm',csrf,(req,res)=>{
 const token=String(req.body.token||''),item=previews.get(token);
 if(!item||item.actor!==String(req.session.teacherId)||item.expires<Date.now())return res.status(400).json({error:'预览已过期，请重新上传'});
 try{
  const revision=db.get('SELECT MAX(id) AS id FROM prep_imports WHERE province_id=? AND year=?',[item.provinceId,item.year]).id||0;
  if(revision!==item.revision)throw Error('该省份年份的数据已更新，请重新预览后导入');
  const count=prep.apply(db,item);previews.delete(token);res.json({count});
 }catch(e){res.status(400).json({error:e.message});}
});
module.exports=router;
