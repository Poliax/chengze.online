const createCourseShipping = require('../lib/course-shipping');
const crypto = require('node:crypto');
module.exports = function(db) {
 const router = require('express').Router();
 const validId = v => /^[1-9]\d*$/.test(String(v)) && Number.isSafeInteger(Number(v));
 function render(req,res,message='',status=200) {
  const student=db.get('SELECT id,name,real_name,phone,status FROM students WHERE id=?',[Number(req.params.id)]);
  if(!student)return res.status(404).send('用户不存在');
  if(!req.session.courseGrantToken)req.session.courseGrantToken=crypto.randomBytes(32).toString('hex');
  res.set('Cache-Control','private, no-store');
  const packages=db.query("SELECT id,title FROM course_packages WHERE status='published' AND COALESCE(parent_id,0)>0 ORDER BY title,id");
  if (req.get('Accept') === 'application/json') return res.status(status).json({token:req.session.courseGrantToken, packages, message});
  return res.status(status).render('teacher/user-course-grants',{title:'开通课程 · 注册管理',teacherName:req.session.teacherName,student,token:req.session.courseGrantToken,message,
   packages,
   ownedPackages:db.query('SELECT p.title FROM package_enrollments e JOIN course_packages p ON p.id=e.package_id WHERE e.student_id=? ORDER BY e.id DESC',[student.id]),
   ownedCourses:db.query('SELECT c.title FROM enrollments e JOIN courses c ON c.id=e.course_id WHERE e.student_id=? ORDER BY e.id DESC',[student.id])});
 }
 router.get('/:id/course-grants',(req,res)=>render(req,res,req.query.saved==='1'?'已开通，学员可在学习总览查看。':''));
 router.post('/:id/course-grants',(req,res)=>{
  if(!req.session.courseGrantToken || typeof req.body.token!=='string' || req.body.token!==req.session.courseGrantToken)return res.status(403).send('页面已失效，请刷新后重试');
  const student=validId(req.params.id)&&db.get('SELECT id,status FROM students WHERE id=?',[Number(req.params.id)]);
  if(!student)return res.status(404).send('用户不存在');
  if(student.status==='disabled' || student.status==='cancelled')return render(req,res,'该账号当前不可开通课程。',400);
  const kind=req.body.kind, id=req.body.item_id;
  if(!['package','course'].includes(kind)||!validId(id))return render(req,res,'请选择要开通的班课或课程。',400);
  if(kind!=='package')return render(req,res,'请选择可赠送的课程。',400);
  const item=db.get('SELECT id,status FROM course_packages WHERE id=? AND COALESCE(parent_id,0)>0',[Number(id)]);
  if(!item||item.status!=='published')return render(req,res,'课程不存在或尚未上架，请重新选择。',400);
  const target='package_enrollments', column='package_id';
  db.atomic(() => {
   db.run('INSERT OR IGNORE INTO '+target+' (student_id,'+column+',granted_by_admin) VALUES (?,?,1)',[student.id,Number(id)]);
   if (req.body.ship_materials === '1') {
    const enrollment = db.get('SELECT id FROM package_enrollments WHERE student_id=? AND package_id=? AND granted_by_admin=1', [student.id, Number(id)]);
    if (enrollment) createCourseShipping(db, {studentId:student.id, packageId:Number(id), number:'LG-G-'+enrollment.id});
   }
   db.run('UPDATE order_payment_grants SET created_by_payment=0 WHERE order_id IN (SELECT id FROM orders WHERE student_id=? AND '+column+'=?)',
    [student.id,Number(id)]);
  });
  if (req.get('Accept') === 'application/json') return res.json({success:true});
  return res.redirect('/admin/users-manage/'+student.id+'/course-grants?saved=1');
 });
 return router;
};
