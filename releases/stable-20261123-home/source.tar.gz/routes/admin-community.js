// 社区审核后台，挂载 /admin/community-manage。
// 权限交给 requireTeacher（模块 community）；所有 POST 校验账号 CSRF。
const express = require('express');
const router = express.Router();
const db = require('../db');
const filter = require('../lib/community-filter');
const { requireTeacher } = require('../middleware/auth');

const PAGE_SIZE = 10;
const TABS = ['posts', 'comments', 'reports'];
const POST_STATUSES = ['published', 'hidden', 'deleted'];
const REPORT_STATUSES = ['open', 'resolved'];
const TYPE_LABELS = { post: '帖子', comment: '评论' };
const STATUS_LABELS = { published: '已发布', hidden: '已隐藏', deleted: '已删除', open: '待处理', resolved: '已处理' };
const MESSAGES = {
  hidden: '已隐藏该帖子，其下评论同步隐藏',
  shown: '已恢复该帖子，评论保持隐藏',
  post_deleted: '已删除该帖子（软删）',
  comment_hidden: '已隐藏该评论',
  comment_deleted: '已删除该评论（软删）',
  resolved: '已处理该举报',
  missing: '记录不存在或已被删除'
};

router.use(requireTeacher);
router.use((req, res, next) => {
  res.set('Cache-Control', 'private, no-store');
  next();
});

// 后台表单 CSRF：与账号会话里的 accountCsrf 比对，失败 403。
function csrf(req, res, next) {
  const token = (req.body || {}).csrf;
  if (!req.session || !req.session.accountCsrf || token !== req.session.accountCsrf) {
    return res.status(403).send('CSRF 校验失败');
  }
  next();
}

function positiveId(raw) {
  const text = String(raw == null ? '' : raw);
  if (!/^[1-9]\d*$/.test(text)) return null;
  const n = Number(text);
  return Number.isSafeInteger(n) ? n : null;
}

function excerpt(body, max) {
  const chars = Array.from(String(body == null ? '' : body).trim());
  return chars.length <= max ? chars.join('') : chars.slice(0, max).join('') + '…';
}

function authorName(row) {
  return filter.displayName({ name: row.s_name, nickname: row.s_nickname });
}

// 操作后回到原 tab/筛选/页码，并带一条提示。
function redirectBack(req, res, msgKey) {
  const body = req.body || {};
  const tab = TABS.includes(body.tab) ? body.tab : 'posts';
  let status = typeof body.status === 'string' ? body.status : '';
  if (tab === 'reports') {
    if (status && !REPORT_STATUSES.includes(status)) status = '';
  } else if (status && !POST_STATUSES.includes(status)) {
    status = '';
  }
  const page = Math.max(1, parseInt(body.page, 10) || 1);
  const query = new URLSearchParams({ tab, status, page: String(page), msg: msgKey });
  res.redirect('/admin/community-manage?' + query.toString());
}

router.get('/', (req, res) => {
  const tab = TABS.includes(String(req.query.tab)) ? String(req.query.tab) : 'posts';
  const rawStatus = typeof req.query.status === 'string' ? req.query.status : null;
  let status = '';
  if (tab === 'reports') {
    status = rawStatus === null ? 'open' : (REPORT_STATUSES.includes(rawStatus) ? rawStatus : '');
  } else {
    status = rawStatus && POST_STATUSES.includes(rawStatus) ? rawStatus : '';
  }
  const page = Math.max(1, Math.min(100000, parseInt(req.query.page, 10) || 1));

  const stats = {
    posts: Number((db.get('SELECT COUNT(*) AS c FROM community_posts') || {}).c) || 0,
    comments: Number((db.get('SELECT COUNT(*) AS c FROM community_comments') || {}).c) || 0,
    reportsOpen: Number((db.get("SELECT COUNT(*) AS c FROM community_reports WHERE status='open'") || {}).c) || 0
  };

  let total = 0;
  let rows = [];
  const params = [];
  if (tab === 'posts') {
    const where = status ? ' WHERE p.status=?' : '';
    if (status) params.push(status);
    total = Number((db.get('SELECT COUNT(*) AS c FROM community_posts p' + where, params) || {}).c) || 0;
    rows = db.query(
      'SELECT p.*, s.name AS s_name, s.nickname AS s_nickname FROM community_posts p' +
        ' LEFT JOIN students s ON s.id = p.student_id' + where +
        ' ORDER BY p.created_at DESC, p.id DESC LIMIT ? OFFSET ?',
      params.concat([PAGE_SIZE, (page - 1) * PAGE_SIZE])
    ).map(row => ({
      id: row.id,
      authorName: authorName(row),
      excerpt: excerpt(row.body, 80),
      likeCount: Number(row.like_count) || 0,
      commentCount: Number(row.comment_count) || 0,
      status: row.status,
      statusLabel: STATUS_LABELS[row.status] || row.status,
      createdAt: row.created_at
    }));
  } else if (tab === 'comments') {
    const where = status ? ' WHERE c.status=?' : '';
    if (status) params.push(status);
    total = Number((db.get('SELECT COUNT(*) AS c FROM community_comments c' + where, params) || {}).c) || 0;
    rows = db.query(
      'SELECT c.*, s.name AS s_name, s.nickname AS s_nickname, p.body AS post_body FROM community_comments c' +
        ' LEFT JOIN students s ON s.id = c.student_id' +
        ' LEFT JOIN community_posts p ON p.id = c.post_id' + where +
        ' ORDER BY c.created_at DESC, c.id DESC LIMIT ? OFFSET ?',
      params.concat([PAGE_SIZE, (page - 1) * PAGE_SIZE])
    ).map(row => ({
      id: row.id,
      postId: row.post_id,
      postExcerpt: excerpt(row.post_body, 40),
      authorName: authorName(row),
      excerpt: excerpt(row.body, 80),
      status: row.status,
      statusLabel: STATUS_LABELS[row.status] || row.status,
      createdAt: row.created_at
    }));
  } else {
    const where = status ? ' WHERE r.status=?' : '';
    if (status) params.push(status);
    total = Number((db.get('SELECT COUNT(*) AS c FROM community_reports r' + where, params) || {}).c) || 0;
    rows = db.query(
      "SELECT r.*, s.name AS s_name, s.nickname AS s_nickname," +
        " CASE r.target_type WHEN 'post' THEN (SELECT substr(p.body,1,60) FROM community_posts p WHERE p.id = r.target_id)" +
        " ELSE (SELECT substr(c.body,1,60) FROM community_comments c WHERE c.id = r.target_id) END AS target_body" +
        ' FROM community_reports r LEFT JOIN students s ON s.id = r.student_id' + where +
        ' ORDER BY r.created_at DESC, r.id DESC LIMIT ? OFFSET ?',
      params.concat([PAGE_SIZE, (page - 1) * PAGE_SIZE])
    ).map(row => ({
      id: row.id,
      targetType: row.target_type,
      typeLabel: TYPE_LABELS[row.target_type] || row.target_type,
      targetId: row.target_id,
      targetExcerpt: excerpt(row.target_body, 60),
      reporterName: authorName(row),
      reason: row.reason,
      detail: row.detail || '',
      status: row.status,
      statusLabel: STATUS_LABELS[row.status] || row.status,
      createdAt: row.created_at
    }));
  }

  const pageCount = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const safePage = Math.min(page, pageCount);
  res.render('teacher/community', {
    title: '社区管理',
    teacherName: req.session.teacherName || (req.adminAccount && req.adminAccount.display_name) || '管理员',
    stats,
    tab,
    status,
    page: safePage,
    pageCount,
    total,
    rows,
    msg: MESSAGES[String(req.query.msg || '')] || null,
    csrf: req.session.accountCsrf,
    accountCsrf: req.session.accountCsrf,
    cssVer: res.locals.cssVer || ''
  });
});

// 隐藏帖子：同步把其下已发布评论置 hidden。
router.post('/posts/:id/hide', csrf, (req, res) => {
  const id = positiveId(req.params.id);
  if (!id) return redirectBack(req, res, 'missing');
  const post = db.get('SELECT id FROM community_posts WHERE id=?', [id]);
  if (!post) return redirectBack(req, res, 'missing');
  db.atomic(() => {
    db.run("UPDATE community_posts SET status='hidden', updated_at=CURRENT_TIMESTAMP WHERE id=?", [id]);
    db.run("UPDATE community_comments SET status='hidden' WHERE post_id=? AND status='published'", [id]);
  });
  redirectBack(req, res, 'hidden');
});

// 恢复帖子：只恢复帖子本身；已隐藏的评论保持隐藏，避免绕过审核。
router.post('/posts/:id/show', csrf, (req, res) => {
  const id = positiveId(req.params.id);
  if (!id) return redirectBack(req, res, 'missing');
  const post = db.get('SELECT id, status FROM community_posts WHERE id=?', [id]);
  if (!post || post.status !== 'hidden') return redirectBack(req, res, 'missing');
  db.run("UPDATE community_posts SET status='published', updated_at=CURRENT_TIMESTAMP WHERE id=?", [id]);
  redirectBack(req, res, 'shown');
});

// 删除帖子（软删）：其下已发布评论置 hidden。
router.post('/posts/:id/delete', csrf, (req, res) => {
  const id = positiveId(req.params.id);
  if (!id) return redirectBack(req, res, 'missing');
  const post = db.get('SELECT id FROM community_posts WHERE id=?', [id]);
  if (!post) return redirectBack(req, res, 'missing');
  db.atomic(() => {
    db.run("UPDATE community_posts SET status='deleted', updated_at=CURRENT_TIMESTAMP WHERE id=?", [id]);
    db.run("UPDATE community_comments SET status='hidden' WHERE post_id=? AND status='published'", [id]);
  });
  redirectBack(req, res, 'post_deleted');
});

router.post('/comments/:id/hide', csrf, (req, res) => {
  const id = positiveId(req.params.id);
  if (!id) return redirectBack(req, res, 'missing');
  const comment = db.get('SELECT id FROM community_comments WHERE id=?', [id]);
  if (!comment) return redirectBack(req, res, 'missing');
  db.run("UPDATE community_comments SET status='hidden' WHERE id=?", [id]);
  redirectBack(req, res, 'comment_hidden');
});

router.post('/comments/:id/delete', csrf, (req, res) => {
  const id = positiveId(req.params.id);
  if (!id) return redirectBack(req, res, 'missing');
  const comment = db.get('SELECT id FROM community_comments WHERE id=?', [id]);
  if (!comment) return redirectBack(req, res, 'missing');
  db.run("UPDATE community_comments SET status='deleted' WHERE id=?", [id]);
  redirectBack(req, res, 'comment_deleted');
});

router.post('/reports/:id/resolve', csrf, (req, res) => {
  const id = positiveId(req.params.id);
  if (!id) return redirectBack(req, res, 'missing');
  const report = db.get('SELECT id FROM community_reports WHERE id=?', [id]);
  if (!report) return redirectBack(req, res, 'missing');
  db.run("UPDATE community_reports SET status='resolved' WHERE id=?", [id]);
  redirectBack(req, res, 'resolved');
});

module.exports = router;
