const express = require('express');
const db = require('../db');
const papers = require('../lib/past-papers');
const { requireStudentApi, currentStudent } = require('../middleware/student-auth');
const router = express.Router();
const fail = (res, status, error) => res.status(status).json({ ok: false, error });
function handle(fn) { return (req,res) => { try { fn(req,res); } catch(e) { console.error('[past-papers]', e.message); fail(res, e.status || 500, e.status ? e.message : '真题暂时无法读取，请稍后重试'); } }; }
function bad(message, status = 400) { throw Object.assign(new Error(message), { status }); }
function province(req) {
  const code = req.query.province || req.body && req.body.province || '61';
  if (typeof code !== 'string' || !/^(61|陕西)$/.test(code)) bad('当前仅开放陕西历年真题');
}
function run(req) {
  if (!/^[1-9]\d*$/.test(req.params.id)) bad('记录编号无效');
  const row = db.get('SELECT * FROM practice_paper_runs WHERE id=? AND student_id=?', [Number(req.params.id), req.student.id]);
  if (!row) bad('答卷不存在', 404);
  return row;
}
function grade(row) {
  if(row.mode==='study')bad('学习模式不交卷、不计考试成绩');
  if (row.status === 'submitted') return row;
  const paper = JSON.parse(row.snapshot), answers = JSON.parse(row.answers);
  let score = 0, objectivePoints = 0, subjectivePoints = 0, pendingPoints = 0;
  const items = papers.questions(paper).map(q => {
    const selected = answers[q.id] === undefined ? null : answers[q.id];
    const correct = q.type === 'choice' && q.answer !== null ? selected === q.answer : null;
    if (q.type === 'choice' && q.answer !== null) objectivePoints += q.points;
    if (q.type === 'text') subjectivePoints += q.points;
    if (q.answer === null) pendingPoints += q.points;
    const earned = correct ? q.points : 0; score += earned;
    return { questionId: q.id, selected, correct, earned, points: q.points, answer: q.answer, explanation: q.explanation };
  });
  const result = { score, objectivePoints, subjectivePoints, pendingPoints, items, durationSeconds: Math.round((Math.min(Date.now(), row.deadline) - row.started_at) / 1000) };
  db.run("UPDATE practice_paper_runs SET status='submitted',submitted_at=?,result=?,revision=revision+1 WHERE id=? AND status='open'", [Date.now(), JSON.stringify(result), row.id]);
  return db.get('SELECT * FROM practice_paper_runs WHERE id=?', [row.id]);
}
function payload(row) {
  if (row.mode!=='study' && row.status === 'open' && Date.now() >= row.deadline) row = grade(row);
  const review = row.status === 'submitted',study=row.mode==='study';
  const snapshot = JSON.parse(row.snapshot);
  const presentation = papers.withUpdatedPresentation(snapshot, papers.load().find(p => p.id === row.paper_id));
  return { ok: true, run: { id: row.id, mode:row.mode||'exam', paperId: row.paper_id, status: row.status, revision: row.revision, startedAt: row.started_at, deadline: study?null:row.deadline, serverNow: Date.now(), answers: JSON.parse(row.answers), workspace: JSON.parse(row.workspace || '{}'), result: review ? JSON.parse(row.result) : null }, paper: papers.publicPaper(presentation, review||study) };
}
function applyAnswers(row, body) {
  if (!body || !Number.isInteger(body.revision) || body.revision !== row.revision) bad('答卷已更新，请重新载入后继续', 409);
  if (!body.answers || typeof body.answers !== 'object' || Array.isArray(body.answers)) bad('答案格式无效');
  const map = new Map(papers.questions(JSON.parse(row.snapshot)).map(q => [q.id, q]));
  const answers = {};
  for (const [id, value] of Object.entries(body.answers)) {
    const q = map.get(id); if (!q) bad('题号不属于本套试卷');
    if (q.type === 'choice' ? !Number.isInteger(value) || value < 0 || value >= q.options.length : typeof value !== 'string' || value.length > 20000) bad('答案内容无效');
    answers[id] = value;
  }
  let workspace = JSON.parse(row.workspace || '{}');
  if (body.workspace !== undefined) {
    const incoming = body.workspace;
    if (!incoming || typeof incoming !== 'object' || Array.isArray(incoming) || !Array.isArray(incoming.flagged) || !incoming.notes || typeof incoming.notes !== 'object' || Array.isArray(incoming.notes)) bad('检查标记或笔记格式无效');
    if (incoming.flagged.length > map.size || new Set(incoming.flagged).size !== incoming.flagged.length || incoming.flagged.some(id => !map.has(id))) bad('检查标记题号无效');
    const notes = {};
    for (const [id,note] of Object.entries(incoming.notes)) {
      if (!map.has(id) || typeof note !== 'string' || note.length > 5000) bad('笔记题号或内容无效');
      notes[id] = note;
    }
    if (JSON.stringify(notes).length > 100000) bad('本卷笔记过长');
    const highlights = {};
    const incomingHighlights = incoming.highlights === undefined ? workspace.highlights : incoming.highlights;
    if (incomingHighlights !== undefined) {
      if (!incomingHighlights || typeof incomingHighlights !== 'object' || Array.isArray(incomingHighlights)) bad('文字标记格式无效');
      for (const [id, phrases] of Object.entries(incomingHighlights)) {
        if (!map.has(id) || !Array.isArray(phrases) || phrases.length > 60 || phrases.some(phrase => typeof phrase !== 'string' || !phrase.trim() || phrase.length > 500) || new Set(phrases).size !== phrases.length) bad('文字标记题号或内容无效');
        highlights[id] = phrases.slice();
      }
      if (JSON.stringify(highlights).length > 100000) bad('本卷文字标记过长');
    }
    let annotations = workspace.annotations;
    if (incoming.annotations !== undefined) {
      const snapshot = JSON.parse(row.snapshot);
      const presentation = papers.withUpdatedPresentation(snapshot, papers.load().find(p => p.id === row.paper_id));
      annotations = require('../lib/paper-annotations').validateAnnotations(incoming.annotations, presentation);
    }
    if (incoming.cursor !== undefined && (typeof incoming.cursor !== 'string' || !map.has(incoming.cursor))) bad('续答题号无效');
    workspace = { flagged: incoming.flagged.slice(), notes };
    if (incomingHighlights !== undefined) workspace.highlights = highlights;
    if (annotations !== undefined) workspace.annotations = annotations;
    if (incoming.cursor !== undefined) workspace.cursor = incoming.cursor;
  }
  db.run('UPDATE practice_paper_runs SET answers=?,workspace=?,revision=revision+1 WHERE id=?', [JSON.stringify(answers), JSON.stringify(workspace), row.id]);
  return db.get('SELECT * FROM practice_paper_runs WHERE id=?', [row.id]);
}
router.use((req,res,next) => { res.set('Cache-Control','no-store'); next(); });
router.get('/', handle((req,res) => {
  province(req);
  const all = papers.load();
  const subject = req.query.subject || '', year = req.query.year || '';
  if (typeof subject !== 'string' || (subject && !papers.SUBJECTS.includes(subject))) bad('科目无效');
  if (typeof year !== 'string' || (year && !/^\d{4}$/.test(year))) bad('年份无效');
  const student = currentStudent(req);
  const rows = student ? db.query("SELECT id,paper_id,status,started_at,deadline,result FROM practice_paper_runs WHERE student_id=? AND mode='exam' ORDER BY id DESC", [student.id]) : [];
  const latest = new Map(); rows.forEach(r => { if (!latest.has(r.paper_id)) latest.set(r.paper_id, r); });
  res.json({ ok: true, province: { code:'61', name:'陕西' }, subjects: papers.SUBJECTS, years: [...new Set(all.map(p => p.year))].sort((a,b) => b-a), total: all.length,
    papers: all.filter(p => (!subject || p.subject === subject) && (!year || p.year === Number(year))).sort((a,b) => b.year-a.year || a.subject.localeCompare(b.subject)).map(p => {
      const r = latest.get(p.id); const result = r && r.result ? JSON.parse(r.result) : null;
      return { ...papers.metadata(p), latestRun: r ? { id:r.id, status:r.status, score:result && result.score, objectivePoints: result && result.objectivePoints, pendingPoints: result && result.pendingPoints, expired:r.status === 'open' && Date.now() >= r.deadline } : null };
    }) });
}));
router.post('/:paperId/start', requireStudentApi, handle((req,res) => {
  province(req);
  const paper = papers.load().find(p => p.id === req.params.paperId); if (!paper) bad('试卷尚未录入或已下架',404);
  const requestedMode=req.body&&req.body.mode;const mode=requestedMode===undefined?'exam':requestedMode;if(!['exam','study'].includes(mode))bad('请选择考试模式或学习模式');
  let row = db.get("SELECT * FROM practice_paper_runs WHERE student_id=? AND paper_id=? AND mode=? AND status='open' ORDER BY id DESC LIMIT 1", [req.student.id,paper.id,mode]);
  if (!row) {
    const now = Date.now();
    const id = db.run('INSERT INTO practice_paper_runs(student_id,paper_id,snapshot,started_at,deadline,mode) VALUES(?,?,?,?,?,?)', [req.student.id,paper.id,JSON.stringify(paper),now,mode==='study'?Number.MAX_SAFE_INTEGER:now+paper.durationMinutes*60000,mode]);
    row = db.get('SELECT * FROM practice_paper_runs WHERE id=?',[id]);
  }
  res.json(payload(row));
}));
router.get('/runs/:id', requireStudentApi, handle((req,res) => { res.json(payload(run(req))); }));
router.post('/runs/:id/save', requireStudentApi, handle((req,res) => {
  let row = run(req);
  if (row.status === 'submitted' || row.mode!=='study' && Date.now() >= row.deadline) return res.json(payload(row));
  row = applyAnswers(row,req.body); res.json(payload(row));
}));
router.post('/runs/:id/submit', requireStudentApi, handle((req,res) => {
  let row = run(req);
  if(row.mode==='study')bad('学习模式不交卷、不计考试成绩');
  if (row.status === 'open' && Date.now() < row.deadline) row = applyAnswers(row,req.body);
  res.json(payload(grade(row)));
}));
const studyService=require('../lib/paper-study')(db);
function studyContext(req){const row=run(req);if(row.mode!=='study')bad('查词和语法分析仅限学习模式',403);const snapshot=JSON.parse(row.snapshot);return {row,paper:papers.withUpdatedPresentation(snapshot,papers.load().find(p=>p.id===row.paper_id))};}
router.use('/runs/:id/study',(req,res,next)=>{if(req.method==='POST'&&(!req.is('application/json')||!req.body||typeof req.body!=='object'||Array.isArray(req.body)))return fail(res,415,'请求格式无效');next();});
router.get('/runs/:id/study/capabilities',requireStudentApi,handle((req,res)=>{studyContext(req);res.json({ok:true,...studyService.capabilities()});}));
router.post('/runs/:id/study/lookup',requireStudentApi,handle((req,res)=>{const c=studyContext(req);res.json({ok:true,...studyService.lookup(req.student.id,c.paper,req.body)});}));
router.get('/runs/:id/study/words',requireStudentApi,handle((req,res)=>{const c=studyContext(req);res.json({ok:true,words:studyService.words(req.student.id,c.paper.id)});}));
router.post('/runs/:id/study/words',requireStudentApi,handle((req,res)=>{const c=studyContext(req);res.json({ok:true,...studyService.collect(req.student.id,c.paper,req.body)});}));
router.post('/runs/:id/study/words/:word/review',requireStudentApi,handle((req,res)=>{studyContext(req);res.json({ok:true,...studyService.review(req.student.id,req.params.word,req.body)});}));
router.post('/runs/:id/study/grammar',requireStudentApi,async(req,res)=>{try{const c=studyContext(req);res.json({ok:true,...await studyService.grammar(req.student.id,c.paper,req.body)});}catch(e){if(!e.status)console.error('[paper-study]',e.message);fail(res,e.status||500,e.status?e.message:'语法分析暂时不可用，请稍后重试');}});
module.exports = router;
