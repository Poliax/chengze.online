const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../db');

// Teacher login page
router.get('/login', (req, res) => {
  if (req.session.teacherId) {
    const account=require('../lib/admin-access').sessionAccount(db,req.session);
    if (account) return res.redirect(account.role==='ceo'?'/admin/dashboard':'/admin/workspace');
    for (const key of require('../lib/auth-session').adminKeys) delete req.session[key];
  }
  const error = req.session.adminLoginError || null;
  delete req.session.adminLoginError;
  res.set('Cache-Control', 'no-store');
  res.render('teacher/login', { title: '承泽在线 - 管理后台', error });
});

// Teacher login handler
function loginFailure(req, res, message) {
  req.session.adminLoginError = message;
  req.session.save(error => {
    if (error) return res.status(500).send('登录失败，请重试');
    res.redirect(303, '/admin/login');
  });
}

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return loginFailure(req, res, '请输入账号和密码');
  }

  const teacher = db.get('SELECT teacher_id AS id,login_username AS username,login_password_hash AS password_hash,login_display_name AS display_name,login_avatar AS avatar FROM admin_accounts WHERE login_username=?', [username]);
  
  if (!teacher) {
    return loginFailure(req, res, '账号或密码错误');
  }

  const account = require('../lib/admin-access').load(db, teacher.id);
  if (!account || account.status !== 'active') {
    return loginFailure(req, res, '账号或密码错误');
  }

  const valid = bcrypt.compareSync(password, teacher.password_hash);
  if (!valid) {
    return loginFailure(req, res, '账号或密码错误');
  }

  return require('../lib/auth-session').rotate(req, 'admin', err => {
  if (err) return res.status(500).send('登录失败，请重试');
  req.session.adminVersion = account.session_version;
  req.session.teacherId = teacher.id;
  req.session.teacherName = teacher.display_name;
  req.session.teacherAvatar = teacher.avatar;
  
  req.session.save(err => {
    if (err) return res.status(500).send('登录失败，请重试');
    res.redirect(account.role==='ceo'?'/admin/dashboard':'/admin/workspace');
  });
  });
});

function renderPassword(req, res, error = '', status = 200) {
  if (req.get('Accept') === 'application/json') return res.status(status).json({error});
  return res.status(status).render('teacher/change-password', { title:'修改密码 · 管理后台', error });
}

function requireSuperAdmin(req, res, next) {
  if (req.adminAccount?.role !== 'ceo' || req.adminAccount.username !== 'admin') return res.sendStatus(403);
  next();
}

router.get('/change-password', requireSuperAdmin, (req, res) => renderPassword(req, res));
router.post('/change-password', requireSuperAdmin, (req, res) => {
  const { _csrf, current_password, new_password, confirmation } = req.body || {};
  if (typeof _csrf !== 'string' || _csrf !== req.session.accountCsrf) return res.sendStatus(403);
  if (typeof new_password !== 'string' || new_password.length < 12 || Buffer.byteLength(new_password) > 72 || !new_password.trim()) {
    return renderPassword(req, res, '新密码至少 12 个字符，且不能超过 72 字节。', 400);
  }
  if (new_password !== confirmation) return renderPassword(req, res, '两次输入的新密码不一致。', 400);
  const id = req.adminAccount.teacher_id;
  const teacher = db.get('SELECT login_password_hash AS password_hash FROM admin_accounts WHERE teacher_id=?', [id]);
  if (typeof current_password !== 'string' || Buffer.byteLength(current_password) > 72 || !teacher?.password_hash || !bcrypt.compareSync(current_password, teacher.password_hash)) {
    return renderPassword(req, res, '当前密码不正确。', 400);
  }
  if (new_password === current_password) return renderPassword(req, res, '请输入与当前密码不同的新密码。', 400);
  const hash = bcrypt.hashSync(new_password, 12);
  db.atomic(() => {
    db.run('UPDATE admin_accounts SET login_password_hash=? WHERE teacher_id=?', [hash, id]);
    db.run('UPDATE admin_accounts SET session_version=session_version+1, updated_at=CURRENT_TIMESTAMP WHERE teacher_id=?', [id]);
    db.run('INSERT INTO admin_account_audit(actor_id,target_id,action,details) VALUES(?,?,?,?)', [id,id,'update','{"password_changed":true}']);
  });
  for (const key of require('../lib/auth-session').adminKeys) delete req.session[key];
  req.session.save(error => {
    if (error) return res.status(500).send('请重新登录');
    if (req.get('Accept') === 'application/json') return res.json({success:true});
    res.redirect('/admin/login');
  });
});

// Logout
router.get('/logout', (req, res) => {
  if (!req.session) return res.redirect('/admin/login');
  // Admin, teacher portal and student identities share this session cookie.
  // Signing out here must only remove the management identity.
  for (const key of ['teacherId', 'teacherName', 'teacherAvatar', 'adminVersion', 'accountCsrf', 'adminLoggedIn']) {
    delete req.session[key];
  }
  req.session.save(err => {
    if (err) return res.status(500).send('退出失败，请重试');
    res.redirect('/admin/login');
  });
});

module.exports = router;
