const express = require('express');
const db = require('../db');
const alipay = require('../lib/alipay-page');
const router = express.Router();
const actions = require('../lib/order-actions')({ db, alipay });

function requireStudent(req, res, next) {
  const id = Number(req.session && req.session.studentId);
  const student = Number.isSafeInteger(id) && id > 0 && db.get('SELECT id, status FROM students WHERE id=?', [id]);
  if (student && student.status !== 'disabled') return next();
  return res.status(401).json({ ok: false, error: '请先登录' });
}

const orderNumber = require('../lib/order-number');
const createCourseShipping = require('../lib/course-shipping');

function getOrderItem(body) {
  const packageId = parseInt(body.package_id) || 0;
  const courseId = parseInt(body.course_id) || 0;
  if (packageId) {
    const pkg = db.get("SELECT * FROM course_packages WHERE id=? AND status='published'", [packageId]);
    if (!pkg) return { error: '课程包不存在或未上架' };
    const amount = parseFloat(pkg.sale_price || pkg.price || 0);
    return { kind: 'package', package_id: packageId, title: pkg.title, amount: isNaN(amount) ? 0 : amount };
  }
  if (courseId) {
    const course = db.get("SELECT * FROM courses WHERE id=? AND status='published'", [courseId]);
    if (!course) return { error: '课程不存在或未上架' };
    const amount = parseFloat(course.sale_price || course.price || 0);
    return { kind: 'course', course_id: courseId, title: course.title, amount: isNaN(amount) ? 0 : amount };
  }
  return { error: '请选择要购买的商品' };
}

// ── 创建订单 ──
router.post('/orders', requireStudent, (req, res) => {
  const item = getOrderItem(req.body || {});
  if (item.error) return res.json({ ok: false, error: item.error });
  if (item.package_id && require('../lib/package-owned')(db, req.session.studentId, item.package_id)) {
    return res.status(409).json({ ok: false, error: '你已购买该班型，请进入学习' });
  }
  let number;
  try { number = orderNumber(item.course_id, item.package_id); }
  catch (error) { return res.status(400).json({ ok: false, error: error.message }); }
  const id = db.run('INSERT INTO orders (order_no, student_id, course_id, package_id, amount, status, payment_method) VALUES (?,?,?,?,?,?,?)',
    [number, req.session.studentId, item.course_id || null, item.package_id || 0, item.amount, 'pending', '']);
  const order = db.get('SELECT * FROM orders WHERE id=?', [id]);
  return res.json({ ok: true, order });
});

// ── 我的订单 ──
router.get('/orders', requireStudent, (req, res) => {
  const orders = db.query(`SELECT o.*, c.title as course_title, p.title as package_title, c.package_id as course_package_id, r.status as refund_status, r.review_note as refund_note
    FROM orders o
    LEFT JOIN courses c ON c.id=o.course_id
    LEFT JOIN course_packages p ON p.id=o.package_id
    LEFT JOIN order_refunds r ON r.order_id=o.id
    LEFT JOIN order_customer_state cs ON cs.order_id=o.id
    WHERE o.student_id=? AND o.status IN ('paid','refunded') AND cs.deleted_at IS NULL ORDER BY o.created_at DESC`, [req.session.studentId]);
  const items = orders.map(order => {
    let packageId = Number(order.package_id || order.course_package_id);
    let classPackage = null;
    const seen = new Set();
    while (packageId > 0 && !seen.has(packageId)) {
      seen.add(packageId);
      const pkg = db.get('SELECT id,title,parent_id,year,province,exam_type,class_type FROM course_packages WHERE id=?', [packageId]);
      if (!pkg) break;
      classPackage = pkg;
      packageId = Number(pkg.parent_id);
    }
    if (!classPackage) return order;
    const year = String(classPackage.year || '').replace(/年$/, '');
    const province = classPackage.province || '';
    const prefix = [year ? year + '年' : '', province, classPackage.exam_type || '专升本'].join('');
    const title = classPackage.title || '';
    const className = title.startsWith(prefix) ? title.slice(prefix.length) : title;
    return { ...order, class_year: year, class_province: province, class_name: className };
  });
  res.set('Cache-Control', 'private, no-store');
  return res.json({ ok: true, orders: items });
});

// ── 发起支付 ──
router.post('/orders/:id/pay', requireStudent, (req, res) => {
  const id = parseInt(req.params.id) || 0;
  const order = db.get('SELECT * FROM orders WHERE id=? AND student_id=?', [id, req.session.studentId]);
  if (!order) return res.status(404).json({ ok: false, error: '订单不存在' });
  if (order.status === 'paid') return res.json({ ok: true, order, alreadyPaid: true });
  if (order.status !== 'pending') return res.status(409).json({ ok: false, error: '订单无法支付' });
  if (db.get('SELECT deleted_at FROM order_customer_state WHERE order_id=? AND deleted_at IS NOT NULL', [id])) return res.status(409).json({ ok: false, error: '订单已删除' });
  if (req.body?.channel !== 'alipay') return res.status(400).json({ ok: false, error: '请选择支付宝' });
  if (!Number.isFinite(order.amount) || order.amount < 0.01) {
    return res.status(400).json({ ok: false, error: '订单金额无效' });
  }
  try {
    const config = alipay.configuration();
    if (config) {
      const item = order.package_id
        ? db.get('SELECT title FROM course_packages WHERE id=?', [order.package_id])
        : db.get('SELECT title FROM courses WHERE id=?', [order.course_id]);
      if (!item) return res.status(409).json({ ok: false, error: '订单商品不存在' });
      return res.json({ ok: true, paymentUrl: alipay.paymentUrl(config, order, item.title) });
    }
  } catch (error) {
    console.error('[Alipay] Could not prepare payment', error.code || error.name);
  }
  return res.status(503).json({ ok: false, error: '在线支付暂不可用，请稍后重试' });
});

router.delete('/orders/:id', requireStudent, async (req, res) => {
  try {
    await actions.remove(Number(req.params.id), req.session.studentId);
    return res.json({ ok: true });
  } catch (error) {
    return res.status(error.status || 503).json({ ok: false, error: error.status ? error.message : '订单暂时无法删除，请稍后重试' });
  }
});

router.post('/orders/:id/refund', requireStudent, (req, res) => {
  if (!req.is('application/json')) return res.status(415).json({ ok: false, error: '请求格式无效' });
  try {
    const refund = actions.apply(Number(req.params.id), req.session.studentId, req.body.reason);
    return res.json({ ok: true, refund });
  } catch (error) {
    return res.status(error.status || 503).json({ ok: false, error: error.status ? error.message : '退款申请暂时无法提交，请稍后重试' });
  }
});

router.post('/pay/notify/alipay', (req, res) => {
  const fail = () => res.type('text').send('failure');
  try {
    const config = alipay.configuration();
    const body = req.body || {};
    if (!config || !alipay.verifyNotification(config, body)) return fail();
    if (!['TRADE_SUCCESS', 'TRADE_FINISHED', 'TRADE_CLOSED'].includes(body.trade_status)) return fail();
    if (!body.out_trade_no || !body.trade_no || !/^\d+(?:\.\d{1,2})?$/.test(body.total_amount)) return fail();
    const accepted = db.atomic(() => {
      const order = db.get('SELECT * FROM orders WHERE order_no=?', [body.out_trade_no]);
      if (!order || order.amount < 0.01 || Number(body.total_amount).toFixed(2) !== Number(order.amount).toFixed(2)) return false;
      if (body.trade_status === 'TRADE_CLOSED') return ['cancelled', 'refunded'].includes(order.status) && (!order.trade_no || order.trade_no === body.trade_no);
      if (['paid', 'refunded'].includes(order.status)) return order.payment_method === 'alipay' && order.trade_no === body.trade_no;
      if (order.status !== 'pending' && !(order.status === 'cancelled' && db.get('SELECT deleted_at FROM order_customer_state WHERE order_id=? AND deleted_at IS NOT NULL', [order.id]))) return false;
      if (db.get("SELECT id FROM orders WHERE payment_method='alipay' AND trade_no=?", [body.trade_no])) return false;
      const grantTable = order.package_id ? 'package_enrollments' : 'enrollments';
      const grantColumn = order.package_id ? 'package_id' : 'course_id';
      const itemId = order.package_id || order.course_id;
      const existingGrant = db.get('SELECT id FROM ' + grantTable + ' WHERE student_id=? AND ' + grantColumn + '=?', [order.student_id, itemId]);
      if (order.package_id) {
        if (!db.get('SELECT id FROM course_packages WHERE id=?', [order.package_id])) return false;
        db.run('INSERT OR IGNORE INTO package_enrollments (student_id, package_id, order_id) VALUES (?,?,?)',
          [order.student_id, order.package_id, order.id]);
      } else {
        if (!db.get('SELECT id FROM courses WHERE id=?', [order.course_id])) return false;
        db.run('INSERT OR IGNORE INTO enrollments (student_id, course_id) VALUES (?,?)',
          [order.student_id, order.course_id]);
      }
      const grant = db.get('SELECT id FROM ' + grantTable + ' WHERE student_id=? AND ' + grantColumn + '=?', [order.student_id, itemId]);
      db.run('INSERT OR IGNORE INTO order_payment_grants (order_id,enrollment_id,created_by_payment) VALUES (?,?,?)',
        [order.id, grant.id, existingGrant ? 0 : 1]);
      createCourseShipping(db, {studentId:order.student_id, courseId:order.course_id, packageId:order.package_id, number:'LG-P-'+order.order_no});
      db.run('DELETE FROM order_customer_state WHERE order_id=?', [order.id]);
      db.run("UPDATE orders SET status='paid', payment_method='alipay', trade_no=?, paid_at=CURRENT_TIMESTAMP WHERE id=?",
        [body.trade_no, order.id]);
      return true;
    });
    return res.type('text').send(accepted ? 'success' : 'failure');
  } catch (error) {
    console.error('[Alipay] Could not process notification', error.code || error.name);
    return fail();
  }
});

module.exports = router;
