const router=require('express').Router(),db=require('../db');
router.get('/:id', (req,res)=>{
  if(!/^\d+$/.test(req.params.id))return res.status(404).send('公告不存在');
  const item=db.get(`SELECT r.title,r.year,p.name AS province,n.* FROM notice_items n
    JOIN province_resources r ON r.id=n.resource_id JOIN provinces p ON p.id=r.province_id
    WHERE r.id=? AND r.kind='notice' AND r.status='published' AND (n.published_on='' OR n.published_on>=?)`,[Number(req.params.id),require('../lib/official-notices').cutoffDate()]);
  res.set('Cache-Control','no-store');
  if(!item)return res.status(404).send('公告不存在或已下架');
  res.render('student/official-notice',{item});
});
module.exports=router;
