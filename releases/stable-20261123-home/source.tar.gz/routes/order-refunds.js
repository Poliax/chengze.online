const crypto = require('crypto');
const express = require('express');

module.exports = function orderRefunds(db, actions) {
  const router = express.Router();
  function render(req, res, message = '', status = 200) {
    if (!req.session.refundReviewToken) req.session.refundReviewToken = crypto.randomBytes(32).toString('hex');
    const refunds = db.query(`SELECT r.*,o.order_no,o.student_id,o.course_id,o.package_id,o.payment_method,o.trade_no,
      s.name AS student_name,c.title AS course_title,p.title AS package_title,
      g.created_by_payment
      FROM order_refunds r JOIN orders o ON o.id=r.order_id
      LEFT JOIN students s ON s.id=o.student_id LEFT JOIN courses c ON c.id=o.course_id
      LEFT JOIN course_packages p ON p.id=o.package_id LEFT JOIN order_payment_grants g ON g.order_id=o.id
      ORDER BY CASE r.status WHEN 'processing' THEN 0 WHEN 'requested' THEN 1 ELSE 2 END,r.updated_at DESC`);
    res.set('Cache-Control', 'private, no-store');
    return res.status(status).render('teacher/order-refunds', {
      title: '退款审核 · 管理后台', teacherName: req.session.teacherName,
      refunds, token: req.session.refundReviewToken, message
    });
  }
  router.get('/refunds', (req, res) => render(req, res));
  router.post('/:id/refund-review', async (req, res) => {
    if (!req.session.refundReviewToken || req.body.token !== req.session.refundReviewToken) {
      return res.status(403).send('页面已失效，请刷新后重试');
    }
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).send('订单无效');
    try {
      if (req.body.decision === 'approve') {
        await actions.approve(id, req.session.teacherId, req.body.revoke_access === '1');
      } else if (req.body.decision === 'reject') {
        actions.reject(id, req.session.teacherId, req.body.note);
      } else {
        return res.status(400).send('请选择审核操作');
      }
      return res.redirect('/admin/orders-manage/refunds');
    } catch (error) {
      console.warn('[Refund review] Could not complete', error.status || 'unknown');
      return render(req, res, error.status ? error.message : '退款结果暂时无法确认，请稍后核对并重试', error.status || 502);
    }
  });
  return router;
};
