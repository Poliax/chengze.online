const db=require('../db');
module.exports=(req,res)=>{
 res.set('Cache-Control','private, no-store');
 if(!req.session.studentId)return res.status(401).json({error:'请先登录'});
 if(req.query.activity==='1'){
  const student=db.get('SELECT id,status FROM students WHERE id=?',[req.session.studentId]);
  if(!student||student.status==='disabled')return res.status(401).json({error:'登录已失效'});
  const today=require('../lib/learning-activity').dateKey();
  const since=today.slice(0,4)+'-01-01';
  return res.json({today,days:db.query('SELECT study_date AS date,SUM(seconds) AS seconds,COUNT(*) AS lessons FROM student_learning_activity WHERE student_id=? AND study_date>=? AND study_date<=? GROUP BY study_date ORDER BY study_date',[req.session.studentId,since,today])});
 }
 if(req.query.session){const id=Number(req.query.session);if(!Number.isSafeInteger(id)||id<=0)return res.status(400).json({error:'场次无效'});return res.json({progress:db.query('SELECT lesson_id,session_id,completed,watch_duration,last_position FROM replay_session_progress WHERE student_id=? AND session_id=?',[req.session.studentId,id])});}
 const ids=db.query('SELECT lesson_id FROM course_progress WHERE student_id=? UNION SELECT lesson_id FROM replay_session_progress WHERE student_id=?',[req.session.studentId,req.session.studentId]);
 const progress=ids.map(row=>({lesson_id:row.lesson_id,...(require('../lib/lesson-version-progress')(db,req.session.studentId,row.lesson_id)||{completed:0,watch_duration:0,last_position:0})}));
 res.json({progress});
};
