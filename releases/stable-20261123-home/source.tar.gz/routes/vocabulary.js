const router=require('express').Router();
const service=require('../lib/vocabulary')(require('../db'));
const {requireStudentApi}=require('../middleware/student-auth');
router.use((req,res,next)=>{res.set('Cache-Control','private, no-store');next();});
router.use(requireStudentApi);
// Requests carry JSON; reject browser form submissions to mutating endpoints.
router.use((req,res,next)=>{if(req.method==='POST'&&(!req.is('application/json')||!req.body||typeof req.body!=='object'||Array.isArray(req.body)))return res.status(415).json({ok:false,error:'请求格式无效'});next();});
const handle=fn=>(req,res)=>{try{res.json({ok:true,...fn(req)});}catch(e){if(!e.status)console.error('[vocabulary]',e.message);res.status(e.status||500).json({ok:false,error:e.status?e.message:'单词学习暂时不可用，请稍后重试'});}};
router.get('/summary',handle(req=>service.summary(req.student.id)));
router.post('/settings',handle(req=>service.setting(req.student.id,req.body.goal)));
router.post('/sessions',handle(req=>({session:service.start(req.student.id,req.body.mode)})));
router.get('/sessions/:id',handle(req=>({session:service.current(req.student.id,req.params.id)})));
router.post('/sessions/:id/reveal',handle(req=>({session:service.reveal(req.student.id,req.params.id,req.body.index)})));
router.post('/sessions/:id/answer',handle(req=>service.answer(req.student.id,req.params.id,req.body)));
router.get('/words',handle(req=>({words:service.list(req.student.id,req.query.filter,req.query.q)})));
router.post('/words/:id/favorite',handle(req=>service.favorite(req.student.id,req.params.id,req.body.favorite)));
module.exports=router;
