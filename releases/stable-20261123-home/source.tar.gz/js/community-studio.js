// 社区 v2 广场（学员端）：五条流（推荐/关注/同路人/树洞/热门）+ 帖子/瞬间/匿名发布 +
// 点赞/收藏/评论（楼中楼）/举报/删除。纯 DOM API 与 textContent 注入，不拼 HTML。
// 注册到 CZCommunityShell 的 plaza 页签；保留 window.CommunityStudio = { refresh } 导出。
(function () {
  'use strict';

  var API = '/api/community';
  var C = window.CZCommunity;
  if (!C) return;

  var FLOWS = [
    { key: 'recommend', label: '推荐' },
    { key: 'following', label: '关注' },
    { key: 'peer', label: '同路人' },
    { key: 'treehole', label: '树洞' },
    { key: 'hot', label: '热门' }
  ];
  var REASONS = ['广告骚扰', '联系方式', '辱骂攻击', '违法违规', '其他'];
  var FALLBACK_TAGS = ['上岸喜报', '学习打卡', '资料分享', '找学习搭子', '备考建议', '其他'];
  var PAGE_SIZE = 10;
  var TOPICS = [
    { icon: '✦', title: '今天也有小进步', text: '背了几个词，也值得被看见', tag: '学习打卡', prompt: '今天的小进步：', tone: 'sage' },
    { icon: '↗', title: '上岸经验交换站', text: '走过的弯路，变成别人的捷径', tag: '备考建议', prompt: '想分享一个备考小方法：', tone: 'peach' },
    { icon: '☁', title: '给心情放个假', text: '开心或低落，这里都接得住', flow: 'treehole', prompt: '此刻想说：', anonymous: true, tone: 'lilac' }
  ];
  var EMPTY_TEXT = {
    recommend: '还没有人分享，来发第一条备考记录吧',
    following: '关注的人还没有发布内容，去「找搭子」发现同路人',
    peer: '登录并完善省份/考试年份后，才能看到同路人',
    treehole: '树洞里还没有匿名分享，说出你的心里话吧',
    hot: '近 7 天还没有热门内容，先来发一条吧'
  };

  var state = {
    tab: 'recommend',
    tag: '',
    tags: FALLBACK_TAGS.slice(),
    page: 1,
    total: 0,
    loading: false,
    seq: 0
  };
  var root = null;
  var refs = {};
  var openComposer = function () {};

  // ── 小工具 ──
  function el(tag, className, text) {
    return C.el(tag, className, text);
  }

  function setText(node, text) {
    node.textContent = text === undefined || text === null ? '' : String(text);
  }

  function charCount(text) {
    return Array.from(String(text === undefined || text === null ? '' : text)).length;
  }

  function avatarNode(item, size) {
    if (!item || item.isAnonymous) {
      return C.avatarEl({ id: 0, name: '匿名同学' }, size || 40);
    }
    return C.avatarEl({ id: item.authorId, name: item.authorName, avatar: item.authorAvatar, gender:item.authorGender }, size || 40);
  }

  function button(className, text, onClick) {
    var node = el('button', className, text);
    node.type = 'button';
    if (onClick) node.addEventListener('click', onClick);
    return node;
  }

  function errorMessage(response, fallback) {
    if (response && response.data && response.data.error) return response.data.error;
    if (response && response.status === 401) return '请先登录';
    return fallback || '加载失败，请稍后重试';
  }

  // ── 页面骨架 ──
  function render(container) {
    root = container || document.getElementById('communityBox');
    if (!root) return;
    root.classList.add('cm-root', 'cm-plaza');
    C.clear(root);

    root.appendChild(buildWelcome());
    root.appendChild(buildTopics());
    var layout = el('div', 'cm-plaza-layout');
    var main = el('div', 'cm-plaza-main');
    root.appendChild(layout);
    layout.appendChild(main);
    main.appendChild(buildHead());

    refs.composeSlot = el('div', 'cm-compose-slot');
    main.appendChild(refs.composeSlot);
    renderComposer();

    refs.tagbar = el('div', 'cm-tagbar');
    main.appendChild(refs.tagbar);
    renderTagbar();

    refs.feed = el('div', 'cm-feed');
    refs.errorBox = el('div', 'cm-feed-error');
    refs.errorBox.hidden = true;
    refs.loadingBox = el('div', 'cm-feed-loading');
    refs.loadingBox.hidden = true;
    refs.emptyBox = el('div', 'cm-feed-empty');
    refs.emptyBox.hidden = true;
    refs.list = el('div', 'cm-post-list');
    refs.more = button('cm-feed-more', '加载更多');
    refs.more.hidden = true;
    refs.more.addEventListener('click', function () {
      if (state.loading) return;
      loadFeed(state.page + 1, true);
    });
    refs.feed.appendChild(refs.errorBox);
    refs.feed.appendChild(refs.loadingBox);
    refs.feed.appendChild(refs.emptyBox);
    refs.feed.appendChild(refs.list);
    refs.feed.appendChild(refs.more);
    main.appendChild(refs.feed);
    layout.appendChild(buildSide());

    loadFeed(1, false);
  }

  function compose(options) {
    if (!C.requireLogin('分享')) return;
    openComposer(options || {});
    if (refs.composeSlot) refs.composeSlot.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function buildWelcome() {
    var hero = el('section', 'cm-welcome');
    var copy = el('div', 'cm-welcome-copy');
    copy.appendChild(el('span', 'cm-eyebrow', 'OUR LITTLE CORNER · 备考生活，也有回声'));
    var title = el('h3', 'cm-welcome-title', '一起上岸，也一起闪光。');
    copy.appendChild(title);
    copy.appendChild(el('p', 'cm-welcome-sub', '分享一点日常，遇见同频的人。这里的每一步，都有人懂。'));
    var actions = el('div', 'cm-welcome-actions');
    actions.appendChild(button('cm-hero-primary', '＋ 分享此刻', function () { compose(); }));
    actions.appendChild(button('cm-hero-secondary', '找个学习搭子 ↗', function () { window.CZCommunityShell.show('partner'); }));
    copy.appendChild(actions);
    hero.appendChild(copy);
    var art = el('div', 'cm-welcome-art');
    art.setAttribute('aria-hidden', 'true');
    art.appendChild(el('span', 'cm-art-orbit'));
    art.appendChild(el('span', 'cm-art-spark', '✦'));
    art.appendChild(el('span', 'cm-art-note cm-art-note-one', '慢慢来，比较快'));
    art.appendChild(el('span', 'cm-art-note cm-art-note-two', '今天也在发光 ✧'));
    hero.appendChild(art);
    return hero;
  }

  function buildTopics() {
    var wrap = el('section', 'cm-discover');
    wrap.setAttribute('aria-label', '话题灵感');
    TOPICS.forEach(function (topic) {
      var entry = button('cm-topic-card cm-topic-' + topic.tone, null, function () {
        state.tag = topic.tag || '';
        renderTagbar();
        if (topic.flow && state.tab !== topic.flow) selectFlow(topic.flow);
        else loadFeed(1, false);
      });
      entry.appendChild(el('span', 'cm-topic-icon', topic.icon));
      var copy = el('span', 'cm-topic-copy');
      copy.appendChild(el('strong', 'cm-topic-title', topic.title));
      copy.appendChild(el('span', 'cm-topic-sub', topic.text));
      entry.appendChild(copy);
      entry.appendChild(el('span', 'cm-topic-arrow', '↗'));
      wrap.appendChild(entry);
    });
    return wrap;
  }

  function buildSide() {
    var side = el('aside', 'cm-plaza-side');
    side.setAttribute('aria-label', '社区灵感与指南');
    var daily = el('section', 'cm-side-card cm-daily');
    daily.appendChild(el('span', 'cm-eyebrow', 'ONE SMALL STEP'));
    daily.appendChild(el('h4', 'cm-side-title', '今天的努力，算数。'));
    daily.appendChild(el('p', 'cm-side-text', '不用等到满分才庆祝。记录一次坚持，给明天的自己一点力量。'));
    daily.appendChild(button('cm-side-button', '去打卡 · 积攒成长 ↗', function () { window.CZCommunityShell.show('me'); }));
    side.appendChild(daily);
    var prompt = el('section', 'cm-side-card');
    prompt.appendChild(el('span', 'cm-eyebrow', 'TALK OF THE DAY'));
    // 按日期轮换编辑话题，不虚构热度或参与人数。
    var topic = TOPICS[Math.floor(Date.now() / 86400000) % TOPICS.length];
    prompt.appendChild(el('h4', 'cm-side-title', topic.title));
    prompt.appendChild(el('p', 'cm-side-text', topic.text));
    prompt.appendChild(button('cm-side-link', '我也想说两句 →', function () {
      compose({ text: topic.prompt, tag: topic.tag, anonymous: topic.anonymous });
    }));
    side.appendChild(prompt);
    var guide = el('section', 'cm-side-card cm-community-note');
    guide.appendChild(el('h4', 'cm-side-title', '在这里，安心做自己'));
    ['友善回应，给每一种努力留点空间。', '树洞匿名表达，不展示个人身份。', '保护隐私，遇到不适内容可以举报。'].forEach(function (text) {
      guide.appendChild(el('p', 'cm-side-text', text));
    });
    side.appendChild(guide);
    return side;
  }

  function buildHead() {
    var head = el('div', 'cm-plaza-head');
    var pills = el('div', 'cm-flow-pills');
    FLOWS.forEach(function (flow) {
      var active = state.tab === flow.key;
      var pill = button('cm-flow-pill' + (active ? ' active' : ''), flow.label, function () {
        selectFlow(flow.key);
      });
      pill.dataset.flow = flow.key;
      pill.setAttribute('aria-pressed', String(active));
      pills.appendChild(pill);
    });
    head.appendChild(pills);
    var publish = button('cm-publish-entry', '＋ 发布', function () {
      if (!C.requireLogin('发布')) return;
      openComposer();
    });
    head.appendChild(publish);
    return head;
  }

  function selectFlow(key) {
    if (state.tab === key) return;
    if ((key === 'following' || key === 'peer') && !C.signedIn()) {
      C.requireLogin('查看关注');
    }
    state.tab = key;
    state.page = 1;
    var pills = root.querySelectorAll('.cm-flow-pill');
    Array.prototype.forEach.call(pills, function (pill) {
      pill.classList.toggle('active', pill.dataset.flow === key);
      pill.setAttribute('aria-pressed', String(pill.dataset.flow === key));
    });
    loadFeed(1, false);
  }

  // ── 发布区 ──
  function renderComposer() {
    openComposer = function () { C.requireLogin('分享'); };
    refs.updateTagChoices = null;
    var slot = refs.composeSlot;
    if (!slot) return;
    C.clear(slot);
    if (!C.signedIn()) {
      var guest = el('div', 'cm-compose-guest');
      guest.appendChild(el('span', 'cm-compose-guest-text', '登录后可以发布帖子、瞬间或匿名树洞'));
      guest.appendChild(button('cm-compose-login', '登录 / 注册', function () {
        C.requireLogin('登录');
      }));
      slot.appendChild(guest);
      return;
    }

    var viewer = C.viewer();
    var trigger = button('cm-compose-trigger');
    trigger.appendChild(C.avatarEl(viewer, 32));
    trigger.appendChild(el('span', 'cm-compose-trigger-text', '分享你的备考日常、上岸喜报或此刻心情…'));
    slot.appendChild(trigger);

    var card = el('div', 'cm-compose-card');
    card.hidden = true;
    var textarea = el('textarea', 'cm-compose-textarea');
    textarea.setAttribute('aria-label', '分享内容');
    textarea.rows = 3;
    textarea.maxLength = 500;
    textarea.placeholder = '写下你的备考记录、上岸喜报或此刻心情…（5–500 字）';
    var counter = el('span', 'cm-compose-count', '0/500');
    textarea.addEventListener('input', function () {
      setText(counter, charCount(textarea.value) + '/500');
    });

    var moods = el('div', 'cm-moods');
    moods.appendChild(el('span', 'cm-mood-label', '此刻心情'));
    var moodOptions = ['☀ 元气满满', '✦ 小有进步', '☁ 想歇一歇', '♡ 需要鼓励'];
    var mood = '';
    moodOptions.forEach(function (label) {
      var chip = button('cm-mood-chip', label, function () {
        mood = mood === label ? '' : label;
        Array.prototype.forEach.call(moods.querySelectorAll('button'), function (item) {
          item.classList.toggle('active', item.textContent === mood);
          item.setAttribute('aria-pressed', String(item.textContent === mood));
        });
      });
      chip.setAttribute('aria-pressed', 'false');
      moods.appendChild(chip);
    });
    var selected = [];
    var tagBox = el('div', 'cm-compose-tags');
    function renderTagChoices() {
      C.clear(tagBox);
      state.tags.forEach(function (tag) {
        var chip = button('cm-tag-choice' + (selected.indexOf(tag) !== -1 ? ' active' : ''), tag, function () {
          var at = selected.indexOf(tag);
          if (at === -1) {
            if (selected.length >= 3) return C.toast('最多选择 3 个标签');
            selected.push(tag);
          } else {
            selected.splice(at, 1);
          }
          renderTagChoices();
        });
        tagBox.appendChild(chip);
      });
    }
    refs.updateTagChoices = renderTagChoices;
    renderTagChoices();

    var anonLabel = el('label', 'cm-anon-toggle');
    var anonInput = document.createElement('input');
    anonInput.type = 'checkbox';
    anonInput.className = 'cm-anon-input';
    anonLabel.appendChild(anonInput);
    anonLabel.appendChild(el('span', 'cm-anon-text', '匿名发布（树洞）'));

    var foot = el('div', 'cm-compose-foot');
    foot.appendChild(counter);
    foot.appendChild(el('span', 'cm-compose-hint', '5–500 字 · 最多 3 个标签'));
    foot.appendChild(anonLabel);
    var cancel = button('cm-compose-cancel', '收起');
    cancel.addEventListener('click', function () {
      card.hidden = true;
    });
    foot.appendChild(cancel);
    var momentBtn = button('cm-publish-moment', '发布瞬间', function () { submit('moment'); });
    var postBtn = button('cm-publish-post', '发布', function () { submit('post'); });
    foot.appendChild(momentBtn);
    foot.appendChild(postBtn);

    var note = el('div', 'cm-compose-note', '「发布瞬间」24 小时后自动消失，适合记录每天的小进度。');
    var busy = false;

    function submit(kind) {
      if (busy) return;
      var body = textarea.value.trim();
      var length = charCount(body);
      if (mood) body = mood + '\n' + body;
      if (length < 5) return C.toast('内容至少 5 个字');
      if (charCount(body) > 500) return C.toast('内容最多 500 个字');
      busy = true;
      postBtn.disabled = true;
      momentBtn.disabled = true;
      var payload = { body: body, tags: selected.slice(), kind: kind, anonymous: !!anonInput.checked };
      C.request(API + '/posts', { method: 'POST', body: payload }).then(function (response) {
        if (!response.ok) {
          C.toast(errorMessage(response, '发布失败，请稍后重试'));
          return;
        }
        textarea.value = '';
        mood = '';
        Array.prototype.forEach.call(moods.querySelectorAll('button'), function (item) {
          item.classList.remove('active');
          item.setAttribute('aria-pressed', 'false');
        });
        setText(counter, '0/500');
        selected = [];
        renderTagChoices();
        anonInput.checked = false;
        card.hidden = true;
        C.toast(kind === 'moment' ? '瞬间已发布，24 小时后自动消失' : '发布成功');
        loadFeed(1, false);
      }).finally(function () {
        busy = false;
        postBtn.disabled = false;
        momentBtn.disabled = false;
      });
    }

    card.appendChild(moods);
    card.appendChild(textarea);
    card.appendChild(tagBox);
    card.appendChild(foot);
    card.appendChild(note);
    slot.appendChild(card);

    openComposer = function (options) {
      options = options || {};
      // 话题入口不覆盖用户已经输入的草稿。
      if (options.text && !textarea.value.trim()) textarea.value = options.text;
      if (options.tag && state.tags.indexOf(options.tag) >= 0 && selected.indexOf(options.tag) < 0 && selected.length < 3) {
        selected.push(options.tag);
        renderTagChoices();
      }
      if (options.anonymous || state.tab === 'treehole') anonInput.checked = true;
      setText(counter, charCount(textarea.value) + '/500');
      card.hidden = false;
      textarea.focus();
    };
    trigger.addEventListener('click', openComposer);
  }

  // ── 标签筛选 ──
  function renderTagbar() {
    var bar = refs.tagbar;
    if (!bar) return;
    C.clear(bar);
    var all = button('cm-tag-pill' + (state.tag === '' ? ' active' : ''), '全部', function () {
      selectTag('');
    });
    all.setAttribute('aria-pressed', String(state.tag === ''));
    bar.appendChild(all);
    state.tags.forEach(function (tag) {
      var pill = button('cm-tag-pill' + (state.tag === tag ? ' active' : ''), tag, function () {
        selectTag(tag);
      });
      pill.setAttribute('aria-pressed', String(state.tag === tag));
      bar.appendChild(pill);
    });
  }

  function selectTag(tag) {
    if (state.tag === tag) return;
    state.tag = tag;
    state.page = 1;
    renderTagbar();
    loadFeed(1, false);
  }

  // ── 信息流 ──
  function showLoading() {
    C.clear(refs.loadingBox);
    refs.loadingBox.appendChild(C.loadingEl('社区加载中…'));
    refs.loadingBox.hidden = false;
  }

  function hideStates() {
    refs.errorBox.hidden = true;
    refs.loadingBox.hidden = true;
    refs.emptyBox.hidden = true;
  }

  function showError(message) {
    C.clear(refs.errorBox);
    refs.errorBox.appendChild(el('span', 'cm-feed-error-text', message));
    refs.errorBox.appendChild(button('cm-feed-retry', '重试', function () {
      loadFeed(state.page || 1, false);
    }));
    refs.errorBox.hidden = false;
  }

  function showLoginGate(message) {
    C.clear(refs.emptyBox);
    refs.emptyBox.appendChild(el('p', 'cm-feed-empty-text', message));
    refs.emptyBox.appendChild(button('cm-feed-login', '去登录', function () {
      C.requireLogin('登录');
    }));
    refs.emptyBox.hidden = false;
  }

  function showEmpty(message) {
    C.clear(refs.emptyBox);
    refs.emptyBox.appendChild(el('span', 'cm-empty-symbol', '✧'));
    refs.emptyBox.appendChild(el('h4', 'cm-empty-title', '这里，等你的第一声回响'));
    refs.emptyBox.appendChild(el('p', 'cm-feed-empty-text', message));
    var publish = button('cm-feed-empty-publish', '发一条', function () {
      if (!C.requireLogin('发布')) return;
      openComposer();
    });
    refs.emptyBox.appendChild(publish);
    refs.emptyBox.hidden = false;
  }

  function loadFeed(page, append) {
    if (append && state.loading) return;
    if (state.tab === 'following' && !C.signedIn()) {
      state.seq += 1; // 让仍在路上的请求失效，避免覆盖登录引导
      state.loading = false;
      C.clear(refs.list);
      C.clear(refs.loadingBox);
      refs.loadingBox.hidden = true;
      refs.emptyBox.hidden = true;
      refs.more.hidden = true;
      showLoginGate('登录后查看你关注的人的最新动态');
      return;
    }
    state.loading = true;
    var seq = (state.seq += 1);
    hideStates();
    refs.more.hidden = true;
    if (!append) {
      C.clear(refs.list);
      showLoading();
    }
    var url = API + '/feed?tab=' + encodeURIComponent(state.tab) + '&page=' + page + '&pageSize=' + PAGE_SIZE;
    if (state.tag) url += '&tag=' + encodeURIComponent(state.tag);
    C.request(url).then(function (response) {
      if (seq !== state.seq) return;
      refs.loadingBox.hidden = true;
      if (!response.ok) {
        if (response.status === 401) showLoginGate('请先登录后再查看');
        else showError(errorMessage(response));
        return;
      }
      var data = response.data || {};
      state.page = Number(data.page) || page;
      state.total = Number(data.total) || 0;
      if (Array.isArray(data.tags) && data.tags.length && data.tags.join('|') !== state.tags.join('|')) {
        state.tags = data.tags.slice();
        renderTagbar();
        // 标签更新不重建发布器，保留正在输入的草稿。
        if (refs.updateTagChoices) refs.updateTagChoices();
      }
      (data.posts || []).forEach(function (post) {
        refs.list.appendChild(createPostCard(post));
      });
      if (!refs.list.firstChild) showEmpty(EMPTY_TEXT[state.tab] || '暂无内容');
      refs.more.hidden = state.page * PAGE_SIZE >= state.total;
    }).catch(function () {
      if (seq !== state.seq) return;
      refs.loadingBox.hidden = true;
      showError('网络异常，请稍后重试');
    }).finally(function () {
      if (seq === state.seq) state.loading = false;
    });
  }

  // ── 帖子卡 ──
  function createPostCard(post) {
    var card = el('article', 'cm-post');
    card.dataset.id = String(post.id);

    var head = el('div', 'cm-post-head');
    head.appendChild(avatarNode(post, 40));
    var meta = el('div', 'cm-post-meta');
    var nameRow = el('div', 'cm-post-name-row');
    nameRow.appendChild(el('span', 'cm-post-author', post.authorName));
    if (!post.isAnonymous) nameRow.appendChild(el('span', 'cm-level', 'Lv.' + (Number(post.authorLevel) || 1)));
    if (post.isAnonymous) nameRow.appendChild(el('span', 'cm-kind cm-kind-anon', '匿名'));
    if (post.kind === 'moment') nameRow.appendChild(el('span', 'cm-kind cm-kind-moment', '瞬间 24h'));
    if (post.kind === 'checkin') nameRow.appendChild(el('span', 'cm-kind cm-kind-checkin', '打卡'));
    meta.appendChild(nameRow);
    meta.appendChild(el('div', 'cm-post-time', C.timeAgo(post.createdAt)));
    head.appendChild(meta);
    card.appendChild(head);

    card.appendChild(el('div', 'cm-post-body', post.body));

    if (Array.isArray(post.tags) && post.tags.length) {
      var tagRow = el('div', 'cm-post-tags');
      post.tags.forEach(function (tag) {
        tagRow.appendChild(button('cm-post-tag', '# ' + tag, function () { selectTag(tag); }));
      });
      card.appendChild(tagRow);
    }

    var actions = el('div', 'cm-post-actions');
    var likeBtn = button('cm-action cm-like' + (post.liked ? ' active' : ''));
    var favBtn = button('cm-action cm-favorite' + (post.favorited ? ' active' : ''));
    var commentBtn = button('cm-action cm-comment-toggle');
    var reportBtn = button('cm-action cm-report-toggle', '举报');
    actions.appendChild(likeBtn);
    actions.appendChild(commentBtn);
    actions.appendChild(favBtn);
    actions.appendChild(reportBtn);
    var deleteBtn = null;
    if (post.isMine) {
      deleteBtn = button('cm-action cm-delete', '删除');
      actions.appendChild(deleteBtn);
    }
    card.appendChild(actions);

    function setLike(liked, count) {
      likeBtn.classList.toggle('active', !!liked);
      likeBtn.setAttribute('aria-pressed', String(!!liked));
      setText(likeBtn, '赞 ' + C.fmtCount(count || 0));
    }
    function setFavorite(favorited, count) {
      favBtn.classList.toggle('active', !!favorited);
      favBtn.setAttribute('aria-pressed', String(!!favorited));
      setText(favBtn, '收藏 ' + C.fmtCount(count || 0));
    }
    function setCommentCount(count) {
      setText(commentBtn, '评论 ' + C.fmtCount(count || 0));
    }
    setLike(post.liked, post.likeCount);
    setCommentCount(post.commentCount);
    setFavorite(post.favorited, post.favoriteCount);

    var commentsBox = el('div', 'cm-comments');
    commentsBox.hidden = true;
    card.appendChild(commentsBox);

    var reportBox = el('div', 'cm-report');
    reportBox.hidden = true;
    card.appendChild(reportBox);

    likeBtn.addEventListener('click', function () {
      if (!C.requireLogin('点赞')) return;
      if (likeBtn.dataset.busy === '1') return;
      likeBtn.dataset.busy = '1';
      C.request(API + '/posts/' + post.id + '/like', { method: 'POST' }).then(function (response) {
        if (!response.ok) {
          C.toast(errorMessage(response, '点赞失败，请稍后重试'));
          return;
        }
        setLike(response.data.liked, response.data.likeCount);
      }).finally(function () {
        delete likeBtn.dataset.busy;
      });
    });

    favBtn.addEventListener('click', function () {
      if (!C.requireLogin('收藏')) return;
      if (favBtn.dataset.busy === '1') return;
      favBtn.dataset.busy = '1';
      C.request(API + '/posts/' + post.id + '/favorite', { method: 'POST' }).then(function (response) {
        if (!response.ok) {
          C.toast(errorMessage(response, '收藏失败，请稍后重试'));
          return;
        }
        setFavorite(response.data.favorited, response.data.favoriteCount);
      }).finally(function () {
        delete favBtn.dataset.busy;
      });
    });

    commentBtn.addEventListener('click', function () {
      var open = commentsBox.hidden;
      commentsBox.hidden = !open;
      if (open) loadComments(post, commentsBox, setCommentCount);
    });

    reportBtn.addEventListener('click', function () {
      if (!reportBox.hidden) {
        reportBox.hidden = true;
        return;
      }
      if (!C.requireLogin('举报')) return;
      reportBox.hidden = false;
      if (!reportBox.dataset.built) {
        buildReportPanel(reportBox, post.id);
        reportBox.dataset.built = '1';
      }
    });

    if (deleteBtn) {
      deleteBtn.addEventListener('click', function () {
        if (!window.confirm('确定删除这条内容？删除后不可恢复。')) return;
        if (deleteBtn.dataset.busy === '1') return;
        deleteBtn.dataset.busy = '1';
        C.request(API + '/posts/' + post.id, { method: 'DELETE' }).then(function (response) {
          if (!response.ok) {
            C.toast(errorMessage(response, '删除失败，请稍后重试'));
            return;
          }
          card.remove();
          state.total = Math.max(0, state.total - 1);
          if (!refs.list.firstChild) showEmpty(EMPTY_TEXT[state.tab] || '暂无内容');
          C.toast('已删除');
        }).finally(function () {
          delete deleteBtn.dataset.busy;
        });
      });
    }

    return card;
  }

  // ── 评论（楼中楼） ──
  async function loadComments(post, box, onCountChange) {
    var ctx = box.__cmCtx;
    if (!ctx) {
      ctx = { post: post, box: box, target: null, allReplies: false, onCountChange: onCountChange };
      box.__cmCtx = ctx;
    }
    if (ctx.loading) return;
    ctx.loading = true;
    C.clear(box);
    box.appendChild(C.loadingEl('评论加载中…'));
    var url = API + '/posts/' + post.id + '/comments?page=1&pageSize=20' + (ctx.allReplies ? '&replies=all' : '');
    var response = await C.request(url);
    ctx.loading = false;
    C.clear(box);
    if (!response.ok) {
      box.appendChild(el('div', 'cm-comment-status', errorMessage(response, '评论加载失败，请稍后重试')));
      box.appendChild(button('cm-comment-retry', '重试', function () {
        loadComments(post, box, onCountChange);
      }));
      return;
    }
    var rows = (response.data && response.data.rows) || [];
    var list = el('div', 'cm-comment-list');
    if (!rows.length) list.appendChild(el('div', 'cm-comments-empty', '还没有评论，来抢沙发'));
    rows.forEach(function (comment) {
      list.appendChild(createCommentItem(ctx, comment));
    });
    box.appendChild(list);
    if (C.signedIn()) {
      box.appendChild(buildCommentForm(ctx));
    } else {
      var hint = el('div', 'cm-comment-login');
      hint.appendChild(el('span', 'cm-comment-login-text', '登录后可参与评论'));
      hint.appendChild(button('cm-comment-login-btn', '去登录', function () {
        C.requireLogin('评论');
      }));
      box.appendChild(hint);
    }
  }

  function replyTargetText(comment) {
    return '回复 @' + (comment.isAnonymous ? '匿名同学' : comment.authorName);
  }

  function createCommentItem(ctx, comment) {
    var item = el('div', 'cm-comment');
    var head = el('div', 'cm-comment-head');
    head.appendChild(el('span', 'cm-comment-author', comment.isAnonymous ? '匿名同学' : comment.authorName));
    head.appendChild(el('span', 'cm-comment-time', C.timeAgo(comment.createdAt)));
    if (comment.isMine) {
      head.appendChild(button('cm-comment-delete', '删除', function () {
        deleteComment(ctx, comment);
      }));
    }
    item.appendChild(head);
    item.appendChild(el('div', 'cm-comment-body', comment.body));

    var actions = el('div', 'cm-comment-actions');
    if (C.signedIn()) {
      actions.appendChild(button('cm-comment-reply', '回复', function () {
        ctx.target = comment;
        var hint = ctx.box.querySelector('.cm-reply-hint');
        if (hint) {
          hint.hidden = false;
          setText(hint.querySelector('.cm-reply-hint-text'), replyTargetText(comment));
          var input = ctx.box.querySelector('.cm-comment-input');
          if (input) input.focus();
        }
      }));
    }
    item.appendChild(actions);

    var replies = Array.isArray(comment.replies) ? comment.replies : [];
    if (replies.length || comment.replyCount > 0) {
      var replyList = el('div', 'cm-reply-list');
      replies.forEach(function (reply) {
        replyList.appendChild(createReplyItem(ctx, reply));
      });
      item.appendChild(replyList);
      if (comment.replyCount > replies.length) {
        item.appendChild(button('cm-reply-expand', '展开全部 ' + comment.replyCount + ' 条回复', function () {
          ctx.allReplies = true;
          loadComments(ctx.post, ctx.box, ctx.onCountChange);
        }));
      }
    }
    return item;
  }

  function createReplyItem(ctx, reply) {
    var item = el('div', 'cm-reply');
    var head = el('div', 'cm-reply-head');
    head.appendChild(el('span', 'cm-reply-author', reply.isAnonymous ? '匿名同学' : reply.authorName));
    head.appendChild(el('span', 'cm-comment-time', C.timeAgo(reply.createdAt)));
    if (reply.isMine) {
      head.appendChild(button('cm-comment-delete', '删除', function () {
        deleteComment(ctx, reply);
      }));
    }
    item.appendChild(head);
    item.appendChild(el('div', 'cm-reply-body', reply.body));
    return item;
  }

  function buildCommentForm(ctx) {
    var form = el('div', 'cm-comment-form');
    var hint = el('div', 'cm-reply-hint');
    hint.hidden = true;
    hint.appendChild(el('span', 'cm-reply-hint-text', ''));
    hint.appendChild(button('cm-reply-cancel', '取消', function () {
      ctx.target = null;
      hint.hidden = true;
    }));
    var input = el('textarea', 'cm-comment-input');
    input.rows = 2;
    input.maxLength = 200;
    input.placeholder = '写下你的评论…（1–200 字）';
    var send = button('cm-comment-send', '发送', function () {
      if (send.dataset.busy === '1') return;
      var body = input.value.trim();
      var length = charCount(body);
      if (!length) return C.toast('请输入评论内容');
      if (length > 200) return C.toast('评论最多 200 个字');
      if (!ctx.target && !C.requireLogin('评论')) return;
      send.dataset.busy = '1';
      send.disabled = true;
      var payload = { body: body };
      if (ctx.target) payload.parentId = ctx.target.id;
      C.request(API + '/posts/' + ctx.post.id + '/comments', { method: 'POST', body: payload }).then(function (response) {
        if (!response.ok) {
          C.toast(errorMessage(response, '评论失败，请稍后重试'));
          return;
        }
        input.value = '';
        ctx.target = null;
        hint.hidden = true;
        if (typeof response.data.commentCount === 'number' && ctx.onCountChange) {
          ctx.onCountChange(response.data.commentCount);
        }
        loadComments(ctx.post, ctx.box, ctx.onCountChange);
      }).finally(function () {
        delete send.dataset.busy;
        send.disabled = false;
      });
    });
    form.appendChild(hint);
    var row = el('div', 'cm-comment-form-row');
    row.appendChild(input);
    row.appendChild(send);
    form.appendChild(row);
    return form;
  }

  function deleteComment(ctx, comment) {
    if (!window.confirm('确定删除这条评论？')) return;
    C.request(API + '/comments/' + comment.id, { method: 'DELETE' }).then(function (response) {
      if (!response.ok) {
        C.toast(errorMessage(response, '删除失败，请稍后重试'));
        return;
      }
      if (typeof response.data.commentCount === 'number' && ctx.onCountChange) {
        ctx.onCountChange(response.data.commentCount);
      }
      C.toast('已删除');
      loadComments(ctx.post, ctx.box, ctx.onCountChange);
    });
  }

  // ── 举报 ──
  function buildReportPanel(box, postId) {
    C.clear(box);
    var panel = el('div', 'cm-report-panel');
    panel.appendChild(el('div', 'cm-report-title', '选择举报原因'));
    var reasons = el('div', 'cm-report-reasons');
    REASONS.forEach(function (reason) {
      reasons.appendChild(button('cm-report-reason', reason, function () {
        if (panel.dataset.busy === '1') return;
        panel.dataset.busy = '1';
        C.request(API + '/reports', {
          method: 'POST',
          body: { targetType: 'post', targetId: postId, reason: reason }
        }).then(function (response) {
          if (!response.ok) {
            C.toast(errorMessage(response, '举报提交失败，请稍后重试'));
            delete panel.dataset.busy;
            return;
          }
          C.clear(box);
          box.appendChild(el('div', 'cm-report-done', '已提交，运营会尽快处理'));
        });
      }));
    });
    panel.appendChild(reasons);
    panel.appendChild(button('cm-report-cancel', '取消', function () {
      box.hidden = true;
    }));
    box.appendChild(panel);
  }

  // ── 注册到页签壳 / 导出 ──
  function refresh() {
    if (!root) return;
    render(root);
  }

  window.CommunityStudio = { refresh: refresh };

  // defer 脚本按顺序执行：页签壳可能已在本脚本注册前 boot（此时 current() 仍为 null），
  // 需要在注册后按 hash/默认页签补渲染广场，避免首屏空白。
  function tryInitialRender() {
    var shell = window.CZCommunityShell;
    var box = document.getElementById('communityBox');
    if (!box) return;
    var current = shell && typeof shell.current === 'function' ? shell.current() : null;
    if (current && current !== 'plaza') return;
    if (current === 'plaza') {
      if (root !== box) render(box);
      return;
    }
    var hash = String(window.location.hash || '').replace('#community-', '');
    if (hash !== '' && hash !== 'plaza') return;
    // 走壳的 show()，让 current() 与页签高亮状态一致（而不是绕过壳直接 render）。
    if (shell && typeof shell.show === 'function') shell.show('plaza');
    else render(box);
  }

  if (window.CZCommunityShell && typeof window.CZCommunityShell.register === 'function') {
    window.CZCommunityShell.register('plaza', { render: render, refresh: refresh, deactivate: function () { state.seq += 1; state.loading = false; } });
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', tryInitialRender);
    } else {
      tryInitialRender();
    }
  } else if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      render(document.getElementById('communityBox'));
    });
  } else {
    render(document.getElementById('communityBox'));
  }
})();
