(function(root){
'use strict';
function catalog(data){
 data=data||{};var rows=[],seen=new Set();
 function add(type,url,title,year,subject){
  if(typeof url!=='string'||!url.trim())return;
  try{var u=new URL(url,'https://www.chengze.online');if(!/^https?:$/.test(u.protocol))return;}catch{return;}
  var identity=[type,url,title,year||0].join('\0');if(seen.has(identity))return;seen.add(identity);
  var match=String(title||'').match(/(?:^|[^0-9])((?:19|20)\d{2})年?/);
  var y=/^(19|20)\d{2}$/.test(String(year))?Number(year):match?Number(match[1]):0;
  rows.push({type:type,url:url,title:title||type,year:y,subject:subject||''});
 }
 function files(type,value,title){
  var list=value;
  if(typeof value==='string'&&value.trim().startsWith('[')){try{list=JSON.parse(value);}catch{list=[];}}
  if(!Array.isArray(list))list=[list];
  list.forEach(function(item){if(typeof item==='string')add(type,item,title);else if(item)add(type,item.url,item.title||item.name||title,item.year);});
 }
 if(Array.isArray(data.resources)){data.resources.forEach(function(r){if(r.status&&r.status!=='published')return;var type={syllabus:'考试大纲',papers:'历年真题',notice:'官方公告'}[r.kind];if(type)add(type,r.url,r.title,r.year,r.subject_name);});return rows;}
 files('考试大纲',data.outline_file,'考试大纲');files('历年真题',data.papers_file,'历年真题');
 (data.subjectRows||[]).forEach(function(s){files('考试大纲',s.outline_file,s.name+' 考试大纲');files('历年真题',s.papers_file,s.name+' 历年真题');});
 (data.officialDocs||[]).forEach(function(d){if(/考试大纲/.test(d.title))add('考试大纲',d.url,d.title);else if(/真题/.test(d.title))add('历年真题',d.url,d.title);else add('官方公告',d.url,d.title);});
 return rows.sort(function(a,b){return (a.type==='考试大纲'?0:1)-(b.type==='考试大纲'?0:1)||b.year-a.year;});
}
function render(container,data){
 container.replaceChildren();var rows=catalog(data);
 ['考试大纲','历年真题'].forEach(function(type){
  var group=document.createElement('div');group.className='home-study-group';
  var heading=document.createElement('h3');heading.textContent=type;group.append(heading);
  var entries=rows.filter(function(r){return r.type===type;});
  if(!entries.length){var empty=document.createElement('p');empty.className='home-study-empty';empty.textContent='暂无'+type;group.append(empty);}
  entries.forEach(function(r){var link=document.createElement('a');link.href=r.url;link.target='_blank';link.rel='noopener';link.textContent=(r.year&&!r.title.includes(String(r.year))?r.year+'年 ':'')+r.title;group.append(link);});
  container.append(group);
 });
}
if(typeof module!=='undefined'&&module.exports)module.exports={catalog:catalog};
else root.ChengzeStudyResources={catalog:catalog,render:render};
})(typeof window!=='undefined'?window:this);
