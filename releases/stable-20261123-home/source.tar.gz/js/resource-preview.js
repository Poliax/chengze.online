(function(){'use strict';
 var dialog,title,download,body,message,toolbar,stack,zoomLabel,source,opener,library,loadingTask,session,loadVersion=0,activeUrl;
 function element(tag,cls,text){var e=document.createElement(tag);if(cls)e.className=cls;if(text)e.textContent=text;return e;}
 function iconAction(el,name,label){el.setAttribute('data-ui-icon',name);if(window.ChengzeIcons)window.ChengzeIcons.apply(el,name,label);return el;}
 function button(text,label,fn){var b=element('button','rp-action',text);b.type='button';b.setAttribute('aria-label',label);b.addEventListener('click',fn);var name={'关闭预览':'close','缩小':'zoom-out','放大':'zoom-in','适合宽度':'fit-width'}[label];if(name)iconAction(b,name,label);return b;}
 function stopDocument(){
  loadVersion++;
  if(session){session.closed=true;if(session.observer)session.observer.disconnect();session.slots.forEach(function(slot){if(slot.task)slot.task.cancel();release(slot);});session.queue=[];session=null;}
  if(loadingTask){loadingTask.destroy().catch(function(){});loadingTask=null;}
  if(stack)stack.replaceChildren();
 }
 function cleanup(){stopDocument();document.documentElement.classList.remove('resource-preview-open');if(opener&&opener.isConnected)opener.focus();}
 function close(){if(dialog&&dialog.open){if(dialog.close)dialog.close();else{dialog.removeAttribute('open');cleanup();}}}
 function build(){
  dialog=element('dialog');dialog.id='resourcePreviewDialog';dialog.setAttribute('aria-labelledby','resourcePreviewTitle');
  var header=element('header','rp-header'),actions=element('div','rp-actions'),closeButton=button('×','关闭预览',close);closeButton.classList.add('rp-close');
  title=element('h2');title.id='resourcePreviewTitle';title.tabIndex=-1;title.setAttribute('autofocus','');download=iconAction(element('a','rp-action','下载'),'download','下载');actions.append(download,closeButton);header.append(title,actions);
  toolbar=element('div','rp-toolbar');toolbar.setAttribute('aria-label','文档缩放');zoomLabel=element('span','rp-zoom','100%');
  toolbar.append(button('−','缩小',function(){changeZoom(-.2);}),zoomLabel,button('+','放大',function(){changeZoom(.2);}),button('适合宽度','适合宽度',function(){if(session){session.fit=true;layout(session,true);}}));
  body=element('div','rp-body');body.setAttribute('tabindex','0');body.setAttribute('aria-label','文档连续阅读区');
  stack=element('div','rp-pages');message=element('div','rp-message');message.setAttribute('role','status');source=element('a','rp-action','打开来源网页');source.target='_blank';source.rel='noopener noreferrer';body.append(message,stack);dialog.append(header,toolbar,body);document.body.append(dialog);
  dialog.addEventListener('close',cleanup);dialog.addEventListener('cancel',function(e){e.preventDefault();close();});dialog.addEventListener('click',function(e){if(e.target!==dialog)return;var r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)close();});
  body.addEventListener('scroll',function(){if(session&&!session.observer)updateVisible(session);},{passive:true});
  window.addEventListener('resize',function(){if(dialog.open&&session&&session.fit)layout(session,true);});
 }
 function release(slot){slot.status.hidden=true;if(slot.canvas){slot.canvas.width=0;slot.canvas.height=0;slot.canvas.remove();slot.canvas=null;}slot.rendered=-1;}
 function changeZoom(delta){if(!session)return;session.fit=false;session.zoom=Math.min(3,Math.max(.4,session.zoom+delta));layout(session,true);}
 function layout(s,preserve){
  if(s.closed)return;var anchor=null,fraction=0;
  if(preserve){anchor=s.slots.find(function(slot){return slot.node.offsetTop+slot.node.offsetHeight>body.scrollTop;});if(anchor)fraction=Math.max(0,(body.scrollTop-anchor.node.offsetTop)/anchor.node.offsetHeight);}
  s.revision++;if(s.fit)s.zoom=Math.min(3,Math.max(.4,(body.clientWidth-32)/s.baseWidth));s.width=s.baseWidth*s.zoom;zoomLabel.textContent=Math.round(s.zoom*100)+'%';
  s.slots.forEach(function(slot){if(slot.task)slot.task.cancel();slot.node.style.width=s.width+'px';slot.node.style.height=Math.ceil(s.width*slot.ratio)+'px';});
  if(anchor)body.scrollTop=anchor.node.offsetTop+fraction*anchor.node.offsetHeight;
  updateVisible(s);
 }
 function enqueue(s,slot){if(s.closed||!slot.near||slot.queued||slot.inflight||(slot.canvas&&slot.rendered===s.revision))return;slot.queued=true;s.queue.push(slot);}
 function updateVisible(s){
  if(s.closed)return;var top=body.scrollTop-900,bottom=body.scrollTop+body.clientHeight+900;
  s.slots.forEach(function(slot){slot.near=slot.node.offsetTop<bottom&&slot.node.offsetTop+slot.node.offsetHeight>top;if(slot.near)enqueue(s,slot);else if(!slot.inflight){slot.queued=false;release(slot);}});pump(s);
 }
 function pump(s){
  if(s.closed)return;
  s.queue.sort(function(a,b){return Math.abs(a.node.offsetTop-body.scrollTop)-Math.abs(b.node.offsetTop-body.scrollTop);});
  while(s.running<2&&s.queue.length){var slot=s.queue.shift();slot.queued=false;if(!slot.near||slot.inflight||(slot.canvas&&slot.rendered===s.revision))continue;paint(s,slot);}
 }
 async function paint(s,slot){
  s.running++;slot.inflight=true;var revision=s.revision,page=null,target=null;
  if(!slot.canvas){slot.status.hidden=false;slot.status.textContent='正在加载…';}
  try{
   page=await s.doc.getPage(slot.number);if(s.closed||!slot.near||revision!==s.revision)return;
   var natural=page.getViewport({scale:1}),viewport=page.getViewport({scale:s.width/natural.width}),ratio=Math.min(window.devicePixelRatio||1,1.5,Math.sqrt(4000000/(viewport.width*viewport.height)));
   var oldHeight=slot.node.offsetHeight,above=slot.node.offsetTop+oldHeight<=body.scrollTop;slot.ratio=natural.height/natural.width;slot.node.style.height=Math.ceil(s.width*slot.ratio)+'px';if(above)body.scrollTop+=slot.node.offsetHeight-oldHeight;
   target=element('canvas');target.width=Math.floor(viewport.width*ratio);target.height=Math.floor(viewport.height*ratio);target.setAttribute('role','img');target.setAttribute('aria-label','第'+slot.number+'页，共'+s.doc.numPages+'页');
   slot.task=page.render({canvasContext:target.getContext('2d'),viewport:viewport,transform:ratio===1?null:[ratio,0,0,ratio,0,0]});await slot.task.promise;
   if(s.closed||!slot.near||revision!==s.revision)return;
   release(slot);slot.canvas=target;target=null;slot.rendered=revision;slot.status.hidden=true;slot.node.append(slot.canvas);
  }catch(error){
   if(!s.closed&&slot.near&&revision===s.revision&&error.name!=='RenderingCancelledException'){
    slot.status.hidden=false;slot.status.replaceChildren(element('span','','这一页暂未加载。'),button('重试','重新加载第'+slot.number+'页',function(){slot.rendered=-1;enqueue(s,slot);pump(s);}));
   }
  }finally{
   if(target){target.width=0;target.height=0;}if(page&&page.cleanup){try{page.cleanup();}catch{}}slot.task=null;slot.inflight=false;s.running--;
   if(!s.closed){if(!slot.near)release(slot);else if(revision!==s.revision)enqueue(s,slot);pump(s);}
  }
 }
 function showDocument(doc){
  var s=session={doc:doc,slots:[],queue:[],running:0,revision:0,zoom:1,fit:true,baseWidth:doc.baseWidth||612,closed:false,observer:null};
  message.hidden=true;toolbar.hidden=false;stack.hidden=false;body.scrollTop=0;body.scrollLeft=0;
  var fragment=document.createDocumentFragment();for(var i=1;i<=doc.numPages;i++){var node=element('div','rp-page'),status=element('div','rp-page-status');status.hidden=true;node.append(status);var slot={node:node,status:status,number:i,ratio:doc.pageRatio||Math.SQRT2,canvas:null,task:null,queued:false,inflight:false,near:false,rendered:-1};s.slots.push(slot);fragment.append(node);}stack.append(fragment);
  layout(s,false);
  if(window.IntersectionObserver){s.observer=new IntersectionObserver(function(entries){if(s.closed)return;entries.forEach(function(entry){var slot=s.slots[Number(entry.target.dataset.page)-1];slot.near=entry.isIntersecting;if(slot.near)enqueue(s,slot);else if(!slot.inflight){slot.queued=false;release(slot);}});pump(s);},{root:body,rootMargin:'900px 0px'});s.slots.forEach(function(slot){slot.node.dataset.page=slot.number;s.observer.observe(slot.node);});}
 }
 function failed(error){if(window.console)console.warn('[资料预览] 预览未完成',error&&error.message||'');toolbar.hidden=true;stack.hidden=true;message.hidden=false;message.replaceChildren(element('p','','预览未完成，请重试或下载查看。'),button('重新加载','重新加载文档',function(){loadPdf(activeUrl);}));}
 async function serverDocument(url){
  var controller=new AbortController(),closed=false;loadingTask={destroy:function(){closed=true;controller.abort();return Promise.resolve();}};
  var response;for(var attempt=0;attempt<2;attempt++){try{response=await fetch(url.origin+url.pathname+'/preview',{cache:'no-store',signal:controller.signal});if(!response.ok)throw Error('Server preview unavailable');break;}catch(error){if(closed||attempt===1)throw error;await new Promise(function(resolve){setTimeout(resolve,350);});}}
  var data=await response.json();if(!Number.isInteger(data.pages)||data.pages<1||data.pages>1000)throw Error('Invalid preview metadata');
  return {numPages:data.pages,baseWidth:data.width||612,getPage:async function(number){
   if(closed)throw Error('Preview closed');var img=new Image();img.decoding='async';
   await new Promise(function(resolve,reject){var retries=0,imageUrl=url.origin+url.pathname+'/preview/page/'+number+'?v='+encodeURIComponent(data.version);img.onload=resolve;img.onerror=function(){if(!closed&&retries++===0){setTimeout(function(){if(closed)reject(Error('Preview closed'));else img.src=imageUrl+'&retry=1';},350);}else reject(Error('Page image unavailable'));};img.src=imageUrl;});
   if(closed)throw Error('Preview closed');var width=data.width||612,height=width*img.naturalHeight/img.naturalWidth;
   return {getViewport:function(opts){return {width:width*opts.scale,height:height*opts.scale};},render:function(opts){var cancelled=false;return {cancel:function(){cancelled=true;},promise:Promise.resolve().then(function(){if(cancelled||closed)return;var ctx=opts.canvasContext;ctx.setTransform.apply(ctx,opts.transform||[1,0,0,1,0,0]);ctx.drawImage(img,0,0,opts.viewport.width,opts.viewport.height);})};}};
  }};
 }
 async function loadPdf(url){
  stopDocument();var id=loadVersion;stack.hidden=true;message.hidden=false;message.textContent='正在加载文档…';toolbar.hidden=true;
  try{
   if(url.origin===location.origin&&/^\/public\/provinces\/[^/]+\.pdf$/i.test(url.pathname)){
    try{var serverPdf=await serverDocument(url);if(id!==loadVersion)return;showDocument(serverPdf);return;}catch(serverError){if(id!==loadVersion)return;if(loadingTask){await loadingTask.destroy();loadingTask=null;}}
   }
   library=library||import('/js/vendor/pdfjs/pdf.min.mjs').catch(function(e){library=null;throw e;});var lib=await library;if(id!==loadVersion)return;lib.GlobalWorkerOptions.workerSrc='/js/vendor/pdfjs/pdf.worker.min.mjs';
   loadingTask=lib.getDocument({url:url.href,cMapUrl:'/js/vendor/pdfjs/cmaps/',cMapPacked:true,standardFontDataUrl:'/js/vendor/pdfjs/standard_fonts/',wasmUrl:'/js/vendor/pdfjs/wasm/',isEvalSupported:false,disableAutoFetch:true,disableStream:true});
   var doc=await loadingTask.promise;if(id!==loadVersion)return;var first=await doc.getPage(1),size=first.getViewport({scale:1});doc.baseWidth=size.width;doc.pageRatio=size.height/size.width;if(id===loadVersion)showDocument(doc);
  }catch(error){if(id===loadVersion)failed(error);}
 }
 function open(link){
  var url;try{url=new URL(link.href,location.href);if(!/^https?:$/.test(url.protocol)||url.username||url.password)return;}catch{return;}
  if(!dialog)build();opener=link;title.textContent=link.dataset.resourceTitle||link.textContent.trim().replace(/\s*↗$/,'');var ext=(url.pathname.match(/\.(pdf|docx?)$/i)||[])[1]||'',local=url.origin===location.origin&&url.pathname.startsWith('/public/provinces/');
  var fileName=title.textContent.replace(/[\\/<>:"|?*\x00-\x1f]/g,'_').replace(/\.(pdf|docx?)$/i,'').slice(0,140)+(ext?'.'+ext:'');var target=new URL(url.href);if(local){target.searchParams.set('download','1');target.searchParams.set('filename',title.textContent);}
  download.href=target.href;download.download=fileName;download.target=local?'_self':'_blank';download.rel='noopener noreferrer';download.hidden=!ext;document.documentElement.classList.add('resource-preview-open');if(!dialog.open){if(dialog.showModal)dialog.showModal();else dialog.setAttribute('open','');}title.focus({preventScroll:true});activeUrl=url;
  if(ext.toLowerCase()==='pdf')loadPdf(url);else{stopDocument();toolbar.hidden=true;stack.hidden=true;message.hidden=false;message.replaceChildren();if(ext)message.append(element('p','','此文档可通过上方“下载”保存后查看。'));else{message.append(element('p','','此资料为来源网页。'));source.href=url.href;message.append(source);}}
 }
 document.addEventListener('click',function(e){var link=e.target.closest&&e.target.closest('a[data-resource-preview]');if(!link||e.defaultPrevented||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey||(e.button!==undefined&&e.button!==0))return;e.preventDefault();open(link);});
})();
