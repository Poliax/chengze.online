/* Single native dialog. Fetch fields, never nest a page or iframe. */
(function(root){
 if(root.AdminFormDialog)return;
 root.AdminFormDialog={attach:function(options){
  const dialog=document.getElementById(options.dialog),trigger=document.getElementById(options.trigger);
  let controller,version=0,saving=false,disposed=false,loading=false;
  function error(message){const box=dialog.querySelector('[role=alert]');box.textContent=message;box.hidden=!message;}
  function busy(value){dialog.setAttribute('aria-busy',String(value));dialog.querySelectorAll('button[type=submit]').forEach(b=>b.disabled=value);dialog.querySelector('[data-cz-dialog-close]').disabled=saving;}
  function fields(doc){const source=doc.querySelector(options.content+' form');if(!source)return false;
   const grid=source.querySelector('.form-grid');if(!grid)return false;
   const form=dialog.querySelector('form'),body=dialog.querySelector('.admin-create-fields');body.replaceChildren();
   form.action=new URL(source.getAttribute('action'),location.href).href;form.method='post';
   for(const input of source.querySelectorAll('input[type=hidden]'))body.append(input.cloneNode(true));
   for(const item of grid.children){const node=item.cloneNode(true);node.removeAttribute('style');node.querySelectorAll('script').forEach(s=>s.remove());node.querySelectorAll('[style]').forEach(n=>n.removeAttribute('style'));node.querySelectorAll('[autofocus]').forEach(n=>n.removeAttribute('autofocus'));node.querySelectorAll('input').forEach(n=>n.autocomplete=n.type==='password'?'new-password':'off');body.append(node);}
   error((doc.querySelector('.error-box')||{}).textContent||'');return true;
  }
  async function open(event){if(event&&(event.metaKey||event.ctrlKey||event.shiftKey||event.altKey))return;if(event)event.preventDefault();if(dialog.open||loading)return;loading=true;
   const id=++version;controller=new AbortController();dialog.querySelector('.admin-create-fields').replaceChildren();error('');trigger.setAttribute('aria-busy','true');busy(true);
   try{const url=new URL(trigger.href,location.href);url.searchParams.set('dialog','1');const response=await fetch(url,{credentials:'same-origin',signal:controller.signal});const doc=new DOMParser().parseFromString(await response.text(),'text/html');if(id!==version||disposed)return;if(!response.ok||!fields(doc))throw Error('无法加载表单，请确认登录状态');dialog.showModal();dialog.querySelector('[data-cz-dialog-close]').focus({preventScroll:true});}
   catch(e){if(e.name!=='AbortError'&&id===version){error(e.message);if(!dialog.open)dialog.showModal();}}finally{loading=false;trigger.removeAttribute('aria-busy');if(id===version)busy(false);}
  }
  async function submit(event){event.preventDefault();if(saving)return;const form=event.currentTarget;if(!form.reportValidity())return;saving=true;error('');busy(true);
   try{const response=await fetch(form.action,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(new FormData(form))});
    const url=new URL(response.url,location.href);if(response.ok&&options.completedPaths.includes(url.pathname)){saving=false;dialog.close();options.onSaved();return;}
    const doc=new DOMParser().parseFromString(await response.text(),'text/html');if(!fields(doc))throw Error('保存失败，请确认登录状态后重试');
   }catch(e){error(e.message);}finally{saving=false;busy(false);}
  }
  function close(){if(!saving)dialog.close();}
  function cancel(event){if(saving)event.preventDefault();}
  function closed(){version++;if(controller)controller.abort();}
  const form=dialog.querySelector('form'),cross=dialog.querySelector('[data-cz-dialog-close]');
  trigger.addEventListener('click',open);form.addEventListener('submit',submit);cross.addEventListener('click',close);dialog.addEventListener('cancel',cancel);dialog.addEventListener('close',closed);
  const removal=new MutationObserver(()=>{if(!dialog.isConnected&&!disposed){disposed=true;closed();removal.disconnect();trigger.removeEventListener('click',open);form.removeEventListener('submit',submit);}});removal.observe(document.body,{childList:true,subtree:true});
 }};
})(window);
