/* 社区 v2「我的」页签：身份卡 / 资料完善 / 每日打卡 / 积分等级 / 排行榜 / 我的帖子。
 * 所有服务器文本一律经 textContent 注入（CZCommunity.el / esc），不使用任何 HTML 拼接。 */
(function () {
  'use strict';

  var C = window.CZCommunity;
  var Shell = window.CZCommunityShell;
  if (!C || !Shell) return;

  var API = '/api/community';
  var STUDY_TAGS = ['英语', '高数', '语文', '计算机', '政治', '管理学', '教育学', '医学', '会计', '经济学', '法学', '艺术', '体育'];
  var LEVEL_MIN = [0, 100, 300, 800, 1500, 3000];
  var state = { period: 'week' };
  var lastBox = null;
  var renderSequence = 0;

  function el(tag, className, text) {
    return C.el(tag, className, text);
  }

  function card(className) {
    return el('section', 'cm-me-card' + (className ? ' ' + className : ''));
  }

  function button(label, className, onClick) {
    var node = el('button', 'cm-me-btn' + (className ? ' ' + className : ''), label);
    node.type = 'button';
    if (typeof onClick === 'function') node.addEventListener('click', onClick);
    return node;
  }

  function pad2(n) {
    return (n < 10 ? '0' : '') + n;
  }

  function todayKey() {
    var now = new Date();
    return now.getUTCFullYear() + '-' + pad2(now.getUTCMonth() + 1) + '-' + pad2(now.getUTCDate());
  }

  function recentKeys(count) {
    var keys = [];
    var now = new Date();
    for (var i = count - 1; i >= 0; i -= 1) {
      var d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - i));
      keys.push(d.getUTCFullYear() + '-' + pad2(d.getUTCMonth() + 1) + '-' + pad2(d.getUTCDate()));
    }
    return keys;
  }

  function sectionHead(title, extra) {
    var head = el('div', 'cm-me-section-head');
    head.appendChild(el('h3', 'cm-me-section-title', title));
    if (extra) head.appendChild(extra);
    return head;
  }

  function errorCard(message, retry) {
    var box = el('div', 'cm-me-status');
    box.appendChild(el('p', 'cm-me-status-text', message));
    if (typeof retry === 'function') box.appendChild(button('重试', 'cm-me-btn-ghost', retry));
    return box;
  }

  // ── 未登录引导卡 ──
  function guestCard() {
    var box = card('cm-me-guest');
    box.appendChild(el('div', 'cm-me-guest-icon', '🌱'));
    box.appendChild(el('h3', 'cm-me-guest-title', '登录后查看你的成长主页'));
    box.appendChild(el('p', 'cm-me-guest-text', '身份卡、每日打卡、积分等级和我的帖子都在这里。'));
    box.appendChild(button('去登录', 'cm-me-btn-primary', function () {
      C.requireLogin('查看成长主页');
    }));
    return box;
  }

  // 未登录时的打卡占位卡：状态如实展示「未登录」，按钮走登录引导。
  function guestCheckinCard() {
    var section = card('cm-me-checkin');
    var head = el('div', 'cm-me-section-head');
    head.appendChild(el('h3', 'cm-me-section-title', '每日打卡'));
    head.appendChild(el('span', 'cm-me-pill', '登录后打卡'));
    section.appendChild(head);
    var stats = el('div', 'cm-me-checkin-stats');
    var streak = el('div', 'cm-me-checkin-stat');
    streak.appendChild(el('span', 'cm-me-checkin-value', '0'));
    streak.appendChild(el('span', 'cm-me-checkin-label', '连续天数'));
    stats.appendChild(streak);
    var total = el('div', 'cm-me-checkin-stat');
    total.appendChild(el('span', 'cm-me-checkin-value', '0'));
    total.appendChild(el('span', 'cm-me-checkin-label', '累计天数'));
    stats.appendChild(total);
    section.appendChild(stats);
    var keys = recentKeys(14);
    var grid = el('div', 'cm-me-days');
    for (var i = 0; i < keys.length; i += 1) {
      var cell = el('span', 'cm-me-day', '·');
      cell.title = keys[i] + ' · 登录后可打卡';
      grid.appendChild(cell);
    }
    section.appendChild(grid);
    var foot = el('div', 'cm-me-checkin-foot');
    var noteInput = document.createElement('input');
    noteInput.type = 'text';
    noteInput.className = 'cm-me-input cm-me-checkin-input';
    noteInput.placeholder = '登录后可记录今天的学习内容';
    noteInput.disabled = true;
    foot.appendChild(noteInput);
    foot.appendChild(button('登录后打卡', 'cm-me-btn-primary', function () {
      C.requireLogin('打卡');
    }));
    section.appendChild(foot);
    return section;
  }

  // ── 身份卡 ──
  function renderIdentity(profile, growthMe) {
    var section = card('cm-me-identity');
    var top = el('div', 'cm-me-identity-top');
    top.appendChild(C.avatarEl(profile, 64));

    var main = el('div', 'cm-me-identity-main');
    var nameRow = el('div', 'cm-me-name-row');
    nameRow.appendChild(el('span', 'cm-me-name', profile.name || '学员'));
    nameRow.appendChild(el('span', 'cm-me-level', 'Lv.' + profile.level + ' ' + profile.levelTitle));
    main.appendChild(nameRow);

    var metaParts = [];
    if (profile.provinceName) metaParts.push(profile.provinceName);
    if (profile.examYear) metaParts.push(profile.examYear + ' 年考试');
    if (metaParts.length) main.appendChild(el('div', 'cm-me-meta', metaParts.join(' · ')));

    var goalParts = [];
    if (profile.targetSchool) goalParts.push('目标院校：' + profile.targetSchool);
    if (profile.targetMajor) goalParts.push('目标专业：' + profile.targetMajor);
    if (goalParts.length) main.appendChild(el('div', 'cm-me-goal', goalParts.join(' ｜ ')));

    if (profile.bio) main.appendChild(el('p', 'cm-me-bio', profile.bio));

    if (profile.studyTags && profile.studyTags.length) {
      var tags = el('div', 'cm-me-tags');
      for (var i = 0; i < profile.studyTags.length; i += 1) {
        tags.appendChild(el('span', 'cm-me-tag', profile.studyTags[i]));
      }
      main.appendChild(tags);
    }
    top.appendChild(main);
    section.appendChild(top);

    var stats = el('div', 'cm-me-stats');
    var statList = [
      { label: '关注', value: profile.following },
      { label: '粉丝', value: profile.followers },
      { label: '帖子', value: profile.posts },
      { label: '积分', value: growthMe ? growthMe.points : profile.points }
    ];
    for (var s = 0; s < statList.length; s += 1) {
      var item = el('div', 'cm-me-stat');
      item.appendChild(el('span', 'cm-me-stat-value', C.fmtCount(statList[s].value)));
      item.appendChild(el('span', 'cm-me-stat-label', statList[s].label));
      stats.appendChild(item);
    }
    section.appendChild(stats);

    var footer = el('div', 'cm-me-identity-foot');
    var nextPoints = growthMe ? growthMe.nextLevelPoints : null;
    var points = growthMe ? growthMe.points : profile.points;
    if (nextPoints === null || nextPoints === undefined) {
      footer.appendChild(el('span', 'cm-me-progress-text', '已达最高等级，继续陪伴大家'));
    } else {
      var minPoints = LEVEL_MIN[Math.max(0, (profile.level || 1) - 1)] || 0;
      var ratio = nextPoints > minPoints ? (points - minPoints) / (nextPoints - minPoints) : 1;
      ratio = Math.max(0, Math.min(1, ratio));
      var bar = el('div', 'cm-me-progress');
      var fill = el('div', 'cm-me-progress-fill');
      fill.style.width = (ratio * 100).toFixed(1) + '%';
      bar.appendChild(fill);
      footer.appendChild(bar);
      footer.appendChild(el('span', 'cm-me-progress-text',
        '距离下一级还差 ' + Math.max(0, nextPoints - points) + ' 积分'));
    }
    if (profile.isSelf) {
      footer.appendChild(button('编辑资料', 'cm-me-btn-ghost cm-me-edit-toggle', function () {
        var form = document.getElementById('cmMeEdit');
        if (!form) return;
        form.hidden = !form.hidden;
        if (!form.hidden && typeof form.scrollIntoView === 'function') {
          try { form.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) { /* 忽略 */ }
        }
      }));
    }
    section.appendChild(footer);
    return section;
  }

  // ── 编辑资料表单（内联） ──
  function renderEditForm(profile) {
    var form = el('div', 'cm-me-card cm-me-edit');
    form.id = 'cmMeEdit';
    form.hidden = true;
    form.appendChild(el('h3', 'cm-me-section-title', '编辑资料'));
    form.appendChild(el('p', 'cm-me-edit-hint', '资料会展示在身份卡与「找搭子」里，请勿填写联系方式。'));

    function field(labelText, value, maxLength, multiline) {
      var wrap = el('label', 'cm-me-field');
      wrap.appendChild(el('span', 'cm-me-field-label', labelText));
      var input = document.createElement(multiline ? 'textarea' : 'input');
      if (!multiline) input.type = 'text';
      input.className = 'cm-me-input';
      input.maxLength = maxLength;
      input.value = value || '';
      wrap.appendChild(input);
      return { wrap: wrap, input: input };
    }

    var nickname = field('昵称（1–20 字）', profile.name, 20, false);
    var school = field('目标院校（≤40 字）', profile.targetSchool, 40, false);
    var major = field('目标专业（≤40 字）', profile.targetMajor, 40, false);
    var bio = field('学习宣言（≤100 字）', profile.bio, 100, true);
    form.appendChild(nickname.wrap);
    form.appendChild(school.wrap);
    form.appendChild(major.wrap);
    form.appendChild(bio.wrap);

    var tagWrap = el('div', 'cm-me-field');
    tagWrap.appendChild(el('span', 'cm-me-field-label', '学习标签（最多 5 个）'));
    var tagBox = el('div', 'cm-me-tag-choices');
    var selected = (profile.studyTags || []).slice(0, 5);
    var tagNodes = [];
    for (var i = 0; i < STUDY_TAGS.length; i += 1) {
      (function (tag) {
        var choice = button(tag, 'cm-me-tag-choice', null);
        if (selected.indexOf(tag) >= 0) choice.classList.add('is-active');
        choice.addEventListener('click', function () {
          var at = selected.indexOf(tag);
          if (at >= 0) {
            selected.splice(at, 1);
            choice.classList.remove('is-active');
            return;
          }
          if (selected.length >= 5) {
            C.toast('最多选择 5 个学习标签');
            return;
          }
          selected.push(tag);
          choice.classList.add('is-active');
        });
        tagNodes.push(choice);
        tagBox.appendChild(choice);
      })(STUDY_TAGS[i]);
    }
    tagWrap.appendChild(tagBox);
    form.appendChild(tagWrap);

    var counter = el('span', 'cm-me-counter', (bio.input.value || '').length + '/100');
    bio.wrap.appendChild(counter);
    bio.input.addEventListener('input', function () {
      counter.textContent = Array.from(bio.input.value || '').length + '/100';
    });

    var actions = el('div', 'cm-me-edit-actions');
    var saving = false;
    var saveBtn = button('保存', 'cm-me-btn-primary', async function () {
      if (saving) return;
      var nicknameValue = String(nickname.input.value || '').trim();
      if (!nicknameValue) {
        C.toast('昵称不能为空');
        return;
      }
      saving = true;
      saveBtn.disabled = true;
      var payload = {
        nickname: nicknameValue,
        targetSchool: String(school.input.value || '').trim(),
        targetMajor: String(major.input.value || '').trim(),
        bio: String(bio.input.value || '').trim(),
        studyTags: selected.slice()
      };
      var response = await C.request(API + '/me/profile', { method: 'PATCH', body: payload });
      if (!response.ok) {
        saving = false;
        saveBtn.disabled = false;
        C.toast((response.data && response.data.error) || '保存失败，请稍后再试');
        return;
      }
      C.toast('资料已更新');
      renderPage(lastBox);
    });
    actions.appendChild(saveBtn);
    actions.appendChild(button('取消', 'cm-me-btn-ghost', function () {
      form.hidden = true;
    }));
    form.appendChild(actions);
    return form;
  }

  // ── 打卡卡 ──
  function renderCheckin(status, checkedToday) {
    var done = !!checkedToday;
    var section = card('cm-me-checkin');
    var head = el('div', 'cm-me-section-head');
    head.appendChild(el('h3', 'cm-me-section-title', '每日打卡'));
    head.appendChild(el('span', 'cm-me-pill' + (done ? ' is-done' : ''), done ? '今日已打卡' : '今日未打卡'));
    section.appendChild(head);

    var stats = el('div', 'cm-me-checkin-stats');
    var streak = el('div', 'cm-me-checkin-stat');
    streak.appendChild(el('span', 'cm-me-checkin-value', C.fmtCount(status.streak || 0)));
    streak.appendChild(el('span', 'cm-me-checkin-label', '连续天数'));
    stats.appendChild(streak);
    var total = el('div', 'cm-me-checkin-stat');
    total.appendChild(el('span', 'cm-me-checkin-value', C.fmtCount(status.checkinTotal || 0)));
    total.appendChild(el('span', 'cm-me-checkin-label', '累计天数'));
    stats.appendChild(total);
    section.appendChild(stats);

    var doneMap = {};
    var recent = Array.isArray(status.recent) ? status.recent : [];
    for (var i = 0; i < recent.length; i += 1) {
      doneMap[recent[i].day] = recent[i].note || '';
    }
    var keys = recentKeys(14);
    var today = todayKey();
    var grid = el('div', 'cm-me-days');
    for (var k = 0; k < keys.length; k += 1) {
      var day = keys[k];
      var checked = Object.prototype.hasOwnProperty.call(doneMap, day);
      var cell = el('span', 'cm-me-day' + (checked ? ' is-done' : '') + (day === today ? ' is-today' : ''), '');
      var dayNumber = String(Number(day.slice(8, 10)));
      cell.textContent = checked ? dayNumber : '·';
      cell.title = day + (checked ? (doneMap[day] ? ' · ' + doneMap[day] : ' · 已打卡') : ' · 未打卡');
      grid.appendChild(cell);
    }
    section.appendChild(grid);

    var foot = el('div', 'cm-me-checkin-foot');
    var noteInput = document.createElement('input');
    noteInput.type = 'text';
    noteInput.className = 'cm-me-input cm-me-checkin-input';
    noteInput.maxLength = 200;
    noteInput.placeholder = '写一句今天的学习内容（可选）';
    var checkinBtn = button(done ? '今日已打卡' : '今日打卡（+5 积分）', 'cm-me-btn-primary', null);
    checkinBtn.disabled = done;
    checkinBtn.addEventListener('click', async function () {
      if (checkinBtn.disabled) return;
      checkinBtn.disabled = true;
      var payload = {};
      var note = String(noteInput.value || '').trim();
      if (note) payload.note = note;
      var response = await C.request(API + '/checkin', { method: 'POST', body: payload });
      if (!response.ok) {
        if (response.status === 409) {
          C.toast('今天已经打过卡了');
          renderPage(lastBox);
          return;
        }
        checkinBtn.disabled = false;
        C.toast((response.data && response.data.error) || '打卡失败，请稍后再试');
        return;
      }
      var awarded = response.data && response.data.awarded;
      C.toast(awarded ? '打卡成功，+' + awarded + ' 积分' : '打卡成功');
      renderPage(lastBox);
    });
    foot.appendChild(noteInput);
    foot.appendChild(checkinBtn);
    section.appendChild(foot);
    return section;
  }

  // ── 排行榜 ──
  function renderBoardRow(row, isMe) {
    var item = el('div', 'cm-me-board-row' + (isMe ? ' is-me' : ''));
    var badge = el('span', 'cm-me-rank', String(row.rank));
    if (row.rank === 1) badge.classList.add('cm-me-rank-1');
    if (row.rank === 2) badge.classList.add('cm-me-rank-2');
    if (row.rank === 3) badge.classList.add('cm-me-rank-3');
    item.appendChild(badge);
    item.appendChild(C.avatarEl(row, 36));
    var main = el('div', 'cm-me-board-main');
    main.appendChild(el('span', 'cm-me-board-name', row.name || '学员'));
    main.appendChild(el('span', 'cm-me-board-level', 'Lv.' + row.level + ' ' + (row.levelTitle || '')));
    item.appendChild(main);
    item.appendChild(el('span', 'cm-me-board-points', C.fmtCount(row.points)));
    return item;
  }

  async function loadLeaderboard(listNode, footNode, viewerId) {
    C.clear(listNode);
    listNode.appendChild(C.loadingEl('榜单加载中…'));
    var response = await C.request(API + '/leaderboard?period=' + state.period + '&limit=50');
    C.clear(listNode);
    if (!response.ok || !response.data || !response.data.ok) {
      listNode.appendChild(errorCard('排行榜加载失败', function () {
        loadLeaderboard(listNode, footNode, viewerId);
      }));
      return;
    }
    var rows = response.data.rows || [];
    var me = response.data.me || null;
    if (!rows.length) {
      listNode.appendChild(C.emptyEl('还没有同学上榜，打卡、发帖就能拿积分'));
    } else {
      for (var i = 0; i < rows.length; i += 1) {
        listNode.appendChild(renderBoardRow(rows[i], !!(viewerId && rows[i].studentId === viewerId)));
      }
    }
    if (footNode) {
      C.clear(footNode);
      if (me) {
        footNode.appendChild(el('span', 'cm-me-board-mine-label', '我的排名'));
        footNode.appendChild(el('span', 'cm-me-board-mine-rank', '第 ' + me.rank + ' 名'));
        footNode.appendChild(el('span', 'cm-me-board-mine-points', C.fmtCount(me.points) + ' 积分'));
        footNode.appendChild(el('span', 'cm-me-board-mine-level', 'Lv.' + me.level + ' ' + (me.levelTitle || '')));
      } else {
        footNode.appendChild(el('span', 'cm-me-board-mine-label', '登录后查看我的排名'));
      }
    }
  }

  function leaderboardSection(viewerId) {
    var section = card('cm-me-board');
    var toggle = el('div', 'cm-me-seg');
    var weekBtn = button('周榜', 'cm-me-seg-btn', function () {
      if (state.period === 'week') return;
      state.period = 'week';
      syncToggle();
      loadLeaderboard(list, foot, viewerId);
    });
    var allBtn = button('总榜', 'cm-me-seg-btn', function () {
      if (state.period === 'all') return;
      state.period = 'all';
      syncToggle();
      loadLeaderboard(list, foot, viewerId);
    });
    toggle.appendChild(weekBtn);
    toggle.appendChild(allBtn);
    function syncToggle() {
      weekBtn.classList.toggle('is-active', state.period === 'week');
      allBtn.classList.toggle('is-active', state.period === 'all');
    }
    syncToggle();
    section.appendChild(sectionHead('积分排行榜', toggle));
    var list = el('div', 'cm-me-board-list');
    var foot = el('div', 'cm-me-board-foot');
    section.appendChild(list);
    section.appendChild(foot);
    loadLeaderboard(list, foot, viewerId);
    return section;
  }

  // ── 我的帖子 ──
  function renderPosts(posts) {
    var section = card('cm-me-posts');
    section.appendChild(sectionHead('我的帖子', button('去广场', 'cm-me-btn-ghost', function () {
      Shell.show('plaza');
    })));
    if (!posts || !posts.length) {
      var empty = el('div', 'cm-me-posts-empty');
      empty.appendChild(el('p', 'cm-me-posts-empty-text', '还没有发过帖子，去广场分享你的备考日常吧'));
      empty.appendChild(button('去发第一条', 'cm-me-btn-primary', function () {
        Shell.show('plaza');
      }));
      section.appendChild(empty);
      return section;
    }
    for (var i = 0; i < posts.length; i += 1) {
      section.appendChild(renderPostItem(posts[i]));
    }
    return section;
  }

  function renderPostItem(post) {
    var item = el('article', 'cm-me-post');
    var meta = el('div', 'cm-me-post-meta');
    var kindLabel = post.kind === 'moment' ? '瞬间' : (post.kind === 'checkin' ? '打卡' : '帖子');
    meta.appendChild(el('span', 'cm-me-post-kind', kindLabel));
    if (post.isAnonymous) meta.appendChild(el('span', 'cm-me-post-anon', '匿名'));
    meta.appendChild(el('span', 'cm-me-post-time', C.timeAgo(post.createdAt)));
    item.appendChild(meta);
    item.appendChild(el('p', 'cm-me-post-body', post.body));
    if (post.tags && post.tags.length) {
      var tags = el('div', 'cm-me-post-tags');
      for (var i = 0; i < post.tags.length; i += 1) tags.appendChild(el('span', 'cm-me-post-tag', post.tags[i]));
      item.appendChild(tags);
    }
    var counts = el('div', 'cm-me-post-counts');
    counts.appendChild(el('span', 'cm-me-post-count', '赞 ' + (post.likeCount || 0)));
    counts.appendChild(el('span', 'cm-me-post-count', '评论 ' + (post.commentCount || 0)));
    counts.appendChild(el('span', 'cm-me-post-count', '收藏 ' + (post.favoriteCount || 0)));
    item.appendChild(counts);
    item.addEventListener('click', function () {
      Shell.show('plaza');
    });
    return item;
  }

  // ── 页面渲染 ──
  async function renderPage(box) {
    if (!box) return;
    var sequence = ++renderSequence;
    lastBox = box;
    C.clear(box);
    box.appendChild(C.loadingEl('正在加载成长主页…'));

    if (!C.signedIn()) {
      C.clear(box);
      var guestWrap = el('div', 'cm-me-root');
      guestWrap.appendChild(guestCard());
      guestWrap.appendChild(guestCheckinCard());
      guestWrap.appendChild(leaderboardSection(0));
      box.appendChild(guestWrap);
      return;
    }

    var meResponse = await C.request(API + '/growth/me');
    if (sequence !== renderSequence) return;
    if (!meResponse.ok || !meResponse.data || !meResponse.data.ok) {
      C.clear(box);
      box.appendChild(errorCard('成长数据加载失败，请稍后再试', function () { renderPage(box); }));
      return;
    }
    var growthMe = meResponse.data;
    var results = await Promise.all([
      C.request(API + '/profile/' + growthMe.studentId),
      C.request(API + '/checkin/status')
    ]);
    if (sequence !== renderSequence) return;
    var profileResponse = results[0];
    var statusResponse = results[1];
    if (!profileResponse.ok || !profileResponse.data || !profileResponse.data.ok) {
      C.clear(box);
      box.appendChild(errorCard('身份卡加载失败，请稍后再试', function () { renderPage(box); }));
      return;
    }
    var profile = profileResponse.data.profile;
    var status = statusResponse.ok && statusResponse.data && statusResponse.data.ok
      ? statusResponse.data
      : { checkedToday: growthMe.checkedToday, streak: growthMe.checkinStreak, checkinTotal: growthMe.checkinTotal, recent: [] };
    var checkedToday = typeof status.checkedToday === 'boolean' ? status.checkedToday : !!growthMe.checkedToday;

    C.clear(box);
    var wrap = el('div', 'cm-me-root');
    wrap.appendChild(renderIdentity(profile, growthMe));
    wrap.appendChild(renderEditForm(profile));
    wrap.appendChild(renderCheckin(status, checkedToday));
    wrap.appendChild(leaderboardSection(growthMe.studentId));
    wrap.appendChild(renderPosts(profileResponse.data.posts || []));
    box.appendChild(wrap);
  }

  var module = {
    deactivate: function () { renderSequence += 1; },
    render: function (container) {
      renderPage(container);
    },
    refresh: function () {
      if (lastBox) renderPage(lastBox);
    }
  };

  window.CZCommunityShell.register('me', module);
  window.CZCommunityGrowth = { refresh: module.refresh };
})();
