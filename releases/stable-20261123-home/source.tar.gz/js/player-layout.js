/* Shared teacher/live/replay workspace: 960x540 stage, 200px sidebar, 12px gap. */
(function(){
 'use strict';
 var page=document.querySelector('.live-studio .page,.replay-studio .page,.teacher-studio .wrap'),header=document.querySelector('.watch-header,.teacher-studio .topbar');
 if(!page||!header)return;
 var frame=0;
 function fit(){
  frame=0;var sidebar=page.querySelector('.right-col');
  var hidden=page.classList.contains('sidebar-hidden')||(sidebar&&sidebar.classList.contains('hidden'));
  var width=window.innerWidth||document.documentElement.clientWidth,height=window.innerHeight||document.documentElement.clientHeight;
  var top=header.getBoundingClientRect().bottom,base=hidden?960:1172,space=Math.max(1,height-top-24);
  var scale=Math.min(1.1,Math.max(1,width-24)/base,space/540),left=(width-base*scale)/2;
  page.style.width=base+'px';page.style.left=left+'px';page.style.top=(top+12+Math.max(0,(space-540*scale)/2))+'px';page.style.transform='scale('+scale+')';
  header.style.paddingLeft=Math.max(12,left)+'px';header.style.paddingRight=Math.max(12,left)+'px';document.body.setAttribute('data-layout-ready','true');
  if(document.body.classList.contains('teacher-studio')){document.body.setAttribute('data-studio-ready','true');var status=document.querySelector('.msgbar');if(status){status.style.left=left+'px';status.style.top=Math.min(parseFloat(page.style.top)+540*scale+8,height-20)+'px';status.style.width=(base*scale)+'px';}}
 }
 function schedule(){if(!frame)frame=requestAnimationFrame(fit);}
 window.addEventListener('resize',schedule);window.addEventListener('orientationchange',schedule);
 if(window.visualViewport)window.visualViewport.addEventListener('resize',schedule);
 if(window.MutationObserver){var observer=new MutationObserver(schedule);observer.observe(page,{attributes:true,attributeFilter:['class']});var sidebar=page.querySelector('.right-col');if(sidebar)observer.observe(sidebar,{attributes:true,attributeFilter:['class']});}
 window.fitPlayerWorkspace=fit;
 if(document.body.classList.contains('teacher-studio'))window.fitTeacherStudio=fit;
 fit();
})();
