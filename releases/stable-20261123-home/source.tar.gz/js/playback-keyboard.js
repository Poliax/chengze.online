(function(){
 function init(){
  const video=document.getElementById('mainVideo')||document.getElementById('watchVideo')||document.getElementById('player');
  if(!video||video.dataset.keyboardPlayback)return;video.dataset.keyboardPlayback='true';
  document.addEventListener('keydown',function(event){
   if(event.defaultPrevented||event.repeat||event.isComposing||event.ctrlKey||event.metaKey||event.altKey||event.shiftKey)return;
   const space=event.code==='Space'||event.key===' ',key=String(event.key||'').toLowerCase();if(!space&&key!=='k')return;
   const target=event.target;
   if(Array.from(document.querySelectorAll('dialog[open],[role="dialog"][aria-modal="true"]:not([hidden])')).some(el=>el.getClientRects().length&&getComputedStyle(el).visibility!=='hidden'))return;
   if(target&&target.closest&&target.closest('input,textarea,select,[contenteditable]:not([contenteditable="false"]),[role="textbox"],[role="slider"]'))return;
   // Let Space activate focused buttons/links natively; never toggle twice.
   if(space&&target&&target.closest&&target.closest('button,a[href],[role="button"]'))return;
   event.preventDefault();const play=document.getElementById('playBtn');
   if(play)play.click();else if(video.paused||video.ended)Promise.resolve(video.play()).catch(()=>{});else video.pause();
  });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
