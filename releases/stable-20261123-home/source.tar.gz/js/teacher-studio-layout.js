(function(){
function fitStudioStage() {
      var wrap = document.querySelector('.wrap');
      var topbar = document.querySelector('.topbar');
      var status = document.querySelector('.msgbar');
      if (!wrap || !topbar) return;
      var viewportWidth = window.innerWidth || document.documentElement.clientWidth;
      var viewportHeight = window.innerHeight || document.documentElement.clientHeight;
      var headerBottom = topbar.getBoundingClientRect().bottom;
      var availableWidth = Math.max(1, viewportWidth - 24);
      var availableHeight = Math.max(1, viewportHeight - headerBottom - 48);
      // Base camera width is 200px; cap enlargement at 220px.
      var scale = Math.min(1.1, availableWidth / 1172, availableHeight / 540);
      var left = (viewportWidth - 1172 * scale) / 2;
      var top = headerBottom + 12 + Math.max(0, (availableHeight - 540 * scale) / 2);
      wrap.style.left = left + 'px';
      wrap.style.top = top + 'px';
      wrap.style.transform = 'scale(' + scale + ')';
      topbar.style.paddingLeft=Math.max(12,left)+'px';topbar.style.paddingRight=Math.max(12,left)+'px';
      document.body.setAttribute('data-studio-ready','true');
      if (status) {
        status.style.left = left + 'px';
        status.style.top = (top + 540 * scale + 8) + 'px';
        status.style.width = (1172 * scale) + 'px';
      }
    }
window.fitTeacherStudio=fitStudioStage;fitStudioStage();
})();
