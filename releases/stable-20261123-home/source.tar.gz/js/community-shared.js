/* 社区 v2 前端共享工具：转义 / 请求 / 时间 / 头像 / 空态 / 轻提示。
 * 所有服务器文本必须先经 esc() 或 textContent 注入，禁止直接拼进 HTML。 */
(function () {
  'use strict';

  function esc(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function viewer() {
    if (window.CZ_VIEWER && typeof window.CZ_VIEWER === 'object') return window.CZ_VIEWER;
    return { signedIn: false, name: '', avatar: '' };
  }

  function signedIn() {
    return !!viewer().signedIn;
  }

  function el(tag, className, text) {
    const node = document.createElement(tag || 'div');
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }

  // 头像：有头像用 img，否则首字色块（颜色由 id 稳定散列）。
  function avatarEl(student, size) {
    const item = student || {};
    const name = String(item.name || item.nickname || '学员');
    const wrap = el('span', 'cm-avatar');
    wrap.dataset.avatarGender = item.gender || 'unknown';
    wrap.style.width = (size || 40) + 'px';
    wrap.style.height = (size || 40) + 'px';
    if (item.avatar) {
      const img = document.createElement('img');
      img.src = String(item.avatar);
      img.alt = '';
      img.loading = 'lazy';
      wrap.appendChild(img);
      return wrap;
    }
    const palette = ['#28554a', '#7c5a3a', '#4b5f8a', '#8a4b5f', '#5f7a4b', '#6b4b8a'];
    const seed = Number(item.id) || String(name).charCodeAt(0) || 1;
    wrap.style.background = palette[Math.abs(seed) % palette.length];
    wrap.appendChild(el('span', 'cm-avatar-text', Array.from(name)[0] || '学'));
    return wrap;
  }

  function displayName(student) {
    const item = student || {};
    const nickname = String(item.nickname || '').trim();
    if (nickname) return nickname;
    const name = String(item.name || '').trim();
    if (name) return Array.from(name)[0] + '同学';
    return '学员';
  }

  function timeAgo(text) {
    const raw = String(text || '');
    if (!raw) return '';
    const stamp = Date.parse(raw.replace(' ', 'T') + (/Z|[+-]\d\d:?\d\d$/.test(raw) ? '' : 'Z'));
    if (!Number.isFinite(stamp)) return raw.slice(0, 16);
    const diff = Date.now() - stamp;
    if (diff < 60 * 1000) return '刚刚';
    if (diff < 60 * 60 * 1000) return Math.floor(diff / 60000) + ' 分钟前';
    if (diff < 24 * 60 * 60 * 1000) return Math.floor(diff / 3600000) + ' 小时前';
    if (diff < 7 * 24 * 60 * 60 * 1000) return Math.floor(diff / 86400000) + ' 天前';
    return raw.slice(0, 10);
  }

  function emptyEl(text) {
    return el('div', 'cm-empty', text || '暂无内容');
  }

  function loadingEl(text) {
    return el('div', 'cm-loading', text || '加载中…');
  }

  let toastTimer = null;
  function toast(message) {
    let node = document.getElementById('czCommunityToast');
    if (!node) {
      node = el('div', 'cm-toast');
      node.id = 'czCommunityToast';
      node.setAttribute('role', 'status');
      document.body.appendChild(node);
    }
    node.textContent = String(message || '');
    node.classList.add('is-show');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { node.classList.remove('is-show'); }, 2200);
  }

  async function request(url, options) {
    const settings = options || {};
    const init = { method: settings.method || (settings.body !== undefined ? 'POST' : 'GET'), headers: {} };
    if (settings.body !== undefined) {
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(settings.body);
    }
    try {
      const response = await fetch(url, init);
      const text = await response.text();
      let data = null;
      try { data = text ? JSON.parse(text) : null; } catch (e) { data = null; }
      return { ok: response.ok && !!(data && data.ok !== false), status: response.status, data, text };
    } catch (e) {
      return { ok: false, status: 0, data: null, text: '' };
    }
  }

  // 未登录时给出提示并打开登录弹窗；返回是否已登录。
  function requireLogin(actionText) {
    if (signedIn()) return true;
    toast(actionText ? (actionText + '前请先登录') : '请先登录');
    if (typeof window.openAuthModal === 'function') {
      try { window.openAuthModal(); } catch (e) { /* 兼容 */ }
    }
    return false;
  }

  function fmtCount(n) {
    const v = Number(n) || 0;
    if (v >= 10000) return (v / 10000).toFixed(1).replace(/\.0$/, '') + 'w';
    return String(v);
  }

  function clear(node) {
    if (!node) return;
    while (node.firstChild) node.removeChild(node.firstChild);
  }

  window.CZCommunity = {
    esc: esc,
    escAttr: esc,
    el: el,
    avatarEl: avatarEl,
    displayName: displayName,
    timeAgo: timeAgo,
    emptyEl: emptyEl,
    loadingEl: loadingEl,
    toast: toast,
    request: request,
    signedIn: signedIn,
    viewer: viewer,
    requireLogin: requireLogin,
    fmtCount: fmtCount,
    clear: clear
  };
})();
