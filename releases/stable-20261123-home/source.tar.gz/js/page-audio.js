(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory;
  else root.createPageAudio = factory;
}(typeof window === 'undefined' ? null : window, function (video, win, url) {
  'use strict';
  var nav = win.navigator || {};
  var ios = /iPad|iPhone|iPod/.test(nav.userAgent || '') || (nav.platform === 'MacIntel' && nav.maxTouchPoints > 1);
  var Context = win.AudioContext || win.webkitAudioContext;
  var corsSafe = false;
  try {
    var parsed = new URL(url, win.location && win.location.href || 'http://localhost/');
    corsSafe = /^https?:$/.test(parsed.protocol) && /\.(mp4|m4v)$/i.test(parsed.pathname) && ((win.location && parsed.origin === win.location.origin) || /\.vod-qcloud\.com$/i.test(parsed.hostname));
  } catch (_) {}
  var mode = ios ? (Context && corsSafe ? 'gain' : 'system') : 'native';
  var level = Number.isFinite(video.volume) ? video.volume : 1;
  var context = null, source = null, gain = null;
  // This must run before assigning src. The verified VOD CDN serves ACAO: *.
  if (mode === 'gain') video.crossOrigin = 'anonymous';
  function value() { return mode === 'gain' ? level : video.volume; }
  function muted() { return video.muted || value() === 0; }
  function sync() {
    if (gain) gain.gain.value = video.muted ? 0 : level;
  }
  function unlock() {
    if (mode !== 'gain' && !context) return Promise.resolve();
    if (!context) {
      try {
        context = new Context();
        gain = context.createGain();
        source = context.createMediaElementSource(video);
        source.connect(gain); gain.connect(context.destination);
        sync();
      } catch (error) {
        // Keep native audio when graph creation is unavailable; never pretend the slider works.
        if (source && context) {
          try { source.disconnect(); source.connect(context.destination); } catch (_) { return Promise.reject(error); }
        } else if (context) {
          try { Promise.resolve(context.close()).catch(function () {}); } catch (_) {}
          context = null;
        }
        gain = null; mode = ios ? 'system' : 'native';
      }
    }
    if (context && context.state !== 'running') {
      try { return Promise.resolve(context.resume()); } catch (error) { return Promise.reject(error); }
    }
    return Promise.resolve();
  }
  function setVolume(next) {
    if (!Number.isFinite(next)) return;
    next = Math.max(0, Math.min(1, next));
    if (mode === 'gain') level = next;
    else if (mode === 'native') { try { video.volume = next; } catch (_) {} }
    video.muted = next === 0;
    sync();
  }
  function setMuted(next) { video.muted = !!next; sync(); }
  return { get mode() { return mode; }, getVolume: value, isMuted: muted, setVolume: setVolume, setMuted: setMuted, sync: sync, unlock: unlock };
}));
