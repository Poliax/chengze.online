(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.replayChatTimeline=factory();})(typeof window==='undefined'?null:window,function(){
 function timestamp(m){var raw=String(m.time||m.created_at||'').replace(' ','T');var n=Date.parse(raw+(/Z$|[+-]\d{2}:?\d{2}$/.test(raw)?'':'Z'));return Number.isFinite(n)?n:0;}
 return function(messages){
  var start=messages.find(function(m){return m.type==='system'&&m.content==='老师已开始直播'});
  var origin=start?timestamp(start):(messages.length?timestamp(messages[0]):0);
  return messages.map(function(m){var intro=m.type==='system_date'||m.type==='system'&&(m.content==='欢迎来到课堂'||m.content==='老师已开始直播');return {m:m,t:timestamp(m),offset:intro?0:Math.max(0,(timestamp(m)-origin)/1000)};}).sort(function(a,b){return a.offset-b.offset;});
 };
});
