/* Shaanxi past papers. Content and grading are owned by the server. */
(function () {
  'use strict';
  var host, mounted = false, version = 0, clock, saveTimer, saving = null;
  var state = { loading: false, loaded: false, error: '', papers: [], subjects: [], years: [], total: 0, subject: '', year: '', filter: 'all', run: null, paper: null, idx: 0, busy: false, dirty: false, saveError: '', offset: 0, autoFailed: false, zoom:100, mobilePanel:'source', notesOpen:false, showReview:false, reviewFilter:'all', original:false, forceFocus:true, scrollPositions:{},studyAnswers:{} };
  function esc(v) { return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
  function signedIn() { return !!(window.CZ_VIEWER && window.CZ_VIEWER.signedIn); }
  function api(path, body) {
    return fetch('/api/practice/papers' + path, { method: body === undefined ? 'GET' : 'POST', credentials:'same-origin', headers: body === undefined ? {} : {'Content-Type':'application/json'}, body:body === undefined ? undefined : JSON.stringify(body) }).then(function(r) { return r.json().then(function(d) { if (!r.ok || !d.ok) throw Error(d.error || '请求失败'); return d; }); });
  }
  function btn(label, action, attrs, primary) { return '<button type="button" class="pz-btn ' + (primary ? 'pz-btn-primary' : 'pz-btn-ghost') + '" data-paper-action="' + action + '" ' + (attrs || '') + '>' + esc(label) + '</button>'; }
  function message(text) { return '<div class="pz-alert" role="alert">' + esc(text) + '</div>'; }
  function qs() { return state.paper.sections.reduce(function(a,s,si) { return a.concat(s.questions.map(function(q) { return Object.assign({ section:s, sectionIndex:si },q); })); },[]); }
  function answered(q) { var v = state.run.answers[q.id]; return v !== undefined && v !== null && String(v).trim() !== ''; }
  function isStudy(){return !!(state.run&&state.run.mode==='study');}
  function remaining() {if(isStudy())return Infinity; return Math.max(0, Math.ceil((state.run.deadline - Date.now() - state.offset)/1000)); }
  function time(n) { return String(Math.floor(n/60)).padStart(2,'0') + ':' + String(n%60).padStart(2,'0'); }
  function load() {
    var current = ++version; state.loading = true; state.error = ''; render();
    return api('/?province=61').then(function(d) { if (current !== version) return; state.papers=d.papers; state.subjects=d.subjects; state.years=d.years; state.total=d.total; state.loaded=true; state.loading=false; render(); }).catch(function(e) { if (current !== version) return; state.loading=false; state.error=e.message; render(); });
  }
  function sectionScores(p) {
    if(!p.sectionSummary || !p.sectionSummary.length)return '';
    return '<table class="pp-section-scores" aria-label="试卷题型与分值"><thead><tr><th scope="col">题型</th><th scope="col">题量</th><th scope="col">每题分值</th><th scope="col">总分</th></tr></thead><tbody>'+p.sectionSummary.map(function(s){return '<tr><td>'+esc(s.title.replace(/^[一二三四五六七八九十]+[、．.\s]*/,''))+'</td><td>'+esc(s.count)+'</td><td>'+s.pointGroups.map(function(g){return esc(g.points)+'分'+(s.pointGroups.length>1?' × '+esc(g.count)+'题':'');}).join('<br>')+'</td><td>'+esc(s.totalPoints)+'分</td></tr>';}).join('')+'</tbody></table>';
  }
  function catalogue() {
    var html = '<header class="pp-intro"><div><span class="pz-eyebrow">PAST PAPERS / 陕西专升本</span><h2>历年真题</h2><p>把一套卷做完整，把每一道题弄明白。</p></div></header>';
    html += '<div class="pp-note">陕西统考 · 大学英语 / 大学语文 / 高等数学<span>有答案的客观题自动判分，主观题对照参考答案复盘</span></div>';
    if (state.error) return html + message(state.error) + btn('重新加载','reload');
    if (state.loading) return html + '<div class="pz-empty" role="status">正在整理历年试卷…</div>';
    var list = state.papers.filter(function(p) { return !state.subject || p.subject===state.subject; });
    if (!list.length) return html + '<section class="pp-no-papers"><h3>试卷正在整理</h3><p>'+esc(state.subject || '陕西三科')+'的真题核对完成后，即可在这里作答。</p>'+btn('刷新试卷','reload')+'</section>';
    return html + '<div class="pp-paper-grid">'+list.map(function(p) { var r=p.latestRun; return '<article class="pp-paper-card"><div class="pp-card-meta"><span>'+esc(p.year)+'年陕西专升本</span><small>'+(p.edition==='recall'?'回忆版':'真题卷')+'</small></div><h4>'+esc(p.subject)+'</h4><p class="pp-score-summary"><span>'+esc(p.totalPoints)+'分</span><span>'+esc(p.durationMinutes)+'分钟</span></p>'+sectionScores(p)+'<div class="pp-card-bottom"><span>'+(r ? r.status==='submitted' ? (r.pendingPoints && !r.objectivePoints ? '已交卷 · 答案待补充' : '客观题 '+r.score+' / '+r.objectivePoints+' 分') : r.expired?'上次答卷已到时':'有未完成的答卷' : '还未开始')+'</span><div class="pp-card-actions">'+btn('模考',r?'resume':'start','data-id="'+esc(r?r.id:p.id)+'"',true)+btn('学习','learn','data-id="'+esc(p.id)+'"')+'</div></div></article>'; }).join('')+'</div>';
  }

  function workspace() {
    if (!state.run.workspace) state.run.workspace={};
    if (!Array.isArray(state.run.workspace.flagged)) state.run.workspace.flagged=[];
    if (!state.run.workspace.notes) state.run.workspace.notes={};
    if (!state.run.workspace.highlights) state.run.workspace.highlights={};
    return state.run.workspace;
  }
  function highlighted(value,q,shared,scope,key) {
    if(window.PaperAnnotations)return window.PaperAnnotations.renderText(value,q,shared,scope||'stem',key||q.id);
    var text=String(value || ''), marks=workspace().highlights, phrases=[];
    qs().forEach(function(item){if(item.id===q.id || shared && q.readingText && item.readingText===q.readingText)phrases=phrases.concat(marks[item.id] || []);});
    var ranges=[];
    phrases.forEach(function(phrase){var at=0;while(phrase && (at=text.indexOf(phrase,at))>=0){ranges.push([at,at+phrase.length]);at+=phrase.length;}});
    ranges.sort(function(a,b){return a[0]-b[0];});var merged=[];
    ranges.forEach(function(r){var last=merged[merged.length-1];if(last && r[0]<=last[1])last[1]=Math.max(last[1],r[1]);else merged.push(r.slice());});
    var html='',at=0;merged.forEach(function(r){html+=esc(text.slice(at,r[0]))+'<mark class="cbt-highlight">'+esc(text.slice(r[0],r[1]))+'</mark>';at=r[1];});return html+esc(text.slice(at));
  }
  function markSelection() {
    if(!state.run || state.run.status!=='open' || state.busy || !remaining())return;
    var selection=window.getSelection && window.getSelection();
    var anchor=selection && selection.anchorNode, focus=selection && selection.focusNode;
    var a=anchor && (anchor.nodeType===1?anchor:anchor.parentElement), b=focus && (focus.nodeType===1?focus:focus.parentElement);
    var text=selection?selection.toString():'';
    if(!text.trim() || text.length>500 || !a || !b || !host.contains(a) || !host.contains(b) || !a.closest('.cbt-selectable') || a.closest('.cbt-selectable')!==b.closest('.cbt-selectable')){
      var hint=host.querySelector('.cbt-mark-hint');if(hint)hint.textContent='先选中一段文字（最多500字），再点击标记';return;
    }
    var item=a.closest('.cbt-answer-item'),qid=item&&item.getAttribute('data-question-id');
    var q=qid?qs().find(function(row){return row.id===qid;}):qs()[state.idx],marks=workspace().highlights[q.id] || [];
    if(marks.indexOf(text)<0 && marks.length<60){marks.push(text);workspace().highlights[q.id]=marks;scheduleSave();}
    selection.removeAllRanges();render();
  }
  function annotationAttrs(scope,key,qid) {return window.PaperAnnotations?window.PaperAnnotations.attrs(scope,key,qid):'';}
  function bindStudyTools(){if(window.PaperStudyTools)window.PaperStudyTools.bind(host,{run:function(){return state.run;},paper:function(){return state.paper;},question:function(){return qs()[state.idx];},isStudy:isStudy});}
  function bindAnnotations() {
    if(!window.PaperAnnotations)return;
    window.PaperAnnotations.bind(host,{run:function(){return state.run;},paper:function(){return state.paper;},questions:qs,index:function(){return state.idx;},canEdit:function(){return mounted&&state.run&&state.run.status==='open'&&!state.busy&&!!remaining();},isStudy:isStudy,studySelection:function(kind,selection){if(window.PaperStudyTools)window.PaperStudyTools.open(kind,selection.quote,selection.questionId);},blocked:function(){return !mounted||state.busy||state.showReview;},changed:scheduleSave,refresh:render,locate:function(entry){var at=qs().findIndex(function(q){return q.id===entry.questionId;});if(at<0)return;state.idx=at;state.showReview=false;state.forceFocus=true;state.mobilePanel=/^(stem|option)$/.test(entry.anchor.scope)?'answer':'source';if(entry.anchor.scope==='pdf')state.original=false;else if(entry.anchor.scope==='reading')state.original=true;render();var root=Array.prototype.find.call(host.querySelectorAll('[data-ann-id]'),function(el){return el.getAttribute('data-ann-id')===entry.id;});if(root&&root.scrollIntoView)root.scrollIntoView({block:'center',inline:'nearest'});window.PaperAnnotations.afterLocate();}});
  }
  function flagged(q) { return workspace().flagged.indexOf(q.id)>=0; }
  function wordCount(text) { return (String(text || '').match(/[A-Za-z]+(?:['’-][A-Za-z]+)*|\d+(?:\.\d+)?|[\u3400-\u9fff]/g) || []).length; }
  function questionButton(q,i,review) {
    var result=review && state.run.result.items[i];
    var status=review && q.type==='choice' && result && result.correct!==null ? result.correct?' correct':' wrong' : answered(q)?' answered':'';
    return '<button type="button" class="cbt-number'+status+(i===state.idx?' current':'')+(flagged(q)?' flagged':'')+'" data-paper-action="jump" data-index="'+i+'" aria-label="第 '+(i+1)+' 题'+(answered(q)?'，已答':'，未答')+(flagged(q)?'，待检查':'')+'"'+(i===state.idx?' aria-current="step"':'')+'>'+(i+1)+(flagged(q)?'<span aria-hidden="true">•</span>':'')+'</button>';
  }
  function reviewPanel(questions,review) {
    var missing=questions.filter(function(q){return !answered(q);}).length;
    var marks=questions.filter(flagged).length;
    return '<div class="cbt-review-backdrop"><section class="cbt-review-panel" role="dialog" aria-modal="true" aria-labelledby="cbtReviewTitle"><header><div><span class="pz-eyebrow">REVIEW / 作答检查</span><h2 id="cbtReviewTitle">'+(isStudy()?'学习进度':review?'答卷总览':'交卷前，再检查一次')+'</h2></div>'+btn('关闭','close-review')+'</header><div class="cbt-review-counts"><span><b>'+questions.filter(answered).length+'</b> 已作答</span><span><b>'+missing+'</b> 未作答</span><span><b>'+marks+'</b> 待检查</span></div><div class="cbt-review-filters">'+[['all','全部'],['missing','未作答'],['flagged','待检查']].map(function(f){return btn(f[1],'review-filter','data-value="'+f[0]+'" aria-pressed="'+(state.reviewFilter===f[0])+'"',state.reviewFilter===f[0]);}).join('')+'</div><div class="cbt-review-list">'+state.paper.sections.map(function(s,si){var rows=questions.filter(function(q){return q.sectionIndex===si && (state.reviewFilter==='all'||state.reviewFilter==='missing'&&!answered(q)||state.reviewFilter==='flagged'&&flagged(q));});return rows.length?'<section><h3>'+esc(s.title)+'</h3><div class="cbt-review-grid">'+rows.map(function(q){return questionButton(q,questions.indexOf(q),review);}).join('')+'</div></section>':'';}).join('')+'</div><footer><p>'+(isStudy()?'学习进度自动保存，不计入考试成绩。':review?'选择题号可回看原题和自己的答案。':missing?'还有 '+missing+' 题未作答，交卷后将不能修改答案。':'全部题目均已作答，确认后提交本卷。')+'</p>'+btn('继续检查','close-review')+(!review&&!isStudy()?btn(state.busy?'正在交卷…':'确认交卷','confirm-submit',state.busy?'disabled':'',true):'')+'</footer></section></div>';
  }
  function readingGroup(q) {
    return q.type==='choice' && q.readingText ? qs().filter(function(item){return item.sectionIndex===q.sectionIndex && item.readingText===q.readingText;}):[q];
  }
  function passageTitle(q) {
    if(state.paper.subject!=='大学英语' || !/Reading/.test(q.section.title))return '阅读材料';
    var seen=[];qs().forEach(function(item){if(item.sectionIndex===q.sectionIndex && item.readingText && seen.indexOf(item.readingText)<0)seen.push(item.readingText);});
    return 'Passage '+(['One','Two','Three','Four'][seen.indexOf(q.readingText)] || (seen.indexOf(q.readingText)+1));
  }
  function originalPage(page) {
    var phrases=[],all=qs(),marks=workspace().highlights;
    all.forEach(function(q){if((q.sourceImages||[]).indexOf(page.src)>=0)phrases=phrases.concat(marks[q.id]||[]);});
    var normalized='',spans=[];
    page.words.forEach(function(w){var text=w.t.replace(/\s/g,'');spans.push([normalized.length,normalized.length+text.length]);normalized+=text;});
    var ranges=[];phrases.forEach(function(phrase){phrase=phrase.replace(/\s/g,'');var at=0;while(phrase && (at=normalized.indexOf(phrase,at))>=0){ranges.push([at,at+phrase.length]);at+=phrase.length;}});
    var rich=window.PaperAnnotations?window.PaperAnnotations.pdfMarks(page,spans,normalized):null;
    return '<div class="cbt-pdf-page"><img class="cbt-page-image" src="'+esc(page.src)+'" alt="可选文字的试卷原页" decoding="async" draggable="false"><div class="cbt-pdf-text cbt-selectable"'+annotationAttrs('pdf',page.src,qs()[state.idx].id)+' aria-label="原卷可选文字层">'+page.words.map(function(w,i){var range=spans[i],marked=ranges.some(function(r){return r[0]<range[1] && r[1]>range[0];});var pieces=rich&&rich[i]||[],annotation=pieces.length&&pieces[pieces.length-1].entry,overlays=pieces.map(function(piece){return '<i aria-hidden="true" class="cbt-pdf-annotation ann-'+piece.entry.kind+' ann-'+piece.entry.color+'" style="left:'+(piece.from*100)+'%;width:'+((piece.to-piece.from)*100)+'%"></i>';}).join('');return '<span class="cbt-pdf-word'+(!rich&&marked?' cbt-pdf-marked':'')+'"'+(annotation?window.PaperAnnotations.annotationAttrs(annotation):'')+' style="left:'+(100*w.x/page.width)+'%;top:'+(100*w.y/page.height)+'%;width:'+(100*w.w/page.width)+'%;height:'+(100*w.h/page.height)+'%;font-size:'+(100*w.h/page.width)+'cqw">'+esc(w.t)+' '+overlays+'</span>';}).join('')+'</div></div>';
  }
  function answerItem(q,index,review) {
    var run=state.run,result=review?run.result.items.find(function(item){return item.questionId===q.id;}):isStudy()?{correct:run.answers[q.id]===q.answer}:null;
    var html='<section class="cbt-answer-item'+(index===state.idx?' current':'')+'" data-question-id="'+esc(q.id)+'" data-question-index="'+index+'"><div class="cbt-item-meta">第 '+(index+1)+' 题 · '+q.points+' 分'+(readingGroup(q).length>1&&!review?btn(flagged(q)?'已标记待检查':'标记待检查','flag','data-question-index="'+index+'" aria-label="标记第 '+(index+1)+' 题待检查" aria-pressed="'+flagged(q)+'"',flagged(q)):'')+'</div><h3 class="cbt-stem"><span class="cbt-inline-number">'+(index+1)+'.</span> <span class="cbt-selectable"'+annotationAttrs('stem',q.id,q.id)+'>'+highlighted(q.displayStem||q.content,q,false,'stem',q.id)+'</span></h3>';
    if(q.type==='choice')html+='<div class="cbt-options" role="group" aria-label="第 '+(index+1)+' 题答案">'+q.options.map(function(o,i){var selected=run.answers[q.id]===i;var cls=review&&q.answer!==null?(i===q.answer?' correct':selected?' wrong':''):selected?' selected':'';return '<button type="button" class="cbt-option'+cls+'" data-paper-action="choice" data-question-index="'+index+'" data-index="'+i+'" aria-pressed="'+selected+'"'+(review||state.busy||!remaining()?' disabled':'')+'><span>'+String.fromCharCode(65+i)+'</span><span class="cbt-selectable"'+annotationAttrs('option',q.id+':'+i,q.id)+'>'+highlighted(q.optionLabels&&q.optionLabels[i]||o,q,false,'option',q.id+':'+i)+'</span></button>';}).join('')+'</div><p class="cbt-selection-state" role="status">'+(run.answers[q.id]===undefined?'本题尚未选择答案':(review?'你的答案：':'已选择：')+String.fromCharCode(65+run.answers[q.id]))+'</p>';
    else html+='<label class="cbt-writing"><span>你的作答</span><textarea data-paper-change="text" aria-label="第'+(index+1)+'题作答" maxlength="20000" placeholder="在此输入答案或解题过程…"'+(review||state.busy||!remaining()?' disabled':'')+'>'+esc(run.answers[q.id]||'')+'</textarea><small data-word-count>字词数 '+wordCount(run.answers[q.id])+'</small></label>';
    if(isStudy())html+=btn(state.studyAnswers[q.id]?'收起答案与解析':'查看答案与解析','study-answer','data-id="'+esc(q.id)+'"');
    if(review||isStudy()&&state.studyAnswers[q.id])html+='<div class="cbt-feedback">'+(q.answer===null?'<b>参考答案待补充</b><p>本题作答已保存，尚未判分，不计为答错。</p>':'<b>'+(q.type==='text'?'参考答案':(result.correct?'回答正确':'本题未答对')+' · 正确答案 '+String.fromCharCode(65+q.answer))+'</b>'+(q.type==='text'?'<p>'+esc(q.answer)+'</p>':'')+'<p>'+esc(q.explanation||'暂无详细解析')+'</p>')+'</div>';
    return html+'</section>';
  }
  function session() {
    bindAnnotations();bindStudyTools();
    var run=state.run, paper=state.paper, questions=qs(), review=run.status==='submitted';
    var q=questions[state.idx], count=questions.filter(answered).length;
    var result=review && run.result.items.find(function(i){return i.questionId===q.id;});
    var reading=q.readingText || q.section.passage || q.displayStem || q.content;
    if(!q.readingText && !q.section.passage && q.type==='choice')reading+='\n\n'+q.options.map(function(o,i){return String.fromCharCode(65+i)+'. '+(q.optionLabels&&q.optionLabels[i]||o);}).join('\n\n');
    var group=readingGroup(q),grouped=group.length>1;
    var pages=(paper.sourcePages||[]).filter(function(page){return (q.sourceImages||[]).indexOf(page.src)>=0;});
    var useText=grouped || state.original || !pages.length;
    var sourceKey=useText?'reading:'+reading.slice(0,100):'original:'+(q.sourceImages || []).join('|');
    var saveText=review?'答卷已保存':state.saveError?'保存失败，请重试':state.dirty||saving?'正在保存…':'已自动保存';
    var html='<section class="cbt-workspace" aria-label="真题机考工作台" style="--cbt-zoom:'+state.zoom+'%;--cbt-scale:'+(state.zoom/100)+'" data-mobile-panel="'+state.mobilePanel+'" data-run-state="'+(review?'review':'open')+'"><header class="cbt-topbar"><div class="cbt-paper-name">'+btn('退出作答','back',state.busy?'disabled':'')+'<div><span>承泽 · 真题练习</span><h2>'+esc(paper.year+' '+paper.subject)+'</h2></div></div><div class="cbt-top-progress"><span data-paper-count>已答 '+count+' / '+questions.length+'</span><span class="cbt-save-state" role="status">'+esc(saveText)+'</span></div><div class="cbt-top-actions"><div class="cbt-clock"><small>'+(isStudy()?'学习':review?'作答用时':'剩余时间')+'</small><strong id="ppTimer"'+(!review&&remaining()<300?' class="urgent"':'')+'>'+(isStudy()?'不限时':time(review?run.result.durationSeconds:remaining()))+'</strong></div>'+btn(isStudy()?'生词本':review?'答卷总览':'检查并交卷',isStudy()?'study-words':'submit',state.busy?'disabled':'',true)+'</div></header>';
    html+='<div class="cbt-modebar" role="group" aria-label="真题模式">'+btn('模考','mode','data-value="exam" aria-pressed="'+(!isStudy())+'"'+(!isStudy()?' disabled':''),!isStudy())+btn('学习','mode','data-value="study" aria-pressed="'+isStudy()+'"'+(isStudy()?' disabled':''),isStudy())+'<span>'+(isStudy()?'不限时 · 查词、记生词、分析句子 · 已开始的考试仍按原截止时间计时':'限时作答 · 学习进度单独保存')+'</span></div>';
    html+='<div class="cbt-session-strip"><span>'+esc(q.section.title)+'</span><span>'+(isStudy()?'学习记录与考试答卷分别保存':review?'已交卷 · 当前为只读复盘':paper.unkeyedCount?'本卷参考答案待补充 · 作答会保存，暂不判分':'客观题交卷后统一判分')+'</span></div>';
    if(review)html+='<div class="cbt-readonly" role="status"><div><b>这份答卷已交卷，选项已锁定</b><span>当前只能回看。若想继续练习，请新开一轮，原答卷会保留。</span></div>'+btn('重新作答','start','data-id="'+esc(paper.id)+'"',true)+'</div>';
    if(review)html+='<div class="cbt-result" role="status">'+(run.result.pendingPoints&&!run.result.objectivePoints?'答卷已保存，答案待补充':'客观题 '+run.result.score+' / '+run.result.objectivePoints+' 分')+(run.result.subjectivePoints&&!run.result.pendingPoints?' · 主观题 '+run.result.subjectivePoints+' 分请对照参考答案自评':'')+'</div>';
    if(state.saveError||state.error)html+='<div class="cbt-error" role="alert">'+esc(state.saveError||state.error)+btn('重试保存','save')+btn('重新载入','restore','data-id="'+run.id+'"')+'</div>';
    html+='<div class="cbt-mobile-tabs">'+btn('阅读题目','mobile-panel','data-value="source" aria-pressed="'+(state.mobilePanel==='source')+'"',state.mobilePanel==='source')+btn('填写答案','mobile-panel','data-value="answer" aria-pressed="'+(state.mobilePanel==='answer')+'"',state.mobilePanel==='answer')+'</div>';
    html+='<div class="cbt-main"><article class="cbt-source-pane"><header class="cbt-pane-toolbar"><div><b>'+(grouped?passageTitle(q):useText?'文字阅读':'原卷排版')+'</b><span>第 '+(state.idx+1)+' 题</span></div><div class="cbt-source-tools">'+(!grouped?btn(useText?'原卷排版':'文字阅读','source-mode'):'')+btn('−','zoom-out','aria-label="缩小题目"')+'<span>'+state.zoom+'%</span>'+btn('+','zoom-in','aria-label="放大题目"')+'<a class="pz-btn" href="'+esc(paper.sourceUrl)+'" target="_blank" rel="noopener noreferrer">原PDF</a></div></header>'+(window.PaperAnnotations?window.PaperAnnotations.toolbar():'<div class="cbt-mark-tools">'+(!review?btn('标记选中文字','highlight')+btn('清除本题标记','clear-highlights'):'')+'<span class="cbt-mark-hint" role="status">'+(review?'已保存的文字标记':'选中文字后点击标记')+'</span></div>')+(isStudy()&&window.PaperStudyTools?window.PaperStudyTools.toolbar():'')+'<div class="cbt-document" data-source-key="'+esc(sourceKey)+'" tabindex="0" aria-label="题目阅读区">';
    if(useText)html+='<div class="cbt-reading-paper">'+(grouped?'<h2 class="cbt-passage-heading">'+esc(passageTitle(q))+'</h2>':'')+'<div class="cbt-reading-text cbt-selectable"'+annotationAttrs('reading',readingGroup(q)[0].id,q.id)+'>'+highlighted(reading,q,true,'reading',readingGroup(q)[0].id)+'</div></div>';
    else if(pages.length)html+='<div class="cbt-pages cbt-original-pages">'+pages.map(originalPage).join('')+'</div>';
    else if((q.sourceImages || []).length)html+='<div class="cbt-pages">'+q.sourceImages.map(function(src){return '<img class="cbt-page-image" src="'+esc(src)+'" alt="第 '+(state.idx+1)+' 题对应原卷页" decoding="async">';}).join('')+'</div>';
    else html+='<div class="cbt-reading-text">'+esc(q.displayStem||q.content)+'</div>';
    html+='</div></article><article class="cbt-answer-pane"><header class="cbt-pane-toolbar"><div><b>'+(grouped?passageTitle(q):'第 '+(state.idx+1)+' 题')+'</b><span>'+(grouped?'第 '+(questions.findIndex(function(item){return item.id===group[0].id;})+1)+'–'+(questions.findIndex(function(item){return item.id===group[group.length-1].id;})+1)+' 题 · 向下滚动作答':q.points+' 分 · '+(q.type==='choice'?(q.options.length===2?'判断题':'单选题'):'主观题'))+'</span></div>'+(!review&&!grouped?btn(flagged(q)?'已标记待检查':'标记待检查','flag','aria-pressed="'+flagged(q)+'"',flagged(q)):'')+'</header><div class="cbt-answer-scroll" data-answer-group="'+esc(group.map(function(item){return item.id;}).join('-'))+'">'+group.map(function(item){return answerItem(item,questions.findIndex(function(row){return row.id===item.id;}),review);}).join('');
    html+='<div class="cbt-notes-toggle">'+btn((state.notesOpen?'收起':'')+(grouped?'第 '+(state.idx+1)+' 题笔记':'本题笔记')+(workspace().notes[q.id]?' · 已记录':''),'notes','aria-expanded="'+state.notesOpen+'"')+'</div>';
    if(state.notesOpen)html+='<label class="cbt-notes"><span>只供自己复习，不作为答题内容</span><textarea data-paper-change="note" maxlength="5000" aria-label="第'+(state.idx+1)+'题笔记" placeholder="记下思路、疑问或待回看的位置…"'+(review?' readonly':'')+'>'+esc(workspace().notes[q.id]||'')+'</textarea></label>';
    html+='</div><footer class="cbt-answer-footer">'+btn('上一题','prev',state.idx===0?'disabled':'')+'<span>'+(state.idx+1)+' / '+questions.length+'</span>'+btn(state.idx===questions.length-1?(isStudy()?'学习进度':'检查本卷'):'下一题','next',state.busy?'disabled':'',true)+'</footer></article></div>';
    html+='<nav class="cbt-bottom-nav" aria-label="大题与题号导航"><div class="cbt-sections">'+paper.sections.map(function(s,si){var group=questions.filter(function(item){return item.sectionIndex===si;});return '<button type="button" data-paper-action="section" data-index="'+questions.indexOf(group[0])+'" aria-pressed="'+(si===q.sectionIndex)+'"><span>'+esc(s.title)+'</span><small>'+group.filter(answered).length+' / '+group.length+'</small></button>';}).join('')+'</div><div class="cbt-question-row"><div class="cbt-question-numbers">'+questions.filter(function(item){return item.sectionIndex===q.sectionIndex;}).map(function(item){return questionButton(item,questions.indexOf(item),review);}).join('')+'</div><div class="cbt-legend"><span>● 已答</span><span>• 待检查</span>'+btn('全部题目','review-open')+'</div></div></nav>';
    if(state.showReview)html+=reviewPanel(questions,review);
    return html+'</section>';
  }
  function render() {
    if(!mounted||!host)return;
    var old=host.querySelector('.cbt-document'),oldAnswer=host.querySelector('.cbt-answer-scroll'),answerScroll=oldAnswer?oldAnswer.scrollTop:0,answerKey=oldAnswer&&oldAnswer.getAttribute('data-answer-group'),focusAnswer=state.forceFocus;
    if(old)state.scrollPositions[old.getAttribute('data-source-key')]=old.scrollTop;
    host.innerHTML='<div class="pp-studio">'+(state.run && (!state.lockedSubject || state.paper.subject === state.lockedSubject) ? session() : catalogue())+'</div>';
    var doc=host.querySelector('.cbt-document');
    if(doc){
      var q=qs()[state.idx],key=doc.getAttribute('data-source-key'),image=doc.querySelector('.cbt-page-image');
      var desired=state.forceFocus&&!q.readingText?null:state.scrollPositions[key];
      function place(){if(!mounted||!doc.isConnected)return;doc.scrollTop=desired===undefined||desired===null?(image?image.offsetTop+q.sourceFocus*image.clientHeight-24:0):desired;}
      if(image&&!image.complete)image.addEventListener('load',place,{once:true});else place();
      state.forceFocus=false;
    }
    var answer=host.querySelector('.cbt-answer-scroll');
    if(answer){var active=answer.querySelector('.cbt-answer-item.current');if(focusAnswer&&active)answer.scrollTop=Math.max(0,active.offsetTop-12);else if(answer.getAttribute('data-answer-group')===answerKey)answer.scrollTop=answerScroll;}
    var current=host.querySelector('.cbt-question-numbers [aria-current="step"]');
    if(current&&current.scrollIntoView)current.scrollIntoView({block:'nearest',inline:'nearest'});
    if(state.run&&window.PaperAnnotations)window.PaperAnnotations.afterRender();
    if(window.PaperStudyTools)window.PaperStudyTools.afterRender();
    var dialog=host.querySelector('.cbt-review-panel');
    if(dialog){var first=dialog.querySelector('button');if(first)first.focus();}
  }
  function accept(d,restoreCursor) {
    if(!state.run||state.run.id!==d.run.id){state.scrollPositions={};state.studyAnswers={};}
    state.run=d.run; state.paper=d.paper; workspace();
    if(restoreCursor){var cursor=qs().findIndex(function(q){return q.id===workspace().cursor;});state.idx=cursor>=0?cursor:0;} state.offset=d.run.serverNow-Date.now(); state.dirty=false; state.saveError=''; state.error=''; state.autoFailed=false;
    clearInterval(clock); if(!isStudy())clock=setInterval(tick,1000); render();
  }
  function openRun(id, start, discard, mode) {
    if (state.busy) return;
    if (!signedIn()) { if (window.openAuthModal) window.openAuthModal(); return; }
    if (discard && !window.confirm('重新载入将使用服务器保存的答卷，本页尚未保存的修改会丢失。继续？')) return;
    if (discard) state.dirty=false;
    state.busy=true; state.error=''; render();
    // Finish any queued writes to the current run before replacing it.
    (discard ? Promise.resolve() : save()).then(function() { return start?api('/'+encodeURIComponent(id)+'/start',{province:'61',mode:mode||'exam'}):api('/runs/'+id); }).then(function(d) { state.idx=0; state.showReview=false; state.forceFocus=true; state.busy=false; accept(d,true); }).catch(function(e) {state.busy=false;state.error=e.message;render();});
  }
  function save() {
    clearTimeout(saveTimer);
    if (saving) return saving.then(function() {return save();});
    if (!state.run || state.run.status==='submitted' || !state.dirty) return Promise.resolve();
    var run=state.run, answers=Object.assign({},run.answers), savedWorkspace=JSON.parse(JSON.stringify(workspace())); state.dirty=false;
    saving=api('/runs/'+run.id+'/save',{revision:run.revision,answers:answers,workspace:savedWorkspace}).then(function(d) {
      if (state.run!==run) return;
      run.revision=d.run.revision; state.saveError='';
      if (d.run.status==='submitted') accept(d);
      else {var el=mounted && host.querySelector('.cbt-save-state'); if(el)el.textContent=state.dirty?'正在保存…':'已自动保存';}
    }).catch(function(e) {state.dirty=true;state.saveError=e.message;render();throw e;}).finally(function(){saving=null;});
    return saving.then(function() {if(state.dirty)return save();});
  }
  function scheduleSave() {
    if(state.run&&state.paper)workspace().cursor=qs()[state.idx].id;
    state.dirty=true;state.saveError='';clearTimeout(saveTimer);
    var el=mounted&&host.querySelector('.cbt-save-state');if(el)el.textContent='正在保存…';
    saveTimer=setTimeout(function(){save().catch(function(){});},450);
  }
  function changed(value) {
    if (!state.run || state.run.status!=='open' || state.busy || !remaining()) return;
    var questions=qs(), q=questions[state.idx]; state.run.answers[q.id]=value; state.dirty=true; state.saveError='';
    if (mounted) {
      var status=host.querySelector('.cbt-save-state'); if(status)status.textContent='正在保存作答…';
      var count=host.querySelector('[data-paper-count]'); if(count)count.textContent='已答 '+questions.filter(answered).length+' / '+questions.length;
      var number=host.querySelector('[data-paper-action="jump"][data-index="'+state.idx+'"]');
      if(number){number.classList.toggle('answered',answered(q));number.setAttribute('aria-label','第 '+(state.idx+1)+' 题'+(answered(q)?'，已答':'，未答'));}
    }
    var words=mounted&&host.querySelector('[data-word-count]');if(words)words.textContent='字词数 '+wordCount(value);
    scheduleSave();
  }
  function submit(auto) {
    if (!state.run || isStudy() || state.busy || state.run.status!=='open') return;
    var missing=qs().filter(function(q){return !answered(q);}).length;
    if(!auto && !state.showReview){state.showReview=true;state.reviewFilter='all';render();return;}
    state.busy=true; state.error=''; render();
    save().then(function(){if(state.run.status==='submitted')return null;return api('/runs/'+state.run.id+'/submit',{revision:state.run.revision,answers:state.run.answers,workspace:workspace()});}).then(function(d){state.busy=false;state.showReview=false;if(d)accept(d);else render();}).catch(function(e){state.busy=false;state.autoFailed=true;state.error=e.message;render();});
  }
  function tick() {
    if (!state.run || isStudy() || state.run.status==='submitted') { clearInterval(clock); return; }
    var el=mounted&&document.getElementById('ppTimer');if(el)el.textContent=time(remaining());
    if(!remaining()&&!state.busy&&!state.autoFailed)submit(true);
  }
  function click(action,target) {
    var index=Number(target.getAttribute('data-index'));
    if(action==='reload')load();
    else if(action==='subject'){state.subject=target.getAttribute('data-value');render();}
    else if(action==='restore')openRun(target.getAttribute('data-id'),false,true);
    else if(action==='start'||action==='resume')openRun(target.getAttribute('data-id'),action==='start');
    else if(action==='learn')openRun(target.getAttribute('data-id'),true,false,'study');
    else if(action==='mode'&&state.paper)openRun(state.paper.id,true,false,target.getAttribute('data-value'));
    else if(action==='study-words'&&isStudy()&&window.PaperStudyTools)window.PaperStudyTools.open('words');
    else if(action==='study-answer'&&isStudy()){var qid=target.getAttribute('data-id');state.studyAnswers[qid]=!state.studyAnswers[qid];render();}
    else if(action==='save')save().then(render).catch(function(){});
    else if(action==='back') {if(state.busy)return;save().then(function(){state.run=null;state.paper=null;clearInterval(clock);load();}).catch(function(){});}
    else if(action==='submit'){state.showReview=true;state.reviewFilter='all';render();}
    else if(action==='confirm-submit')submit(false);
    else if(action==='review-open'){state.showReview=true;state.reviewFilter='all';render();}
    else if(action==='close-review'){state.showReview=false;render();}
    else if(action==='review-filter'){state.reviewFilter=target.getAttribute('data-value');render();}
    else if(action==='flag'&&state.run&&!state.busy&&state.run.status==='open'){var flagIndex=target.getAttribute('data-question-index');if(flagIndex!==null){var fi=Number(flagIndex);if(!Number.isInteger(fi)||fi<0||fi>=qs().length)return;state.idx=fi;}var q=qs()[state.idx],flags=workspace().flagged;var at=flags.indexOf(q.id);if(at<0)flags.push(q.id);else flags.splice(at,1);scheduleSave();render();}
    else if(action==='notes'){state.notesOpen=!state.notesOpen;render();}
    else if(action==='source-mode'){state.original=!state.original;state.forceFocus=true;render();}
    else if(action==='zoom-in'||action==='zoom-out'){state.zoom=Math.min(150,Math.max(80,state.zoom+(action==='zoom-in'?10:-10)));render();}
    else if(action==='mobile-panel'){state.mobilePanel=target.getAttribute('data-value');render();}
    else if(action==='highlight')markSelection();
    else if(action==='clear-highlights'&&state.run&&state.run.status==='open'&&!state.busy&&remaining()) {var current=qs()[state.idx];qs().forEach(function(item){if(item.id===current.id || current.readingText && item.readingText===current.readingText)delete workspace().highlights[item.id];});scheduleSave();render();}
    else if(action==='choice'&&state.run&&state.run.status==='open'&&!state.busy&&remaining()){
      var selection=window.getSelection&&window.getSelection();if(selection&&!selection.isCollapsed&&target.contains&&target.contains(selection.anchorNode))return;
      var itemIndex=target.getAttribute('data-question-index');if(itemIndex!==null){var qi=Number(itemIndex);if(!Number.isInteger(qi)||qi<0||qi>=qs().length)return;state.idx=qi;}
      var current=qs()[state.idx];if(current.type!=='choice'||index<0||index>=current.options.length||!Number.isInteger(index))return;
      changed(index);
      if(isStudy()){state.studyAnswers[current.id]=true;scheduleSave();render();return;}
      if(state.idx+1<qs().length){state.idx++;state.showReview=false;state.forceFocus=true;state.mobilePanel='answer';scheduleSave();}
      else {state.showReview=true;state.reviewFilter='all';}
      render();
    }
    else if(state.run&&(action==='prev'||action==='next'||action==='jump'||action==='section')) {var next=(action==='jump'||action==='section')?index:state.idx+(action==='prev'?-1:1);if(next===qs().length){state.showReview=true;render();}else if(next>=0&&next<qs().length){state.idx=next;state.showReview=false;state.forceFocus=true;if(state.run.status==='open'&&!state.busy)scheduleSave();render();}}
  }
  window.PastPaperStudio={mount:function(box,subject){if(subject){var mapped=subject === '英语' ? '大学英语' : subject === '语文' ? '大学语文' : subject;state.subject=mapped;state.lockedSubject=mapped;}host=box;mounted=true;if(!state.loaded&&!state.loading)load();else render();},unmount:function(){mounted=false;}};
  document.addEventListener('click',function(e){var target=e.target.closest('[data-paper-action]');if(mounted&&target&&host.contains(target)&&!target.disabled)click(target.getAttribute('data-paper-action'),target);});
  document.addEventListener('mousedown',function(e){var target=e.target.closest('[data-paper-action="highlight"]');if(mounted&&target&&host.contains(target))e.preventDefault();});
  document.addEventListener('change',function(e){if(!mounted||!host.contains(e.target))return;var action=e.target.getAttribute('data-paper-change');if(action==='year'||action==='filter'){state[action]=e.target.value;render();}});
  document.addEventListener('input',function(e){if(!mounted||!host.contains(e.target)||!state.run)return;var action=e.target.getAttribute('data-paper-change');if(action==='text')changed(e.target.value);else if(action==='note'&&state.run.status==='open'&&!state.busy){workspace().notes[qs()[state.idx].id]=e.target.value;scheduleSave();}});
  document.addEventListener('keydown',function(e){
    if(!mounted||!state.run)return;
    if(e.target.closest&&e.target.closest('.cbt-annotation-ui,.cbt-study-ui'))return;
    if(e.shiftKey&&/Arrow/.test(e.key))return;
    var dialog=host.querySelector('.cbt-review-panel');
    var scope=dialog||host.querySelector('.cbt-workspace');
    if(scope&&e.key==='Tab'){var controls=Array.prototype.slice.call(scope.querySelectorAll('button:not(:disabled),a[href],textarea:not(:disabled),[tabindex="0"]'));if(!controls.length)return;var current=controls.indexOf(document.activeElement);if(current<0){e.preventDefault();controls[0].focus();return;}if(e.shiftKey&&current<=0){e.preventDefault();controls[controls.length-1].focus();}else if(!e.shiftKey&&current===controls.length-1){e.preventDefault();controls[0].focus();}return;}
    if(e.key==='Escape'&&state.showReview){state.showReview=false;render();return;}
    if(state.showReview||/^(INPUT|TEXTAREA|SELECT|BUTTON)$/.test(e.target.tagName)||e.target.isContentEditable)return;
    if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();click(e.key==='ArrowLeft'?'prev':'next',{getAttribute:function(){return null;}});}
  });
  window.addEventListener('beforeunload',function(e){if(state.dirty||saving){e.preventDefault();e.returnValue='';}});
})();
