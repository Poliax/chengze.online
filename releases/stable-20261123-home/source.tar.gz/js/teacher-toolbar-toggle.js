(function(){
 const toggle=document.getElementById('toolbarToggle'),toolbar=document.getElementById('studioToolbar');
 if(!toggle||!toolbar)return;
 const stage=toolbar.closest('.stage');
 ['pointerdown','mousedown','touchstart'].forEach(name=>toggle.addEventListener(name,event=>event.stopPropagation()));
 toggle.addEventListener('click',event=>{
  event.stopPropagation();const collapsed=stage.classList.toggle('toolbar-collapsed');
  toggle.setAttribute('aria-expanded',String(!collapsed));
  toggle.title=collapsed?'展开工具栏':'收起工具栏';toggle.setAttribute('aria-label',toggle.title);
  toggle.querySelector('path').setAttribute('d','M4 6h16M4 12h16M4 18h16');
  if(collapsed)toolbar.querySelectorAll('.tool-pop.show').forEach(popup=>popup.classList.remove('show'));
 });
})();
