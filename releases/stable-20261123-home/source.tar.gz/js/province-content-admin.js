(()=>{'use strict';
 const filter=document.getElementById('resourceKind');if(filter)filter.addEventListener('change',()=>document.querySelectorAll('[data-resource-kind]').forEach(row=>row.hidden=!!filter.value&&row.dataset.resourceKind!==filter.value));
 const form=document.getElementById('provinceQueryTest'),out=document.getElementById('provinceQueryResult');let version=0;
 if(form)form.addEventListener('submit',async e=>{e.preventDefault();const id=++version;out.textContent='正在查询…';try{const r=await fetch(form.dataset.url+'?year='+form.dataset.year+'&q='+encodeURIComponent(form.elements.keyword.value.trim()));if(!r.ok)throw Error();const d=await r.json();if(id!==version)return;out.textContent=d.rows&&d.rows.length?d.province+' · '+d.year+'年：'+d.rows.map(x=>x.code+' '+x.name).join('；')+(d.isFallback?'（采用最近已收录年份）':''):d.suggestions&&d.suggestions.length?'请选择完整名称：'+d.suggestions.join('、'):'该省份年份暂无匹配的已启用对应关系。';}catch{if(id===version)out.textContent='查询失败，请重试。';}});
})();
