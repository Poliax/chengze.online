(function(){
 const page=document.querySelector('.live-studio .page'),header=document.querySelector('.watch-header');if(!page||!header)return;
 let frame=0;
 function fit(){frame=0;const width=innerWidth,height=innerHeight,full=page.classList.contains('fullscreen-mode'),top=full?0:header.getBoundingClientRect().bottom;const base=full||page.classList.contains('sidebar-hidden')?960:1172,space=Math.max(1,height-top-(full?0:24));const scale=Math.min(full?Infinity:1.1,Math.max(1,width-(full?0:24))/base,space/540);page.style.width=base+'px';page.style.left=(width-base*scale)/2+'px';page.style.top=(top+(full?0:12)+Math.max(0,(space-540*scale)/2))+'px';page.style.transform='scale('+scale+')';const inset=Math.max(12,(width-base*scale)/2);header.style.paddingLeft=inset+'px';header.style.paddingRight=inset+'px';document.body.setAttribute('data-layout-ready','true');}
 function schedule(){if(!frame)frame=requestAnimationFrame(fit);}
 window.addEventListener('resize',schedule);window.addEventListener('orientationchange',schedule);if(window.visualViewport)visualViewport.addEventListener('resize',schedule);new MutationObserver(schedule).observe(page,{attributes:true,attributeFilter:['class']});fit();
})();
