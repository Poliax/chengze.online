(function () {
 'use strict';
 var panel=document.getElementById('authReset');
 if(!panel)return;
 var phone=document.getElementById('resetPhone'),code=document.getElementById('resetCode'),password=document.getElementById('resetPassword');
 var send=document.getElementById('resetSendCode'),submit=document.getElementById('resetSubmit'),message=document.getElementById('resetMessage');
 var accountMode=false;
 var dialog=document.createElement('dialog');dialog.id='studentPasswordResetDialog';dialog.setAttribute('aria-labelledby','passwordResetHeading');
 dialog.innerHTML='<div class="password-reset-heading"><h2 id="passwordResetHeading" tabindex="-1" autofocus>修改登录密码</h2><button type="button" class="cz-icon-action" aria-label="关闭"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg></button></div>';
 document.body.append(dialog);dialog.append(panel);
 dialog.querySelector('button').addEventListener('click',function(){dialog.close();});
 var back=panel.querySelector('button[onclick]');if(back){var backContainer=back.parentElement;back.remove();if(backContainer!==panel&&!backContainer.children.length)backContainer.remove();}
 var confirmField=document.createElement('div');confirmField.className='field';
 confirmField.innerHTML='<label for="resetPasswordConfirm">确认新密码</label><input id="resetPasswordConfirm" type="password" minlength="6" maxlength="64" autocomplete="new-password" placeholder="再次输入新密码" aria-label="再次输入新密码">';
 panel.insertBefore(confirmField,panel.querySelector('.modal-actions'));
 var confirmation=confirmField.querySelector('input');
 phone.setAttribute('aria-label','手机号');code.setAttribute('aria-label','验证码');password.setAttribute('aria-label','新密码');
 var style=document.createElement('style');style.textContent=`
 #studentPasswordResetDialog{position:fixed;inset:0;margin:auto;max-height:calc(100dvh - 32px);overflow:auto;box-sizing:border-box;width:280px;max-width:calc(100vw - 32px);padding:24px;border:.5px solid #DCE1E6;border-radius:12px;background:#fff;color:#475569;box-shadow:0 12px 40px #172d471a}
 #studentPasswordResetDialog::backdrop{background:rgba(25,35,32,.3)}
 #studentPasswordResetDialog .password-reset-heading{display:grid;grid-template-columns:29px minmax(0,1fr) 29px;align-items:center;gap:8px;margin:0 -24px 20px;padding:0 24px 16px;border-bottom:.5px solid #DCE1E6}
 #studentPasswordResetDialog h2{grid-column:2;grid-row:1;text-align:center;margin:0;font-size:16px;line-height:24px;font-weight:600;color:#303943;outline:none}
 #studentPasswordResetDialog #authReset{display:block;width:100%;margin:0}
 #studentPasswordResetDialog .auth-reset-title{display:none}
 #studentPasswordResetDialog .field{margin:0 0 14px}
 #studentPasswordResetDialog .field label{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
 #studentPasswordResetDialog .field input{box-sizing:border-box;width:100%;min-width:0;height:29px;padding:0 10px;border:1px solid #dedee3;border-radius:8px;font:inherit;font-size:12px;color:#475569;background:#fff}
 #studentPasswordResetDialog .auth-reset-code{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:6px}
 #studentPasswordResetDialog .auth-reset-code label{position:absolute}
 #studentPasswordResetDialog button:not(.cz-icon-action){height:29px;padding:0 12px;border:1px solid #dedee3;border-radius:8px;background:#fff;color:#52525b;font-size:12px;line-height:19px;font-weight:500;white-space:nowrap;cursor:pointer}
 #studentPasswordResetDialog .modal-actions{display:flex;justify-content:flex-end;gap:8px;margin:20px -24px -4px;padding:16px 24px 0;border-top:.5px solid #DCE1E6}
 #studentPasswordResetDialog #resetMessage:not(:empty){box-sizing:border-box;width:100%;padding:8px 10px;margin:0 0 14px;border-radius:8px;background:#fff3f1;color:#a33a2e;font-size:12px;line-height:18px}
 #studentPasswordResetDialog #resetMessage:empty{display:none}
 #studentPasswordResetDialog .password-reset-heading>.cz-icon-action{grid-column:3;grid-row:1;display:grid;place-items:center;box-sizing:border-box;width:29px!important;height:29px!important;min-width:29px!important;min-height:29px!important;padding:0!important;border:1px solid #dedee3;border-radius:8px;background:#fff;color:#52525b}
 @layer student-controls {
 body:not(#cz-reset-dialog).student-brand-theme #studentPasswordResetDialog :is(#resetSubmit,.auth-forgot){height:29px!important;min-height:29px!important;padding:0 12px!important;border-radius:8px!important;font-size:12px!important;line-height:19px!important;font-weight:500!important;background:#fff!important;color:#52525b!important;border:1px solid #dedee3!important}
 }
 `;document.head.append(style);
 var busy=false,deadline=0,timer;
 function notice(text){message.textContent=text;}
 function update(){var left=Math.max(0,Math.ceil((deadline-Date.now())/1000));send.disabled=busy||left>0;submit.disabled=busy;send.textContent=left?left+'秒后重发':'获取验证码';submit.textContent=busy?'保存中…':'保存';if(!left&&timer){clearInterval(timer);timer=null;}}
 function validPhone(){if(/^1\d{10}$/.test(phone.value.trim()))return true;notice('请输入正确的手机号');phone.focus();return false;}
 async function post(url,body){var r=await fetch(url,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});var data=await r.json();if(!r.ok||!data.success||data.devCode)throw Error(data.devCode?'短信服务暂不可用':data.error||'操作失败，请重试');return data;}
 window.openPasswordReset=function(options){
  options=options||{};accountMode=!!options.account;
  document.getElementById('passwordResetHeading').textContent=options.setPassword?'设置登录密码':'修改登录密码';
  var value=options.phone||document.getElementById('loginPhone').value.trim();
  document.getElementById('authModal').classList.remove('open');
  if(phone.value!==value){phone.value=value;code.value='';}password.value='';confirmation.value='';notice('');
  phone.readOnly=accountMode;panel.style.display='';dialog.showModal();update();
 };
 phone.addEventListener('input',function(){code.value='';});
 send.addEventListener('click',async function(){
  if(send.disabled||!validPhone())return;
  busy=true;notice('');update();
  try {await post('/api/auth/send-code',{phone:phone.value.trim()});deadline=Date.now()+60000;timer=setInterval(update,1000);notice('验证码已发送，5分钟内有效');code.focus();}
  catch(e){notice(e.message);}finally{busy=false;update();}
 });
 panel.addEventListener('submit',async function(event){
  event.preventDefault();if(busy||!validPhone())return;
  if(!/^\d{6}$/.test(code.value.trim())){notice('请输入6位短信验证码');code.focus();return;}
  if(password.value.length<6||password.value.length>64||!password.value.trim()){notice('请设置6至64位新密码');password.focus();return;}
  if(password.value!==confirmation.value){notice('两次密码不一致');confirmation.focus();return;}
  busy=true;notice('');update();
  try {
   await post('/api/auth/reset-password',{phone:phone.value.trim(),code:code.value.trim(),password:password.value});
   try{localStorage.removeItem('cz_remember_login');}catch(e){}
   document.getElementById('loginPhone').value=phone.value.trim();document.getElementById('loginPassword').value='';
   code.value='';password.value='';confirmation.value='';dialog.close();
   if(accountMode){var status=document.getElementById('studentAccountStatus');if(status)status.textContent='登录密码已更新';var display=document.getElementById('studentPasswordDisplay');if(display){display.hidden=false;display.value='************';display.setAttribute('aria-label','密码已隐藏');}var reset=document.getElementById('studentPasswordReset');if(reset){reset.textContent='修改';reset.dataset.unset='false';}}
   else {window.openAuthModal();window.switchAuth('login');document.getElementById('authMsg').textContent='密码已重设，请使用新密码登录';}

  }catch(e){notice(e.message);}finally{busy=false;update();}
 });
 update();
}());
