/* Study-only vocabulary and sentence tools. Every API also enforces study mode. */
(function(){
 'use strict';
 var host,ctx,runId=null,generation=0;
 var state={open:false,tab:'lookup',loading:false,error:'',query:'',sentence:'',questionId:'',entry:null,analysis:null,capabilities:null,book:[],dueOnly:false,recall:false,revealed:false,rated:false,queue:[],queueIndex:0,notice:''};
 function esc(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
 function button(text,action,attrs){return '<button type="button" data-study-action="'+action+'" '+(attrs||'')+(state.loading&&action!=='close'&&action!=='tab'?' disabled':'')+'>'+esc(text)+'</button>';}
 function enabled(){return ctx&&ctx.run()&&ctx.isStudy();}
 function api(path,body){return fetch('/api/practice/papers/runs/'+ctx.run().id+'/study/'+path,{method:body===undefined?'GET':'POST',credentials:'same-origin',headers:body===undefined?{}:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)}).then(function(r){return r.json().then(function(d){if(!r.ok||!d.ok)throw Error(d.error||'学习工具暂时不可用');return d;});});}
 function perform(path,body,success){
  if(!enabled())return;var ticket=++generation,id=runId;state.loading=true;state.error='';render();
  api(path,body).then(function(d){if(ticket===generation&&id===runId&&enabled())success(d);}).catch(function(e){if(ticket===generation&&id===runId)state.error=e.message;}).finally(function(){if(ticket===generation&&id===runId){state.loading=false;render();}});
 }
 function selection(){var value=window.getSelection&&window.getSelection();var a=value&&value.anchorNode,node=a&&(a.nodeType===1?a:a.parentElement),root=node&&node.closest('.cbt-selectable');return {text:root&&host.contains(root)?value.toString():'',questionId:root&&root.getAttribute('data-ann-question')||ctx.question().id};}
 function open(tab,text,qid){
  if(!enabled())return;var pick=selection();if(window.PaperAnnotations)window.PaperAnnotations.action('dismiss');var native=window.getSelection&&window.getSelection();if(native&&native.removeAllRanges)native.removeAllRanges();state.open=true;state.tab=tab;state.error='';state.notice='';state.questionId=qid||pick.questionId;generation++;state.loading=false;
  if(tab==='lookup'){state.query=text===undefined?pick.text:text;state.entry=null;state.recall=false;state.queue=[];if(state.query.trim())lookup();else render();}
  else if(tab==='words')loadWords();
  else {state.sentence=text===undefined?pick.text:text;state.analysis=null;perform('capabilities',undefined,function(d){state.capabilities=d;if(state.sentence.trim()&&d.grammarAvailable)analyze();});}
 }
 function lookup(){state.recall=false;state.revealed=false;state.rated=false;state.notice='';perform('lookup',{word:state.query,questionId:state.questionId},function(d){state.entry=d.entry;});}
 function collect(remember){if(!state.entry)return;perform('words',{word:state.entry.word,questionId:state.questionId},function(d){state.entry=d.entry;state.notice='已加入真题生词本';if(remember){state.recall=true;state.revealed=false;state.rated=false;state.queue=[];}});}
 function loadWords(){perform('words',undefined,function(d){state.book=d.words;});}
 function analyze(){state.analysis=null;state.notice='';perform('grammar',{sentence:state.sentence,questionId:state.questionId},function(d){state.analysis=d.analysis;state.notice=d.cached?'已载入该句的分析记录':'AI 语法解析已完成，请结合原文核对';});}
 function dueWords(){return state.book.filter(function(w){return !w.stage||w.dueAt<=Date.now();});}
 function recall(entry){state.entry=entry;state.query=entry.word;state.questionId=entry.questionId||state.questionId;state.tab='lookup';state.recall=true;state.revealed=false;state.rated=false;state.notice='';state.error='';render();}
 function rating(value){if(!state.entry||state.rated)return;perform('words/'+encodeURIComponent(state.entry.word)+'/review',{rating:value,revision:state.entry.revision},function(d){Object.assign(state.entry,d);var stored=state.book.find(function(w){return w.word===d.word;});if(stored)Object.assign(stored,d);state.rated=true;state.notice='已记录 · 下次复习 '+new Date(d.dueAt).toLocaleString('zh-CN',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'});});}
 function renderWord(){
  var e=state.entry,html='<div class="study-search"><input type="text" data-study-input="word" aria-label="查找本题英文单词" maxlength="50" value="'+esc(state.query)+'" placeholder="选中或输入本题单词">'+button('查词','lookup')+'</div>';
  if(!e)return html+'<div class="study-empty"><b>在真题中积累词汇</b><p>选中一个英文单词，点击“查单词”，即可查看中文释义、音标与词形。</p></div>';
  html+='<section class="study-word-card"><div class="study-word-heading"><h2>'+esc(e.word)+'</h2>'+button('朗读','speak',(!window.speechSynthesis||!window.SpeechSynthesisUtterance?'disabled ':'')+'aria-label="朗读单词"')+'</div>'+(e.phonetic?'<p class="study-phonetic">/'+esc(e.phonetic)+'/</p>':'')+(e.lemma&&e.lemma.toLowerCase()!==e.word?'<p class="study-lemma">词典原形：'+esc(e.lemma)+'</p>':'');
  if(state.recall&&!state.revealed)html+='<div class="study-recall"><span>先回想这个词的含义</span>'+button('显示释义','reveal')+'</div>';
  else html+='<div class="study-meaning">'+esc(e.meaning||'暂无中文释义')+'</div>'+(e.definition?'<details class="study-definition"><summary>英文释义与用法</summary><p>'+esc(e.definition)+'</p></details>':'')+(e.exchange?'<details class="study-definition"><summary>词形变化</summary><p>'+esc(e.exchange.replace(/\//g,' · ').replace(/(^| · )p:/g,'$1过去式：').replace(/(^| · )d:/g,'$1过去分词：').replace(/(^| · )i:/g,'$1现在分词：').replace(/(^| · )s:/g,'$1复数：').replace(/(^| · )3:/g,'$1第三人称：').replace(/(^| · )r:/g,'$1比较级：').replace(/(^| · )t:/g,'$1最高级：').replace(/(^| · )0:/g,'$1原形：'))+'</p></details>':'');
  html+=(e.context?'<blockquote class="study-context"><small>真题语境</small>'+esc(e.context)+'</blockquote>':'');
  if(!state.recall)html+='<div class="study-word-actions">'+button(e.collected?'已在生词本':'加入生词本','collect',e.collected?'disabled':'')+button('记忆这个单词','remember','class="study-primary"')+'</div>';
  else if(state.revealed&&!state.rated)html+='<div class="study-ratings">'+button('不认识','rating','data-value="again"')+button('有点模糊','rating','data-value="hard"')+button('记住了','rating','data-value="remember"')+'</div>';
  else if(state.rated)html+='<div class="study-word-actions">'+button(state.queueIndex+1<state.queue.length?'下一个生词':'返回生词本','next-word','class="study-primary"')+'</div>';
  return html+'</section><small class="study-source">词典来源：<a href="https://github.com/skywind3000/ECDICT" target="_blank" rel="noopener noreferrer">ECDICT · MIT</a>；词义请结合真题语境理解。</small>';
 }
 function renderBook(){var due=dueWords(),rows=state.dueOnly?due:state.book;return '<div class="study-book-summary"><span><b>'+state.book.length+'</b> 已收录</span><span><b>'+due.length+'</b> 待复习</span>'+button('开始复习','review-book',!due.length?'disabled':'class="study-primary"')+'</div><div class="study-book-filters">'+button('全部生词','all-words','aria-pressed="'+!state.dueOnly+'"')+button('待复习','due-words','aria-pressed="'+state.dueOnly+'"')+'</div><div class="study-word-list">'+(rows.length?rows.map(function(e){return '<button type="button" data-study-action="word-card" data-word="'+esc(e.word)+'"><strong>'+esc(e.word)+'</strong><span>'+esc(e.meaning.split('\n')[0])+'</span><small>'+(e.stage>=5?'熟练':e.stage?'复习中':'未开始记忆')+'</small></button>';}).join(''):'<div class="study-empty"><b>'+(!state.book.length?'生词本还是空的':'暂时没有到期单词')+'</b><p>在查词卡片中加入生词，复习时记录自己的记忆情况。</p></div>')+'</div>';}
 function renderGrammar(){var a=state.analysis;return '<label class="study-sentence-label">原文句子<textarea data-study-input="sentence" aria-label="需要分析的英文句子" maxlength="1000" rows="4" placeholder="选中原文中的英文句子，或粘贴本题句子">'+esc(state.sentence)+'</textarea></label>'+button(state.loading?'正在分析…':'分析这个句子','analyze','class="study-primary"')+(state.capabilities&&!state.capabilities.grammarAvailable?'<p class="study-config-note">AI 接口尚未配置，配置后可重新分析。</p>':'')+(a?'<div class="study-analysis"><section><h3>句意</h3><p>'+esc(a.translation)+'</p></section><section><h3>句子主干</h3><p>'+esc(a.structure)+'</p></section><section><h3>成分与从句</h3>'+a.clauses.map(function(c){return '<article><span>'+esc(c.role)+'</span><q>'+esc(c.text)+'</q><p>'+esc(c.explanation)+'</p></article>';}).join('')+'</section><section><h3>语法要点</h3>'+a.grammarPoints.map(function(g){return '<article><b>'+esc(g.title)+'</b><p>'+esc(g.explanation)+'</p></article>';}).join('')+'</section><small>AI 辅助分析，仅供学习核对，不作为试卷参考答案。</small></div>':'<p class="study-empty">可分析句子主干、主谓宾、修饰成分、从句关系和语法要点。</p>');}
 function render(){
  var old=host&&host.querySelector('.cbt-study-panel');if(old)old.remove();if(!enabled()||!state.open)return;
  var panel=document.createElement('aside');panel.className='cbt-study-panel cbt-study-ui';panel.setAttribute('aria-label','真题学习工具');
  panel.innerHTML='<header><div><span>STUDY / 真题精读</span><h2>边做题，边学懂</h2></div>'+button('×','close','aria-label="关闭学习工具"')+'</header><nav aria-label="学习工具">'+[['lookup','查词'],['words','生词本'],['grammar','句子分析']].map(function(t){return button(t[1],'tab','data-value="'+t[0]+'" aria-pressed="'+(state.tab===t[0])+'"');}).join('')+'</nav><div class="study-panel-body">'+(state.error?'<div class="study-error" role="alert">'+esc(state.error)+'</div>':'')+(state.notice?'<p class="study-notice" role="status">'+esc(state.notice)+'</p>':'')+(state.loading?'<p class="study-loading" role="status">正在读取…</p>':'')+(state.tab==='lookup'?renderWord():state.tab==='words'?renderBook():renderGrammar())+'</div>';
  var workspace=host.querySelector('.cbt-workspace');if(workspace)workspace.appendChild(panel);
 }
 function action(name,target){if(!enabled())return;
  if(name==='close'){generation++;state.loading=false;state.open=false;render();}
  else if(name==='tab')open(target.getAttribute('data-value'),'');
  else if(name==='lookup')lookup();
  else if(name==='analyze')analyze();
  else if(name==='collect')collect(false);
  else if(name==='remember'){if(state.entry.collected){state.recall=true;state.revealed=false;state.rated=false;state.queue=[];render();}else collect(true);}
  else if(name==='reveal'){state.revealed=true;render();}
  else if(name==='rating')rating(target.getAttribute('data-value'));
  else if(name==='speak'&&state.entry&&window.speechSynthesis&&window.SpeechSynthesisUtterance){var utterance=new window.SpeechSynthesisUtterance(state.entry.word);utterance.lang='en-US';utterance.rate=.85;window.speechSynthesis.cancel();window.speechSynthesis.speak(utterance);}
  else if(name==='due-words'||name==='all-words'){state.dueOnly=name==='due-words';render();}
  else if(name==='review-book'){state.queue=dueWords().slice();state.queueIndex=0;if(state.queue.length)recall(state.queue[0]);}
  else if(name==='word-card'){var e=state.book.find(function(w){return w.word===target.getAttribute('data-word');});if(e){state.queue=[];recall(e);}}
  else if(name==='next-word'){state.queueIndex++;if(state.queueIndex<state.queue.length)recall(state.queue[state.queueIndex]);else open('words');}
 }
 function bind(box,context){host=box;ctx=context;if(!enabled()||runId!==ctx.run().id){generation++;state.open=false;state.loading=false;state.entry=null;state.analysis=null;state.book=[];state.queue=[];state.capabilities=null;state.error='';state.notice='';runId=ctx.run()&&ctx.run().id;}}
 function toolbar(){return '<div class="cbt-study-toolbar cbt-study-ui"><span>精读工具</span><button type="button" data-study-open="lookup">选词查词</button><button type="button" data-study-open="grammar">分析句子</button><button type="button" data-study-open="words">我的生词本</button></div>';}
 document.addEventListener('mousedown',function(e){if(host&&host.contains(e.target)&&e.target.closest('[data-study-open]'))e.preventDefault();});
 document.addEventListener('click',function(e){if(!enabled()||!host.contains(e.target))return;var opener=e.target.closest('[data-study-open]'),target=e.target.closest('[data-study-action]');if(opener){e.preventDefault();open(opener.getAttribute('data-study-open'));}else if(target){e.preventDefault();e.stopImmediatePropagation();if(!target.disabled)action(target.getAttribute('data-study-action'),target);}});
 document.addEventListener('input',function(e){if(!enabled()||!host.contains(e.target))return;var field=e.target.getAttribute('data-study-input');if(field==='word')state.query=e.target.value;else if(field==='sentence')state.sentence=e.target.value;});
 document.addEventListener('keydown',function(e){if(!enabled()||!host.contains(e.target))return;if(e.key==='Escape'&&state.open){e.preventDefault();e.stopImmediatePropagation();state.open=false;render();}else if(e.key==='Enter'&&e.target.getAttribute('data-study-input')==='word'){e.preventDefault();lookup();}});
 window.PaperStudyTools={bind:bind,toolbar:toolbar,afterRender:render,open:open};
})();
