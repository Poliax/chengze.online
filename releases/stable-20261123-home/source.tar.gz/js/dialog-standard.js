/* Shared form-dialog chrome. Keep business handlers and existing form nodes. */
(function(){
 if(typeof document==='undefined'||document.documentElement.dataset.czDialogStandard)return;
 document.documentElement.dataset.czDialogStandard='true';
 const selector='dialog,.teacher-body .modal-box,.teacher-body .modal-content,.user-dialog-content,.order-dialog-content';
 const icon='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>';
 function normalize(root){
  if(root.dataset.czDialog||root.closest('#authModal,.resource-preview,.player-wrap')||root.id==='resourcePreviewDialog')return;
  // An outer native dialog may receive its form through a later request.
  const title=root.querySelector('h1,h2,h3');if(!title||title.closest(selector)!==root)return;
  const excluded=root.matches('[data-dialog-layout="custom"]');if(excluded)return;
  root.dataset.czDialog='form';
  if(root.tagName!=='DIALOG'){root.setAttribute('role','dialog');root.setAttribute('aria-modal','true');}
  if(!title.id)title.id='cz-dialog-title-'+Math.random().toString(36).slice(2);
  root.setAttribute('aria-labelledby',title.id);
  let header=title.parentElement;
  if(!header.matches('.admin-dialog-heading,.course-detail-modal__header,.password-reset-heading,.phone-change-heading,.cancel-dialog-heading,.student-order-dialog-header,.student-order-dialog-heading,header')){
   header=document.createElement('div');title.before(header);header.append(title);
  }
  header.dataset.czDialogHeader='';title.dataset.czDialogTitle='';
  let close=root.querySelector('button[aria-label^="关闭"],button.course-detail-modal__close,button.student-order-dialog-close');
  const cancels=Array.from(root.querySelectorAll('button[type="button"]')).filter(b=>b.textContent.trim()==='取消');
  if(!close){
   close=cancels.find(b=>/close|cancel/i.test(b.id))||cancels[0];
   if(!close){close=document.createElement('button');close.type='button';close.addEventListener('click',()=>{if(root.tagName==='DIALOG')root.close();else{const overlay=root.closest('.modal-overlay,.modal');if(overlay){overlay.classList.remove('open','active','show');overlay.style.display='none';}}});}
  }
  close.setAttribute('aria-label','关闭');close.classList.add('cz-icon-action');close.dataset.czDialogClose='';close.innerHTML=icon;header.append(close);
  for(const cancel of cancels)if(cancel!==close){cancel.hidden=true;cancel.dataset.czDialogCancel='';}
  const submit=root.querySelector('button[type="submit"],.form-actions button.btn-primary,.modal-actions button.primary,.student-order-dialog-submit');
  if(submit){
   let footer=submit.closest('.form-actions,.modal-actions,.student-cancel-actions,.student-order-dialog-actions');
   if(!footer||!root.contains(footer))footer=submit.parentElement;
   if(footer===root||footer===submit.form){footer=document.createElement('div');submit.before(footer);footer.append(submit);}
   footer.dataset.czDialogFooter='';
  }
 }
 function scan(node){if(node.nodeType!==1)return;if(node.matches(selector))normalize(node);for(const root of node.querySelectorAll(selector))normalize(root);const parent=node.closest(selector);if(parent)normalize(parent);}
 scan(document.body);
 new MutationObserver(records=>{for(const record of records)for(const node of record.addedNodes)scan(node);}).observe(document.body,{childList:true,subtree:true});
})();
