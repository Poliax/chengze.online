(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory;
  else root.createReplayMedia = factory;
}(typeof window === 'undefined' ? null : window, function (doc, win, options) {
  'use strict';
  var main = doc.getElementById('mainVideo');
  var camera = doc.getElementById('camVideo');
  if (!main) return null;
  var playBtn = doc.getElementById('playBtn'), playIcon = doc.getElementById('playIcon');
  var muteBtn = doc.getElementById('muteBtn'), range = doc.getElementById('volRange');
  var on = doc.getElementById('volOn'), off = doc.getElementById('volOff');
  var status = doc.getElementById('playbackStatus'), hint = doc.getElementById('volumeHint');
  var nav = win.navigator || {};
  var hardwareVolume = /iPad|iPhone|iPod/.test(nav.userAgent || '') || (nav.platform === 'MacIntel' && nav.maxTouchPoints > 1);
  var audio = win.createPageAudio ? win.createPageAudio(main, win, options && options.sourceUrl) : null;
  function pageVolume() { return audio ? audio.getVolume() : main.volume; }
  function pageMuted() { return audio ? audio.isMuted() : main.muted || main.volume === 0; }
  function setPageVolume(value) { if (audio) audio.setVolume(value); else { try { main.volume = value; } catch (_) {} main.muted = value === 0; } }
  function setPageMuted(value) { if (audio) audio.setMuted(value); else main.muted = value; }
  function unlockAudio() { if (audio) audio.unlock().then(syncVolume, function () { message('声音未能启用，请再次点击播放或音量按钮。'); }); }
  var lastVolume = pageVolume() > 0 ? pageVolume() : 1;
  var operation = 0, cameraPending = false;
  function message(text) {
    if (!status) return;
    status.textContent = text || ''; status.hidden = !text;
  }
  function silentCamera() {
    if (!camera) return;
    camera.defaultMuted = true;
    if (!camera.muted) camera.muted = true;
  }
  function syncPlay() {
    var playing = !main.paused && !main.ended;
    if (playIcon) playIcon.innerHTML = playing ? '<rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/>' : '<polygon points="5,3 19,12 5,21"/>';
    if (playBtn) {
      playBtn.setAttribute('aria-label', playing ? '暂停' : '播放');
      playBtn.setAttribute('aria-pressed', String(playing));
      playBtn.title = playing ? '暂停' : '播放';
    }
  }
  function syncVolume() {
    if (audio) audio.sync();
    var muted = pageMuted();
    if (on) on.style.display = muted ? 'none' : 'block';
    if (off) off.style.display = muted ? 'block' : 'none';
    if (range) {
      range.value = muted ? '0' : String(Math.round(pageVolume() * 100));
      range.hidden = audio ? audio.mode === 'system' : hardwareVolume;
      range.setAttribute('aria-label', '播放器音量');
      range.setAttribute('aria-valuetext', range.value + '%');
      range.title = '播放器音量 ' + range.value + '%（与设备音量独立）';
    }
    if (hint) { hint.hidden = !(audio ? audio.mode === 'system' : hardwareVolume); hint.textContent = '当前浏览器请用机身音量键'; }
    if (!muted && pageVolume() > 0) lastVolume = pageVolume();
    if (muteBtn) {
      muteBtn.setAttribute('aria-pressed', String(muted));
      muteBtn.setAttribute('aria-label', muted ? '恢复声音' : '静音');
      muteBtn.title = muted ? '恢复声音' : '静音';
    }
    silentCamera();
  }
  var lastCameraSeek = -Infinity;
  function masterRate() { var rate=Number(main.playbackRate);return Number.isFinite(rate)&&rate>0?rate:1; }
  function alignCamera(force) {
    if (!camera || camera.readyState < 1) return;
    var time = main.currentTime || 0;
    if (Number.isFinite(camera.duration)) time = Math.min(time, Math.max(0, camera.duration));
    var drift = time-camera.currentTime,rate=masterRate();
    if(main.seeking||camera.seeking)return;
    var now=win.performance&&win.performance.now?win.performance.now():Date.now();
    // Starting/seeking is explicit. Normal playback corrects small drift without repeated seeks.
    if(force===true||main.paused||(Math.abs(drift)>2&&now-lastCameraSeek>=2000)){
      if(Math.abs(drift)>.08){try{camera.currentTime=time;lastCameraSeek=now;}catch(_){}}
      camera.playbackRate=rate;return;
    }
    var correction=Math.abs(drift)>.08?Math.max(-.04,Math.min(.04,drift*.08)):0;
    camera.playbackRate=rate*(1+correction);
  }
  function playCamera() {
    if (!camera || cameraPending || main.paused || main.ended || !camera.paused) return;
    silentCamera(); alignCamera(true);
    cameraPending = true;
    try {
      Promise.resolve(camera.play()).then(function () {
        cameraPending = false;
        if (main.paused || main.ended) camera.pause();
      }, function () {
        cameraPending = false;
        if (!main.paused && !main.ended) message('教师画面暂时无法播放，授课和声音可继续。');
      });
    } catch (_) { cameraPending = false; message('教师画面暂时无法播放，授课和声音可继续。'); }
  }
  function stop() {
    operation++;
    main.pause(); if (camera) camera.pause();
    if (playBtn) playBtn.setAttribute('aria-busy', 'false');
    syncPlay();
  }
  function togglePlay() {
    if (!main.paused && !main.ended) { stop(); return Promise.resolve(); }
    var token = ++operation;
    message(''); silentCamera(); unlockAudio();
    if (playBtn) playBtn.setAttribute('aria-busy', 'true');
    var pending;
    // Both play calls stay inside the original user gesture; only the master is audible.
    try { pending = main.play(); }
    catch (error) { pending = Promise.reject(error); }
    playCamera();
    return Promise.resolve(pending).then(function () {
      if (token !== operation) return;
      if (playBtn) playBtn.setAttribute('aria-busy', 'false');
      syncPlay();
    }, function () {
      if (token !== operation) return;
      main.pause(); if (camera) camera.pause();
      if (playBtn) playBtn.setAttribute('aria-busy', 'false');
      syncPlay(); message('授课视频未能开始播放，请再次点击播放；仍无响应时请刷新重试。');
    });
  }
  if (playBtn) playBtn.addEventListener('click', togglePlay);
  main.addEventListener('click', function () { togglePlay(); });
  main.addEventListener('play', function () { syncPlay(); playCamera(); });
  main.addEventListener('pause', function () { if (camera) camera.pause(); syncPlay(); });
  main.addEventListener('ended', function () { if (camera) camera.pause(); syncPlay(); });
  main.addEventListener('error', function () { stop(); message('授课视频加载失败，请刷新重试。'); });
  main.addEventListener('volumechange', syncVolume);
  main.addEventListener('seeked', function(){alignCamera(true);});
  main.addEventListener('ratechange', function(){if(camera)camera.playbackRate=masterRate();});
  main.addEventListener('timeupdate', alignCamera);
  if (camera) {
    camera.addEventListener('volumechange', silentCamera);
    camera.addEventListener('loadedmetadata', function(){alignCamera(true);});
  }
  if (muteBtn) muteBtn.addEventListener('click', function () {
    unlockAudio();
    var muted = pageMuted();
    if (muted) {
      if (pageVolume() === 0) setPageVolume(lastVolume || 1);
      setPageMuted(false);
    } else {
      lastVolume = pageVolume() || lastVolume;
      setPageMuted(true);
    }
    syncVolume();
  });
  if (range) {
    range.hidden = hardwareVolume;
    range.addEventListener('input', function () {
      unlockAudio();
      if (audio ? audio.mode === 'system' : hardwareVolume) { syncVolume(); return; }
      var value = Number(range.value);
      if (!Number.isFinite(value)) return;
      var volume = Math.max(0, Math.min(1, value / 100));
      if (volume > 0) lastVolume = volume;
      setPageVolume(volume);
      setPageMuted(volume === 0);
      syncVolume();
    });
  }

  var full = doc.getElementById('fullBtn');
  if (full) full.addEventListener('click', function () {
    var stage = doc.getElementById('mainBox');
    var target = doc.fullscreenElement || doc.webkitFullscreenElement ? doc : stage;
    var fn = target === doc ? (doc.exitFullscreen || doc.webkitExitFullscreen) : (stage.requestFullscreen || stage.webkitRequestFullscreen);
    if (!fn && target !== doc && main.webkitEnterFullscreen) { target = main; fn = main.webkitEnterFullscreen; }
    if (!fn) { message('当前浏览器不支持此全屏方式。'); return; }
    try { Promise.resolve(fn.call(target)).catch(function () { message('暂时无法进入全屏，请重试。'); }); }
    catch (_) { message('暂时无法进入全屏，请重试。'); }
  });
  main.autoplay=false;main.removeAttribute('autoplay');
  if(camera){camera.autoplay=false;camera.removeAttribute('autoplay');}
  setPageMuted(true);
  silentCamera(); syncPlay(); syncVolume();
  return { togglePlay: togglePlay, stop: stop, syncVolume: syncVolume };
}));
