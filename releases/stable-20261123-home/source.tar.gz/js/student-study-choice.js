(function(){
 if(document.getElementById('studentStudyChoiceDialog'))return;
 fetch('/api/auth/study-choice',{cache:'no-store'}).then(response=>response.ok?response.json():null).then(data=>{
  if(!data||!data.success||!data.required)return;
  const dialog=document.createElement('dialog');dialog.id='studentStudyChoiceDialog';dialog.dataset.czDialog='form';dialog.setAttribute('aria-labelledby','studyChoiceTitle');
  dialog.innerHTML='<form><header data-cz-dialog-header><h2 id="studyChoiceTitle" data-cz-dialog-title>选择招考信息</h2></header><div class="study-choice-fields"><p role="alert" hidden></p><select name="province_code" aria-label="招考省份" required><option value="">请选择招考省份</option></select><select name="exam_year" aria-label="考试年份" required><option value="">请选择考试年份</option></select></div><footer data-cz-dialog-footer><button type="submit" class="cz-text-action">保存</button></footer></form>';
  const form=dialog.querySelector('form'),province=form.elements.province_code,year=form.elements.exam_year,button=form.querySelector('button'),message=form.querySelector('[role=alert]');
  data.provinces.forEach(p=>province.add(new Option(p.name,p.code)));data.years.forEach(y=>year.add(new Option(y+'年',y)));
  province.value=data.province_code;year.value=data.exam_year;
  document.body.append(dialog);dialog.addEventListener('cancel',event=>event.preventDefault());dialog.showModal();
  form.addEventListener('submit',async event=>{event.preventDefault();if(button.disabled||!form.reportValidity())return;button.disabled=true;message.hidden=true;
   try{const response=await fetch('/api/auth/study-choice',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({province_code:province.value,exam_year:year.value})});const result=await response.json();if(!response.ok||!result.success)throw Error(result.error||'保存失败，请重试');dialog.close();location.reload();}
   catch(error){message.textContent=error.message;message.hidden=false;button.disabled=false;}
  });
 }).catch(()=>{});
})();
