/* Personal annotations. The answer sheet and its scoring data remain owned by the studio. */
(function () {
  'use strict';
  var host,ctx,runId=null,pending=null,selected=null,panelOpen=false,panelFilter='all',query='',kind='highlight',color='yellow',undo=[],redo=[],draft='',message='',selectionTimer,noteOpen=false,lastIndex=null,preserveSelected=false;
  var COLORS={yellow:'黄色',green:'绿色',blue:'蓝色',pink:'粉色'},KINDS={highlight:'高亮',underline:'下划线',strike:'删除线'};
  function esc(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
  function clone(v){return JSON.parse(JSON.stringify(v));}
  function work(){return ctx.run().workspace;}
  function editable(){return ctx&&ctx.canEdit();}
  function rows(){
    if(!ctx||!ctx.run())return [];
    var all=(work().annotations||[]).slice();
    Object.keys(work().highlights||{}).forEach(function(qid){(work().highlights[qid]||[]).forEach(function(quote,i){all.push({id:'old-'+qid+'-'+i,questionId:qid,kind:'highlight',color:'yellow',quote:quote,note:'',anchor:{scope:'legacy',key:'',start:0,end:0},legacy:true,legacyIndex:i});});});
    return all;
  }
  function byId(id){return rows().find(function(a){return a.id===id;});}
  function snapshot(){return {annotations:clone(work().annotations||[]),highlights:clone(work().highlights||{})};}
  function restore(value){work().annotations=clone(value.annotations);work().highlights=clone(value.highlights);}
  function freshId(){return 'a-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);}
  function record(change){
    if(!editable())return;
    var previous=snapshot();change();
    if(JSON.stringify(previous)===JSON.stringify(snapshot()))return;
    undo.push(previous);if(undo.length>40)undo.shift();redo=[];ctx.changed();ctx.refresh();
  }
  function materialize(a){
    if(!a.legacy)return (work().annotations||[]).find(function(row){return row.id===a.id;});
    var entry=clone(a);delete entry.legacy;delete entry.legacyIndex;entry.id=freshId();
    work().highlights[a.questionId].splice(a.legacyIndex,1);if(!work().annotations)work().annotations=[];work().annotations.push(entry);selected=entry.id;return entry;
  }
  function scopeAttrs(scope,key,qid){return ' data-ann-scope="'+esc(scope)+'" data-ann-key="'+esc(key)+'" data-ann-question="'+esc(qid)+'"';}
  function applies(a,q,shared){
    if(a.questionId===q.id)return true;
    var other=ctx.questions().find(function(row){return row.id===a.questionId;});
    return !!(shared&&q.readingText&&other&&other.readingText===q.readingText);
  }
  function ranges(text,q,shared,scope,key){
    var result=[];
    rows().forEach(function(a){
      if(a.anchor.scope==='legacy'){
        if(!applies(a,q,shared))return;var at=0;
        while((at=text.indexOf(a.quote,at))>=0){result.push({start:at,end:at+a.quote.length,entry:a});at+=a.quote.length;}
      } else if(a.anchor.scope===scope&&a.anchor.key===key)result.push({start:a.anchor.start,end:a.anchor.end,entry:a});
    });
    return result;
  }
  function annotationAttrs(a){return ' data-ann-id="'+esc(a.id)+'" tabindex="0" role="button" aria-label="'+esc(KINDS[a.kind]+'，'+COLORS[a.color]+(a.note?'，有批注':'')+'：'+a.quote.slice(0,120)+'，点击编辑')+'" title="'+esc(a.note||'点击查看或编辑标记')+'"';}
  function renderText(value,q,shared,scope,key){
    var text=String(value||''),marks=ranges(text,q,shared,scope,key),points=[0,text.length];
    marks.forEach(function(r){points.push(Math.max(0,Math.min(text.length,r.start)),Math.max(0,Math.min(text.length,r.end)));});
    points=points.filter(function(p,i,a){return a.indexOf(p)===i;}).sort(function(a,b){return a-b;});
    var html='';
    for(var i=0;i<points.length-1;i++){
      var from=points[i],to=points[i+1],active=marks.filter(function(r){return r.start<to&&r.end>from;}),piece=esc(text.slice(from,to));
      active.forEach(function(r){var a=r.entry;piece='<mark class="cbt-annotation ann-'+a.kind+' ann-'+a.color+(selected===a.id?' ann-active':'')+(a.note?' ann-has-note':'')+'"'+annotationAttrs(a)+'>'+piece+'</mark>';});
      html+=piece;
    }
    return html;
  }
  function pdfMarks(page,spans,normalized){
    var marks=[];
    rows().forEach(function(a){
      if(a.anchor.scope==='pdf'&&a.anchor.key===page.src)marks.push({start:a.anchor.start,end:a.anchor.end,entry:a});
      else if(a.anchor.scope==='legacy'){
        var q=ctx.questions().find(function(q){return q.id===a.questionId;});if(!q||(q.sourceImages||[]).indexOf(page.src)<0)return;
        var quote=a.quote.replace(/\s/g,''),at=0;while(quote&&(at=normalized.indexOf(quote,at))>=0){marks.push({start:at,end:at+quote.length,entry:a});at+=quote.length;}
      }
    });
    // Rectangles use the actual PDF word boxes, preserving formula and page positions.
    return spans.map(function(range){return marks.filter(function(r){return r.start<range[1]&&r.end>range[0];}).map(function(r){return {entry:r.entry,from:(Math.max(range[0],r.start)-range[0])/(range[1]-range[0]),to:(Math.min(range[1],r.end)-range[0])/(range[1]-range[0])};});});
  }
  function colorButtons(value){return '<div class="ann-colors" role="group" aria-label="标记颜色">'+Object.keys(COLORS).map(function(c){return '<button type="button" class="ann-swatch ann-'+c+'" data-annotation-action="color" data-value="'+c+'" aria-label="'+COLORS[c]+'" aria-pressed="'+(value===c)+'"'+(!editable()?' disabled':'')+'>'+(value===c?'✓':'')+'</button>';}).join('')+'</div>';}
  function typeButtons(value){return '<div class="ann-types" role="group" aria-label="标记类型">'+Object.keys(KINDS).map(function(k){return '<button type="button" data-annotation-action="kind" data-value="'+k+'" aria-pressed="'+(value===k)+'"'+(!editable()?' disabled':'')+'>'+KINDS[k]+'</button>';}).join('')+'</div>';}
  function toolbar(){
    var readonly=!editable();
    return '<div class="cbt-annotation-toolbar cbt-annotation-ui" role="toolbar" aria-label="阅读标记工具">'+(!readonly?colorButtons(color)+'<span class="ann-divider"></span>'+typeButtons(kind)+'<button type="button" class="ann-icon-button" data-annotation-action="undo" aria-label="撤销标记" title="撤销标记"'+(!undo.length?' disabled':'')+'>↶</button><button type="button" class="ann-icon-button" data-annotation-action="redo" aria-label="重做标记" title="重做标记"'+(!redo.length?' disabled':'')+'>↷</button>':'')+'<button type="button" class="ann-list-button" data-annotation-action="panel" aria-expanded="'+panelOpen+'">批注列表 <span>'+rows().length+'</span></button><span class="ann-toolbar-hint" role="status">'+esc(message||(readonly?'回看已保存的标记与批注':'选中文字，即可标记或添加批注'))+'</span></div>';
  }
  function clearActive(){if(host)Array.prototype.forEach.call(host.querySelectorAll('.ann-active'),function(node){node.classList.remove('ann-active');});}
  function removeUi(selector){var node=host&&host.querySelector(selector);if(node)node.remove();}
  function floating(){
    removeUi('.cbt-annotation-float');if(!ctx||ctx.blocked())return;
    var entry=selected&&byId(selected);if(!pending&&!entry)return;
    var node=document.createElement('section');node.className='cbt-annotation-float cbt-annotation-ui';node.setAttribute('role','dialog');node.setAttribute('aria-label',entry?'编辑标记':'标记选中文字');
    node.innerHTML='<header><b>'+(!editable()?'批注详情':entry?'编辑标记':'标记选中文字')+'</b><button type="button" data-annotation-action="dismiss" aria-label="关闭批注工具">×</button></header><blockquote>'+esc((entry||pending).quote)+'</blockquote>'+(ctx.isStudy&&ctx.isStudy()?'<div class="ann-study-actions"><button type="button" data-annotation-action="study-word">查单词</button><button type="button" data-annotation-action="study-grammar">句子语法分析</button></div>':'')+colorButtons(color)+typeButtons(kind)+(noteOpen?'<label class="ann-note-label">批注<textarea data-annotation-note maxlength="3000" placeholder="写下理解、疑问或解题思路…"'+(!editable()?' readonly':'')+'>'+esc(draft)+'</textarea></label>':'<button type="button" class="ann-add-note" data-annotation-action="note-open">'+(editable()?'＋ 添加文字批注':'没有文字批注')+'</button>')+'<footer>'+(!editable()?'':entry?'<button type="button" class="ann-delete" data-annotation-action="delete">删除标记</button>':'')+'<span class="ann-note-count">'+draft.length+' / 3000</span>'+(!editable()?'':'<button type="button" class="ann-save" data-annotation-action="apply">'+(entry?'保存修改':'添加标记')+'</button>')+'</footer>';
    host.appendChild(node);
    var rect=pending&&pending.rect;
    if(entry){var target=Array.prototype.find.call(host.querySelectorAll('[data-ann-id]'),function(n){return n.getAttribute('data-ann-id')===entry.id;});if(target)rect=target.getBoundingClientRect();}
    var width=Math.min(350,window.innerWidth-24),height=node.getBoundingClientRect().height;
    node.style.width=width+'px';node.style.left=Math.max(12,Math.min(window.innerWidth-width-12,rect?rect.left:window.innerWidth-width-24))+'px';
    node.style.top=Math.max(12,Math.min(window.innerHeight-height-12,rect?rect.bottom+8:100))+'px';
  }
  function panel(){
    removeUi('.cbt-annotation-panel');if(!panelOpen||!ctx||ctx.blocked())return;
    var all=rows(),current=ctx.questions()[ctx.index()],group=ctx.questions().filter(function(q){return q.id===current.id||current.readingText&&q.readingText===current.readingText;}).map(function(q){return q.id;});
    var visible=all.filter(function(a){return (panelFilter!=='current'||group.indexOf(a.questionId)>=0)&&(panelFilter!=='notes'||a.note)&&(a.quote+' '+a.note).toLowerCase().indexOf(query.toLowerCase())>=0;});
    var node=document.createElement('aside');node.className='cbt-annotation-panel cbt-annotation-ui';node.setAttribute('aria-label','批注列表');
    node.innerHTML='<header><div><span>我的阅读笔记</span><h2>标记与批注 <small>'+all.length+'</small></h2></div><button type="button" data-annotation-action="panel-close" aria-label="关闭批注列表">×</button></header><div class="ann-panel-search"><input type="search" data-annotation-search aria-label="搜索标记或批注" placeholder="搜索原文或批注…" value="'+esc(query)+'"></div><div class="ann-panel-filters">'+[['all','全部'],['current','本题 / 本篇'],['notes','有批注']].map(function(f){return '<button type="button" data-annotation-action="filter" data-value="'+f[0]+'" aria-pressed="'+(panelFilter===f[0])+'">'+f[1]+'</button>';}).join('')+'</div><div class="ann-panel-list">'+(visible.length?visible.map(function(a){var number=ctx.questions().findIndex(function(q){return q.id===a.questionId;})+1;return '<button type="button" class="ann-list-item ann-'+a.color+(selected===a.id?' active':'')+'" data-annotation-action="locate" data-id="'+esc(a.id)+'"><span class="ann-list-meta">第 '+number+' 题 · '+KINDS[a.kind]+(a.note?' · 有批注':'')+'</span><q>'+esc(a.quote)+'</q>'+(a.note?'<p>'+esc(a.note)+'</p>':'')+'</button>';}).join(''):'<div class="ann-empty"><b>'+(all.length?'没有匹配的批注':'还没有阅读标记')+'</b><p>选中一段原文，选择颜色与样式，记下你的理解。</p></div>')+'</div><footer>'+(!editable()?'标记与批注已随答卷保存':'<button type="button" data-annotation-action="clear-current">清空本题 / 本篇</button><span>误删可撤销</span>')+'</footer>';
    var workspace=host.querySelector('.cbt-workspace');if(workspace)workspace.appendChild(node);
  }
  function hint(text){message=text;var el=host&&host.querySelector('.ann-toolbar-hint');if(el)el.textContent=text;}
  function captureSelection(){
    if(!ctx||!editable()||ctx.blocked())return false;
    var selection=window.getSelection&&window.getSelection();if(!selection||selection.isCollapsed||!selection.rangeCount)return false;
    var a=selection.anchorNode,b=selection.focusNode;a=a&&(a.nodeType===1?a:a.parentElement);b=b&&(b.nodeType===1?b:b.parentElement);
    var root=a&&a.closest('.cbt-selectable[data-ann-scope]');
    if(!root||!b||root!==b.closest('.cbt-selectable[data-ann-scope]')||!host.contains(root))return false;
    var range=selection.getRangeAt(0),prefix=range.cloneRange();prefix.selectNodeContents(root);prefix.setEnd(range.startContainer,range.startOffset);
    var scope=root.getAttribute('data-ann-scope'),before=prefix.toString(),quote=range.toString();
    if(!quote.trim()||quote.length>1000){hint('每次可标记1～1000字');return false;}
    var start=(scope==='pdf'?before.replace(/\s/g,''):before).length,end=start+(scope==='pdf'?quote.replace(/\s/g,''):quote).length;
    if(end===start)return false;
    pending={questionId:root.getAttribute('data-ann-question'),quote:quote,anchor:{scope:scope,key:root.getAttribute('data-ann-key'),start:start,end:end},rect:range.getBoundingClientRect()};selected=null;draft='';noteOpen=false;floating();return true;
  }
  function apply(){
    if(!editable())return;
    var entry=selected&&byId(selected);
    if(!entry&&!pending){captureSelection();return;}
    if(!entry&&(work().annotations||[]).length>=1000){hint('本卷最多保存1000条批注');return;}
    record(function(){
      if(entry){var saved=materialize(entry);saved.kind=kind;saved.color=color;saved.note=draft;}
      else {var saved={id:freshId(),questionId:pending.questionId,quote:pending.quote,anchor:clone(pending.anchor),kind:kind,color:color,note:draft};if(!work().annotations)work().annotations=[];work().annotations.push(saved);selected=saved.id;pending=null;}
      message='标记已保存 · 可在批注列表中回看';
    });
  }
  function openEntry(id,locate){
    var entry=byId(id);if(!entry)return;pending=null;selected=id;kind=entry.kind;color=entry.color;draft=entry.note;noteOpen=!!entry.note;
    if(locate){preserveSelected=true;ctx.locate(entry);}else floating();
  }
  function action(name,target){
    if(!ctx)return;
    var value=target&&target.getAttribute('data-value');
    if((name==='study-word'||name==='study-grammar')&&ctx.isStudy&&ctx.isStudy()){var selection=selected&&byId(selected)||pending;if(!selection)return;ctx.studySelection(name==='study-word'?'lookup':'grammar',selection);pending=null;selected=null;removeUi('.cbt-annotation-float');return;}
    if(name==='color'||name==='kind'){
      if(!editable())return;if(name==='color'&&COLORS[value])color=value;if(name==='kind'&&KINDS[value])kind=value;
      if(pending){apply();}else if(selected){floating();updateToolbar();}else {if(!captureSelection())updateToolbar();}
    }else if(name==='apply')apply();
    else if(name==='note-open'){noteOpen=true;floating();var field=host.querySelector('[data-annotation-note]');if(field)field.focus();}
    else if(name==='dismiss'){pending=null;selected=null;draft='';clearActive();removeUi('.cbt-annotation-float');}
    else if(name==='panel'){panelOpen=!panelOpen;panel();updateToolbar();}
    else if(name==='panel-close'){panelOpen=false;panel();updateToolbar();}
    else if(name==='filter'){panelFilter=value;panel();}
    else if(name==='locate')openEntry(target.getAttribute('data-id'),true);
    else if(name==='delete'){
      var entry=byId(selected);if(!entry||!editable())return;
      record(function(){if(entry.legacy)work().highlights[entry.questionId].splice(entry.legacyIndex,1);else work().annotations=work().annotations.filter(function(a){return a.id!==entry.id;});selected=null;pending=null;draft='';message='标记已删除 · 可撤销';});
    }else if(name==='clear-current'&&editable()){
      var q=ctx.questions()[ctx.index()],ids=ctx.questions().filter(function(row){return row.id===q.id||q.readingText&&q.readingText===row.readingText;}).map(function(row){return row.id;});
      record(function(){work().annotations=(work().annotations||[]).filter(function(a){return ids.indexOf(a.questionId)<0;});ids.forEach(function(id){delete work().highlights[id];});selected=null;pending=null;message='本题标记已清空 · 可撤销';});
    }else if((name==='undo'||name==='redo')&&editable()){
      var from=name==='undo'?undo:redo,to=name==='undo'?redo:undo;if(!from.length)return;to.push(snapshot());restore(from.pop());pending=null;selected=null;draft='';message=name==='undo'?'已撤销标记操作':'已重做标记操作';ctx.changed();ctx.refresh();
    }
  }
  function updateToolbar(){var el=host&&host.querySelector('.cbt-annotation-toolbar');if(el)el.outerHTML=toolbar();}
  function bind(box,context){
    host=box;ctx=context;
    if(lastIndex!==ctx.index()&&!preserveSelected){pending=null;selected=null;draft='';}lastIndex=ctx.index();preserveSelected=false;
    if(runId!==ctx.run().id){runId=ctx.run().id;pending=null;selected=null;undo=[];redo=[];panelOpen=false;query='';message='';}
  }
  function afterRender(){if(selected&&!byId(selected))selected=null;pending=null;panel();floating();}
  document.addEventListener('mouseup',function(e){if(host&&host.contains(e.target)&&!e.target.closest('.cbt-annotation-ui,.cbt-study-ui'))captureSelection();});
  document.addEventListener('keyup',function(e){if(e.shiftKey&&host&&host.contains(e.target)&&!e.target.closest('.cbt-annotation-ui,.cbt-study-ui'))captureSelection();});
  document.addEventListener('touchend',function(e){if(host&&host.contains(e.target)&&!e.target.closest('.cbt-annotation-ui,.cbt-study-ui')){clearTimeout(selectionTimer);selectionTimer=setTimeout(captureSelection,180);}});
  document.addEventListener('mousedown',function(e){if(host&&host.contains(e.target)&&e.target.closest('[data-annotation-action]'))e.preventDefault();});
  document.addEventListener('click',function(e){
    if(!host||!host.contains(e.target))return;
    var button=e.target.closest('[data-annotation-action]');
    if(button){e.preventDefault();e.stopImmediatePropagation();if(!button.disabled)action(button.getAttribute('data-annotation-action'),button);return;}
    var mark=e.target.closest('[data-ann-id]'),selection=window.getSelection&&window.getSelection();
    if(mark&&(!selection||selection.isCollapsed)){e.preventDefault();e.stopImmediatePropagation();openEntry(mark.getAttribute('data-ann-id'),false);}
  });
  document.addEventListener('input',function(e){
    if(!host||!host.contains(e.target))return;
    if(e.target.hasAttribute('data-annotation-note')){draft=e.target.value.slice(0,3000);var count=host.querySelector('.ann-note-count');if(count)count.textContent=draft.length+' / 3000';}
    if(e.target.hasAttribute('data-annotation-search')){query=e.target.value;var pos=e.target.selectionStart;panel();var field=host.querySelector('[data-annotation-search]');if(field){field.focus();field.setSelectionRange(pos,pos);}}
  });
  document.addEventListener('keydown',function(e){
    if(!host||!host.contains(e.target))return;
    if(e.key==='Escape'&&(pending||selected||panelOpen)){e.preventDefault();e.stopImmediatePropagation();pending=null;selected=null;panelOpen=false;clearActive();removeUi('.cbt-annotation-float');panel();updateToolbar();return;}
    if((e.key==='Enter'||e.key===' ')&&e.target.hasAttribute('data-ann-id')){e.preventDefault();e.stopImmediatePropagation();openEntry(e.target.getAttribute('data-ann-id'),false);return;}
    if(e.target.closest('.cbt-annotation-ui')&&!/^(INPUT|TEXTAREA)$/.test(e.target.tagName)&&(e.ctrlKey||e.metaKey)&&/^[zy]$/i.test(e.key)){e.preventDefault();e.stopImmediatePropagation();action(e.key.toLowerCase()==='y'||e.shiftKey?'redo':'undo');}
  });
  window.PaperAnnotations={bind:bind,toolbar:toolbar,renderText:renderText,pdfMarks:pdfMarks,attrs:scopeAttrs,annotationAttrs:annotationAttrs,afterRender:afterRender,afterLocate:floating,captureSelection:captureSelection,action:action,rows:rows};
})();
