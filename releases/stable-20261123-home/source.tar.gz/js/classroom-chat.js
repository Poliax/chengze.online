(function(){
 var viewer='';
 function render(m){
  var role=(m.type==='system'||m.type==='system_date'||m.sender==='系统')?'system':m.author_role==='teacher'?'teacher':'student';
  var own=!!viewer&&m.author_id===viewer;
  var row=document.createElement('div');row.className='chat-msg chat-card role-'+role+(own?' is-own':'');
  var avatar=document.createElement('div');avatar.className='chat-avatar';avatar.dataset.avatarGender=role==='student'?(m.gender||'unknown'):'unknown';avatar.title=m.sender||({system:'系统',teacher:'教师',student:'学员'}[role]);avatar.setAttribute('aria-label',avatar.title);avatar.textContent=role==='system'?'⚙':String(m.sender||'学员').slice(0,1);
  if(m.avatar&&/^(\/[^/]|https:\/\/)/.test(m.avatar)){var img=document.createElement('img');img.src=m.avatar;img.alt='';img.onerror=function(){img.remove()};avatar.append(img)}
  var body=document.createElement('div');body.className='chat-body';var head=document.createElement('div');head.className='head';
  var name=document.createElement('span');name.className='who';name.textContent=m.sender||({system:'系统',teacher:'教师',student:'学员'}[role]);
  var badge=document.createElement('span');badge.className='chat-role';badge.textContent=own?'我':({system:'系统',teacher:'教师',student:'学员'}[role]);
  var time=document.createElement('time');time.className='time';var raw=m.time||m.created_at||'';var date=new Date(raw&& !/[Z+]|-\d\d:\d\d$/.test(raw.slice(10))?raw.replace(' ','T')+'Z':raw);time.textContent=isNaN(date)?'':date.toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit',hour12:false});time.title=isNaN(date)?'':date.toLocaleString('zh-CN');
  var txt=document.createElement('div');txt.className='txt';txt.textContent=m.content||'';
  if(role==='system'){body.append(txt);if(m.type!=='system_date')body.append(time);}else{head.append(avatar,name,time);body.append(head,txt); } row.append(body);return row;
 }
 window.ClassroomChat={render:render,setViewer:function(id){viewer=id||''}};
})();
