(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else{if(root.ChengzeIcons)return;root.ChengzeIcons=factory();root.ChengzeIcons.init(root.document);}})(typeof window!=='undefined'?window:null,function(){
 'use strict';
 var paths={close:'M4 4l16 16M20 4 4 20',download:'M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5',search:'M21 21l-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0',back:'M20 12H4m7-7-7 7 7 7','chevron-left':'m15 5-7 7 7 7','chevron-right':'m9 5 7 7-7 7','chevron-up':'m5 15 7-7 7 7','chevron-down':'m5 9 7 7 7-7','zoom-in':'M4 12h16M12 4v16','zoom-out':'M4 12h16','fit-width':'M3 4v16M21 4v16M4 12h16M8 8l-4 4 4 4m8-8 4 4-4 4',menu:'M4 6h16M4 12h16M4 18h16',more:'M5 12h.01M12 12h.01M19 12h.01'};
 var calendarGroups='.student-week-nav-group,.month-nav,.week-actions,.cal-nav-group,.calendar-nav-group';
 var excluded=/\b(?:campaign-arrow|pen-tool|student-avatar-picker|student-account-trigger|watch-brand|brand-logo|chengze-brand|admin-nav-overlay|teacher-nav-overlay)\b/;
 function classify(item){
  var text=(item.text||'').trim(),classes=item.classes||'',label=item.label||'';
  if(item.inPlayer||/\b(?:ctrl-btn|teaching-ctrl-btn)\b/.test(classes)||excluded.test(classes)||item.hasImage||/承泽|logo/i.test(label)||!['BUTTON','A'].includes(item.tag))return null;
  if(text==='今天'&&item.calendar)return {kind:'text',name:null};
  if(item.calendar&&/上一周|上个月|上一月|上月/.test(label))return {kind:'icon',name:'chevron-left'};
  if(item.calendar&&/下一周|下个月|下一月|下月/.test(label))return {kind:'icon',name:'chevron-right'};
  if(item.icon&&Object.prototype.hasOwnProperty.call(paths,item.icon))return {kind:'icon',name:item.icon};
  if(/\b(?:auth-close|auth-v2-close|course-detail-modal__close|rp-close)\b/.test(classes)||(/^[×✕✖]$/.test(text)&&/关闭|close/i.test(label)))return {kind:'icon',name:'close'};
  if(/^(?:下载|下载文件|下载资料|下载原文件)$/.test(text)||(!text&&item.download))return {kind:'icon',name:'download'};
  if(/^[‹<←]$/.test(text))return {kind:'icon',name:'chevron-left'};
  if(/^[›>→]$/.test(text))return {kind:'icon',name:'chevron-right'};
  if(/^[▲↑]$/.test(text))return {kind:'icon',name:'chevron-up'};
  if(/^[▼↓]$/.test(text))return {kind:'icon',name:item.download?'download':'chevron-down'};
  if(!text&&/查询|搜索/.test(label))return {kind:'icon',name:'search'};
  if(/\bprep-school-toggle\b/.test(classes))return {kind:'icon',name:item.expanded==='true'?'chevron-up':'chevron-down'};
  if(/\b(?:row-del|del-btn)\b/.test(classes)&&/^[×✕✖]$/.test(text))return {kind:'icon',name:'close'};
  if(/\badd-btn\b/.test(classes)&&text==='+')return {kind:'icon',name:'zoom-in'};
  if(item.hasSvg&&(!text||/\bplayer-theme-toggle\b/.test(classes)))return {kind:'icon',name:null};
  if(item.hasSvg)return {kind:'inline',name:null};
  return null;
 }
 function svg(name,document){var ns='http://www.w3.org/2000/svg',node=document.createElementNS(ns,'svg'),path=document.createElementNS(ns,'path');node.setAttribute('viewBox','0 0 24 24');node.setAttribute('width','20');node.setAttribute('height','20');node.setAttribute('fill','none');node.setAttribute('stroke','currentColor');node.setAttribute('stroke-width','1.8');node.setAttribute('stroke-linecap','round');node.setAttribute('stroke-linejoin','round');node.setAttribute('aria-hidden','true');node.setAttribute('focusable','false');path.setAttribute('d',paths[name]||paths.close);node.append(path);return node;}
 function apply(el,name,label){el.setAttribute('data-ui-icon',name);if(label){el.setAttribute('aria-label',label);el.setAttribute('title',label);}enhance(el);return el;}
 function enhance(el){
  if(!el.matches||!el.matches('button,a'))return;
  var icon=el.getAttribute('data-ui-icon'),text=el.textContent.trim(),classes=el.getAttribute('class')||'',label=el.getAttribute('aria-label')||el.getAttribute('title')||'',hasSvg=Array.from(el.children).some(function(child){return child.tagName.toLowerCase()==='svg';})||(el.tagName==='BUTTON'&&!!el.querySelector('svg'));
  var result=classify({tag:el.tagName,text:text,classes:classes,label:label,icon:icon,hasSvg:hasSvg,hasImage:!!el.querySelector('img,svg[role="img"]')||!!el.closest('.logo,.brand-logo,.watch-brand,.sidebar-brand,.playback-brand'),download:el.hasAttribute('download'),expanded:el.getAttribute('aria-expanded'),inPlayer:!!el.closest('.player-controls,.teaching-controls,.video-controls,.player-main .controls'),calendar:!!el.closest(calendarGroups)||el.hasAttribute('data-week-today')||el.matches('.cal-nav')});if(!result)return;
  if(result.kind==='text'){el.classList.add('cz-text-action');el.setAttribute('aria-label',label||'回到今天');return;}
  if(result.kind==='inline'){el.classList.add('cz-with-icon');markSlots(el);return;}
  el.classList.add('cz-icon-action');markSlots(el);
  if(result.name&&el.getAttribute('data-cz-glyph')!==result.name){el.replaceChildren(svg(result.name,el.ownerDocument));el.setAttribute('data-cz-glyph',result.name);}
  var fallback={close:'关闭',download:'下载','chevron-left':'上一项','chevron-right':'下一项','chevron-up':'上移','chevron-down':'下移'};
  var classLabel=/\b(?:row-del|del-btn)\b/.test(classes)?'删除':/\badd-btn\b/.test(classes)?'添加':/\bcopy-btn\b/.test(classes)?'复制':/\bpw-toggle\b/.test(classes)?'显示或隐藏密码':/\b(?:admin-mobile-menu|teacher-mobile-menu|sidebar-toggle)\b/.test(classes)?'展开或收起菜单':'';var idLabel={muteBtn:'静音或恢复声音',playBtn:'播放或暂停',fullBtn:'全屏',pageFullBtn:'网页全屏',sideToggle:'展开或收起侧边栏',sideBtn:'展开或收起侧边栏'}[el.id]||'';label=label||classLabel||idLabel||fallback[result.name]||text;if(label){el.setAttribute('aria-label',label);if(!el.hasAttribute('title'))el.setAttribute('title',label);}
  if(/\b(?:row-del|del-btn)\b/.test(classes))el.setAttribute('data-ui-tone','danger');
 }
 function markSlots(el){el.querySelectorAll('svg').forEach(function(node){var parent=node.parentElement;if(parent!==el&&parent.children.length===1&&!parent.textContent.trim())parent.classList.add('cz-icon-slot');});}
 function init(document){
  var root=document.documentElement;root.setAttribute('data-cz-input','pointer');
  function pointer(){root.setAttribute('data-cz-input','pointer');}
  document.addEventListener('pointerdown',pointer,true);document.addEventListener('mousedown',pointer,true);document.addEventListener('touchstart',pointer,{capture:true,passive:true});
  document.addEventListener('keydown',function(e){if(['Tab','Enter',' ','ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End','PageUp','PageDown'].includes(e.key))root.setAttribute('data-cz-input','keyboard');},true);
  function scan(node){if(node.nodeType!==1&&node.nodeType!==9)return;if(node.matches){if(node.matches(calendarGroups))node.classList.add('cz-action-group');enhance(node);}node.querySelectorAll(calendarGroups).forEach(function(group){group.classList.add('cz-action-group');});node.querySelectorAll('button,a').forEach(enhance);}
  function start(){scan(document);var observer=new MutationObserver(function(records){records.forEach(function(record){if(record.target.closest){var control=record.target.closest('button,a');if(control)enhance(control);}record.addedNodes.forEach(scan);});});observer.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['aria-expanded','data-ui-icon']});}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
 }
 return {classify:classify,svg:svg,apply:apply,init:init};
});
