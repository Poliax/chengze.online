(function(){
 if(window.__teacherTableScroll)return;window.__teacherTableScroll=true;
 function prepare(){document.querySelectorAll('.course-group-list .lesson-body:not([data-scroll-frame])').forEach(function(body){
  var table=body.querySelector('table.lesson-table'),head=table&&table.tHead;if(!head||!body.clientWidth)return;
  var cells=Array.from(head.rows[0].cells),widths=cells.map(c=>c.getBoundingClientRect().width),width=table.getBoundingClientRect().width;
  if(!width)return;
  var frame=document.createElement('div');frame.className='lesson-table-scroll';var header=document.createElement('div');header.className='lesson-table-header';
  var heading=document.createElement('table');heading.className='lesson-table';
  function columns(){var group=document.createElement('colgroup');widths.forEach(function(w){var col=document.createElement('col');col.style.width=(w/width*100)+'%';group.append(col)});return group;}
  table.prepend(columns());heading.append(columns(),head);header.append(heading);frame.append(table);body.append(header,frame);body.dataset.scrollFrame='true';
  function fit(){var gutter=frame.offsetWidth-frame.clientWidth;header.style.paddingRight=gutter+'px';var size=Math.max(1320,frame.clientWidth);table.style.setProperty('width',size+'px','important');heading.style.setProperty('width',size+'px','important');header.scrollLeft=frame.scrollLeft;var rows=Array.from(table.tBodies[0]?table.tBodies[0].rows:[]).slice(0,10);var rowsHeight=rows.reduce(function(sum,row){return sum+row.getBoundingClientRect().height},0);var barHeight=frame.offsetHeight-frame.clientHeight;if(rowsHeight)frame.style.maxHeight=(rowsHeight+barHeight)+'px';}
  frame.addEventListener('scroll',function(){header.scrollLeft=frame.scrollLeft},{passive:true});new ResizeObserver(fit).observe(frame);fit();
 });}
 var queued=false;function schedule(){if(queued)return;queued=true;requestAnimationFrame(function(){queued=false;prepare()})}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',schedule);else schedule();
 new MutationObserver(schedule).observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['class']});
})();
