/* Bind the shared playback recorder only to the main live picture, never the camera. */
(function(){
 const tag=document.currentScript,lesson=Number(tag.dataset.lesson),session=Number(tag.dataset.session),root=document.getElementById('teacherVideoMain');
 if(!lesson||!session||!root)return;
 const bound=new WeakSet();let next=0;
 function scan(){const video=root.querySelector('video');if(!video||bound.has(video))return;bound.add(video);
  if(!video.id)video.id='liveLearningVideo'+(++next);
  const script=document.createElement('script');script.src='/js/lesson-progress.js?v=20261111-activity1';script.dataset.lesson=String(lesson);script.dataset.session=String(session);script.dataset.live='1';script.dataset.player=video.id;document.body.append(script);
 }
 new MutationObserver(scan).observe(root,{childList:true,subtree:true});scan();
})();
