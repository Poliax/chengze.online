(function () {
  'use strict';
  var form = document.getElementById('studentSmsLoginForm');
  if (!form) return;
  var phone = document.getElementById('smsLoginPhone');
  var code = document.getElementById('smsLoginCode');
  var send = document.getElementById('smsLoginSendCode');
  var submit = document.getElementById('smsLoginSubmit');
  var message = document.getElementById('smsLoginMessage');
  var agreement = document.getElementById('authAgreement');
  window.positionAuthAgreement = function (containerId) {
    var container = document.getElementById(containerId || 'authCodeLogin');
    if (!agreement || !container || !container.querySelector) return;
    var actions = container.querySelector('.modal-actions');
    if (actions) actions.parentNode.insertBefore(agreement.closest('.auth-agreement'), actions);
  };
  var sending = false;
  var loggingIn = false;
  var deadline = 0;
  var timer;

  function updateButtons() {
    var left = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
    send.disabled = sending || loggingIn || left > 0;
    send.textContent = sending ? '正在发送…' : left ? left + '秒后重发' : '获取验证码';
    submit.disabled = sending || loggingIn;
    if (document.querySelectorAll) document.querySelectorAll('#authModal .modal-actions .primary').forEach(function (button) { button.disabled = submit.disabled; });
    submit.textContent = loggingIn ? '正在登录…' : '登录';
    if (!left && timer) { clearInterval(timer); timer = null; }
  }

  function notice(text, error) {
    message.textContent = text;
    message.classList.toggle('is-error', !!error);
  }

  function validPhone() {
    if (/^1\d{10}$/.test(phone.value.trim())) return true;
    notice('请输入正确的手机号', true);
    phone.focus();
    return false;
  }

  async function post(url, body) {
    var response = await fetch(url, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
    });
    var data = await response.json();
    if (!response.ok || !data.success || data.devCode) throw Error(data.devCode ? '短信服务暂不可用' : data.error || '请求失败，请稍后重试');
    return data;
  }

  phone.addEventListener('input', function () { code.value = ''; });
  send.addEventListener('click', async function () {
    if (send.disabled || !validPhone()) return;
    sending = true;
    notice('');
    updateButtons();
    try {
      await post('/api/auth/send-code', { phone: phone.value.trim(), agreementAccepted: !!(agreement && agreement.checked) });
      notice('验证码已发送，5分钟内有效');
      deadline = Date.now() + 60000;
      timer = setInterval(updateButtons, 1000);
      code.focus();
    } catch (error) {
      notice(error.message || '发送失败，请稍后重试', true);
    } finally {
      sending = false;
      updateButtons();
    }
  });

  form.addEventListener('submit', async function (event) {
    event.preventDefault();
    if (sending || loggingIn) return;
    if (!agreement?.checked) { notice('请先阅读并同意《用户协议》与《隐私政策》', true); agreement?.focus(); return; }
    if (!validPhone()) return;
    if (!/^\d{6}$/.test(code.value.trim())) {
      notice('请输入6位短信验证码', true);
      code.focus();
      return;
    }
    loggingIn = true;
    notice('');
    updateButtons();
    try {
      await post('/api/auth/login-code', { phone: phone.value.trim(), code: code.value.trim(), agreementAccepted: !!(agreement && agreement.checked) });
      try { localStorage.removeItem('cz_remember_login'); } catch (error) {}
      location.reload();
    } catch (error) {
      notice(error.message || '登录失败，请稍后重试', true);
    } finally {
      loggingIn = false;
      updateButtons();
    }
  });
  updateButtons();
}());
