/* Record real playback; opening a page or seeking alone never completes a lesson. */
(function(){
 const tag=document.currentScript,id=Number(tag&&tag.dataset.lesson),video=document.getElementById(tag&&tag.dataset.player);
 if(!id||!video)return;
 const sessionId=Number(tag&&tag.dataset.session)||0;
 const live=tag&&tag.dataset.live==='1';
 let watched=0,last=null,dirty=false,ready=false,sending=false,done=false;
 fetch('/api/progress'+(sessionId?'?session='+sessionId:''),{cache:'no-store'}).then(r=>r.ok?r.json():Promise.reject()).then(data=>{
  const row=(data.progress||[]).find(r=>Number(r.lesson_id)===id);
  watched=Number(row&&row.watch_duration)||0;done=!!(row&&row.completed);
  const resume=()=>{const position=Number(row&&row.last_position)||0;if(position>0&&!done&&position<video.duration-2)video.currentTime=position;};
  if(!live){if(video.readyState>=1)resume();else video.addEventListener('loadedmetadata',resume,{once:true});}ready=true;
 }).catch(()=>{});
 function save(){if(!ready||!dirty||sending)return;sending=true;dirty=false;
  fetch('/api/progress',{method:'POST',headers:{'Content-Type':'application/json'},keepalive:true,body:JSON.stringify({...(sessionId?{sessionId}:{}),lessonId:id,watchDuration:Math.min(86400,watched),lastPosition:Math.min(86400,Math.max(0,video.currentTime||0)),completed:done})}).then(r=>{if(!r.ok)dirty=true;}).catch(()=>{dirty=true;}).finally(()=>{sending=false;});
 }
 video.addEventListener('timeupdate',()=>{const now=video.currentTime;if(last!==null&&!video.paused&&!video.seeking&&now>last&&now-last<5){watched+=now-last;dirty=true;}last=now;});
 video.addEventListener('seeking',()=>{last=null;});
 video.addEventListener('play',()=>{last=video.currentTime;});
 video.addEventListener('pause',save);
 video.addEventListener('ended',()=>{if(!live&&Number.isFinite(video.duration)&&watched>=video.duration*.9)done=true;dirty=true;save();});
 setInterval(save,10000);window.addEventListener('pagehide',save);document.addEventListener('visibilitychange',()=>{if(document.hidden)save();});
})();
