(function(){
  function format(value,kind){var d=String(value||'').replace(/\D/g,'').slice(0,kind==='datetime'?12:8);return d.slice(0,4)+(d.length>4?'/'+d.slice(4,6):'')+(d.length>6?'/'+d.slice(6,8):'')+(d.length>8?' '+d.slice(8,10):'')+(d.length>10?':'+d.slice(10,12):'');}
  function valid(value,kind){if(!value)return true;var re=kind==='datetime'?/^(\d{4})\/(\d{2})\/(\d{2}) (\d{2}):(\d{2})$/:/^(\d{4})\/(\d{2})\/(\d{2})$/;var p=String(value).match(re);if(!p)return false;var date=new Date(0);date.setFullYear(+p[1],+p[2]-1,+p[3]);return +p[1]>0&&date.getFullYear()===+p[1]&&date.getMonth()===+p[2]-1&&date.getDate()===+p[3]&&(kind!=='datetime'||(+p[4]<24&&+p[5]<60));}
  function canonical(value,kind){var result=String(value||'').replace(/\//g,'-');return kind==='datetime'?result.replace(' ','T'):result;}
  if(typeof module!=='undefined')module.exports={format:format,valid:valid,canonical:canonical};
  if(typeof document==='undefined'||window.czDateTextInputReady)return;
  window.czDateTextInputReady=true;
  var selector='input[type="text"][data-cz-date],input[type="text"][placeholder="YYYY/MM/DD"]';
  function kind(input){return input.dataset.czDate==='datetime'?'datetime':'date';}
  function check(input){input.setCustomValidity(valid(input.value,kind(input))?'':'请输入有效日期'+(kind(input)==='datetime'?'和时间':'')+'：'+input.placeholder);}
  function prepare(input){if(input.dataset.czDateReady)return;input.dataset.czDateReady='1';input.inputMode='numeric';input.autocomplete='off';input.maxLength=kind(input)==='datetime'?16:10;if(input.value)input.value=format(input.value,kind(input));check(input);}
  function scan(root){if(root.matches&&root.matches(selector))prepare(root);if(root.querySelectorAll)root.querySelectorAll(selector).forEach(prepare);}
  document.addEventListener('input',function(event){var input=event.target;if(!input.matches(selector))return;var n=input.value.slice(0,input.selectionStart).replace(/\D/g,'').length;input.value=format(input.value,kind(input));var caret=0,count=0;while(caret<input.value.length&&count<n){if(/\d/.test(input.value[caret]))count++;caret++;}input.setSelectionRange(caret,caret);check(input);});
  document.addEventListener('focusin',function(event){var input=event.target;if(input.matches(selector)){input.value=format(input.value,kind(input));check(input);}});
  document.addEventListener('focusout',function(event){var input=event.target;if(input.matches(selector))check(input);});
  document.addEventListener('formdata',function(event){event.target.querySelectorAll(selector).forEach(function(input){if(input.name&&!input.disabled)event.formData.set(input.name,canonical(input.value,kind(input)));});});
  scan(document);
  new MutationObserver(function(records){records.forEach(function(record){record.addedNodes.forEach(scan);});}).observe(document.documentElement,{childList:true,subtree:true});
})();
