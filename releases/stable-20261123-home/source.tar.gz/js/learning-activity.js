(function(){
 const grid=document.querySelector('[data-learning-activity-grid]');if(!grid)return;
 const status=document.querySelector('[data-learning-activity-status]');
 const tooltip=document.createElement('div');tooltip.className='learning-activity-tooltip';tooltip.id='learningActivityTooltip';tooltip.setAttribute('role','tooltip');tooltip.hidden=true;document.body.append(tooltip);
 let activeCell=null;
 function hideTip(){if(activeCell)activeCell.removeAttribute('aria-describedby');activeCell=null;tooltip.hidden=true;}
 function showTip(cell){
  if(!cell||!cell.dataset.tooltip)return;hideTip();activeCell=cell;tooltip.textContent=cell.dataset.tooltip;tooltip.hidden=false;cell.setAttribute('aria-describedby',tooltip.id);
  const rect=cell.getBoundingClientRect(),tip=tooltip.getBoundingClientRect();
  tooltip.style.left=Math.max(8,Math.min(innerWidth-tip.width-8,rect.left+rect.width/2-tip.width/2))+'px';
  tooltip.style.top=(rect.top-tip.height-8>=8?rect.top-tip.height-8:rect.bottom+8)+'px';
 }
 grid.addEventListener('pointerover',event=>{const cell=event.target.closest('[data-tooltip]');if(cell!==activeCell)showTip(cell);});
 grid.addEventListener('pointerout',event=>{if(activeCell&&!activeCell.contains(event.relatedTarget))hideTip();});
 grid.addEventListener('focusin',event=>showTip(event.target.closest('[data-tooltip]')));
 grid.addEventListener('focusout',hideTip);document.addEventListener('scroll',hideTip,true);window.addEventListener('resize',hideTip);
 document.addEventListener('keydown',event=>{if(event.key==='Escape')hideTip();});
 function render(data){
  const today=new Date(data.today+'T00:00:00Z'),days=new Map(data.days.map(row=>[row.date,row]));
  const fragment=document.createDocumentFragment();
  const year=document.querySelector('[data-learning-activity-year]');if(year)year.textContent=today.getUTCFullYear()+'年';
  for(let monthIndex=0;monthIndex<12;monthIndex++){
   const first=new Date(Date.UTC(today.getUTCFullYear(),monthIndex,1)),last=new Date(Date.UTC(first.getUTCFullYear(),first.getUTCMonth()+1,0));
   const month=document.createElement('div');month.className='learning-activity-month';
   const cells=document.createElement('div');cells.className='learning-activity-cells';
   const leading=(first.getUTCDay()+6)%7,count=last.getUTCDate(),slots=Math.ceil((leading+count)/7)*7;
   month.style.setProperty('--activity-weeks',String(slots/7));
   for(let index=0;index<slots;index++){
    const cell=document.createElement('span');cell.className='learning-activity-cell';const day=index-leading+1;
    if(day<1||day>count){cell.dataset.empty='';cell.setAttribute('aria-hidden','true');}
    else{
     const date=new Date(Date.UTC(first.getUTCFullYear(),first.getUTCMonth(),day)).toISOString().slice(0,10);
     if(date>data.today){cell.dataset.level='0';cell.dataset.tooltip=date;cell.setAttribute('aria-label',date);}
     else{const row=days.get(date),seconds=Number(row&&row.seconds)||0;
      cell.dataset.level=seconds===0?'0':seconds<900?'1':seconds<1800?'2':seconds<3600?'3':'4';
      const text=date+' · '+(seconds>0?'学习 '+(seconds<60?'不足1分钟':Math.round(seconds/60)+'分钟')+' · '+row.lessons+'个课次':'暂无学习记录');
      cell.dataset.tooltip=text;cell.setAttribute('aria-label',text);if(seconds>0)cell.tabIndex=0;
     }
    }
    cells.append(cell);
   }
   const label=document.createElement('span');label.textContent=(first.getUTCMonth()+1)+'月';
   month.append(cells,label);fragment.append(month);
  }
  grid.replaceChildren(fragment);grid.setAttribute('aria-busy','false');
  status.hidden=true;status.textContent='';
  grid.parentElement.scrollLeft=0;
 }
 fetch('/api/progress?activity=1',{cache:'no-store'}).then(response=>{if(!response.ok)throw Error();return response.json();}).then(render).catch(()=>{grid.setAttribute('aria-busy','false');status.hidden=false;status.textContent='学习记录暂时无法加载，请刷新重试';});
})();
