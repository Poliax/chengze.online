(function () {
  'use strict';
  var view = document.getElementById('viewOrders');
  if (!view) return;
  var list = document.getElementById('studentOrdersList');
  var notice = document.getElementById('studentOrdersStatus');
  var heading = document.getElementById('studentOrdersHeading');
  var loading = false;
  var paying = false;
  var hasLoaded = false;
  var lastSnapshot = '';
  var currentOrders = [];
  var dialog = document.getElementById('studentOrderDialog');
  var actionForm = document.getElementById('studentOrderActionForm');
  var reasonInput = document.getElementById('studentOrderReason');
  var dialogStatus = document.getElementById('studentOrderDialogStatus');
  var dialogSubmit = document.getElementById('studentOrderDialogSubmit');
  var selectedAction = null;
  var selectedOrder = null;
  var sourceButton = null;
  var states = { paid: '已支付', pending: '待支付', cancelled: '已取消', refunded: '已退款' };

  function element(tag, text, className) {
    var node = document.createElement(tag);
    if (text) node.textContent = text;
    if (className) node.className = className;
    return node;
  }

  function time(value) {
    if (!value) return '—';
    var raw = String(value);
    var date = new Date(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(raw) ? raw.replace(' ', 'T') + 'Z' : raw);
    if (!Number.isFinite(date.getTime())) return raw;
    return date.toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', hour12: false });
  }

  function detail(parent, label, value) {
    var row = element('div');
    row.append(element('dt', label), element('dd', value));
    parent.append(row);
  }

  function render(orders) {
    var fragment = document.createDocumentFragment();
    if (!orders.length) {
      var empty = element('div', '', 'student-orders-empty');
      empty.append(element('h3', '暂无订单'), element('p', '购买课程后，你的订单会显示在这里。'));
      fragment.append(empty);
    }
    orders.forEach(function (order) {
      var card = element('article', '', 'student-order-card');
      var top = element('div', '', 'student-order-top');
      var title = element('div', '', 'student-order-title');
      var tags = element('div', '', 'student-order-tags');
      [order.class_year ? order.class_year + '年' : '', order.class_province, order.class_name].filter(Boolean).forEach(function (label) {
        tags.append(element('span', label));
      });
      title.append(tags, element('h3', order.package_title || order.course_title || '课程订单'));
      var badge = element(order.status === 'pending' ? 'button' : 'span', order.status === 'paid' && ['requested','processing'].includes(order.refund_status) ? '申请退款' : (states[order.status] || '处理中'), 'student-order-badge');
      if (order.status === 'pending') {
        badge.type = 'button';
        badge.dataset.orderPay = String(order.id);
        badge.title = '点击前往支付宝付款';
        badge.setAttribute('aria-label', '支付订单，金额' + Number(order.amount || 0).toFixed(2) + '元');
      }
      if (order.status === 'paid' || order.status === 'pending') badge.classList.add('is-' + order.status);
      top.append(badge);
      top.append(title, element('div', '¥' + Number(order.amount || 0).toFixed(2), 'student-order-price'));
      var details = element('dl', '', 'student-order-details');
      detail(details, '订单号', order.order_no);
      detail(details, '下单时间', time(order.created_at));
      if (order.paid_at) detail(details, '付款时间', time(order.paid_at));
      card.append(top, details);
      if (order.refund_status === 'rejected' && order.refund_note) detail(details, '退款说明', order.refund_note);
      if (order.status === 'pending' || order.status === 'paid') {
        var footer = element('div', '', 'student-order-footer');
        if (order.status === 'pending') {
          var remove = element('button', '删除订单', 'student-order-secondary');
          remove.type = 'button';
          remove.dataset.orderDelete = String(order.id);
          footer.append(remove);
        } else if (order.refund_status === 'requested' || order.refund_status === 'processing') {
          footer.append(element('span', order.refund_status === 'requested' ? '退款审核中' : '退款处理中', 'student-order-refund-state'));
        } else {
          var refund = element('button', '申请售后', 'student-order-secondary');
          refund.type = 'button';
          refund.dataset.orderRefund = String(order.id);
          footer.append(refund);
        }
        card.append(footer);
      }
      fragment.append(card);
    });
    list.replaceChildren(fragment);
  }

  async function load() {
    if (loading || paying) return;
    loading = true;
    list.setAttribute('aria-busy', 'true');
    if (!hasLoaded) {
      var loadingMessage = element('div', '', 'student-orders-empty');
      loadingMessage.append(element('p', '正在加载订单…'));
      list.replaceChildren(loadingMessage);
    }
    try {
      var response = await fetch('/api/orders', { cache: 'no-store' });
      var result = await response.json();
      if (!response.ok || !result.ok || !Array.isArray(result.orders)) throw Error(result.error || '订单加载失败，请稍后重新进入我的订单');
      var snapshot = JSON.stringify(result.orders);
      if (snapshot !== lastSnapshot) {
        render(result.orders);
        lastSnapshot = snapshot;
      }
      currentOrders = result.orders;
      hasLoaded = true;
      notice.textContent = '';
    } catch (error) {
      notice.textContent = error.message || '订单加载失败，请稍后重新进入我的订单';
    } finally {
      loading = false;
      list.setAttribute('aria-busy', 'false');
    }
  }

  async function submitAction(button, method, path, body) {
    paying = true;
    button.disabled = true;
    notice.textContent = '';
    var completed = false;
    try {
      var response = await fetch(path, {
        method: method, headers: { 'Content-Type': 'application/json' },
        body: body ? JSON.stringify(body) : undefined
      });
      var result = await response.json();
      if (!response.ok || !result.ok) throw Error(result.error || '操作失败，请重试');
      completed = true;
    } catch (error) {
      notice.textContent = error.message || '操作失败，请重试';
    } finally {
      paying = false;
      button.disabled = false;
    }
    if (completed) await load();
    return completed;
  }

  function openAction(action, button, id) {
    if (!dialog) { notice.textContent = '页面已更新，请刷新后重试'; return; }
    selectedOrder = currentOrders.find(function (order) { return String(order.id) === id; });
    if (!selectedOrder) return;
    selectedAction = action;
    sourceButton = button;
    var isRefund = action === 'refund';
    document.getElementById('studentOrderDialogTitle').textContent = isRefund ? '申请售后' : '删除订单';
    document.getElementById('studentOrderDialogDescription').textContent = isRefund
      ? '提交后我们会审核处理，退款审核通过后按原支付渠道退回。'
      : '确认删除这笔待支付订单？对应的支付交易会一并关闭。';
    document.getElementById('studentOrderDialogCourse').textContent = selectedOrder.package_title || selectedOrder.course_title || '课程订单';
    document.getElementById('studentOrderDialogAmount').textContent = '¥' + Number(selectedOrder.amount || 0).toFixed(2);
    document.getElementById('studentOrderReasonField').hidden = !isRefund;
    reasonInput.required = isRefund;
    reasonInput.value = '';
    var support = document.getElementById('studentOrderSupport');
    if (support) support.open = false;
    document.getElementById('studentOrderSupportNumber').textContent = selectedOrder.order_no || '';
    document.getElementById('studentOrderCopyStatus').textContent = '';
    dialogStatus.textContent = '';
    dialogSubmit.textContent = isRefund ? '提交申请' : '确认删除';
    dialog.showModal();
    if (isRefund) reasonInput.focus();
  }

  if (dialog) {
    document.getElementById('studentOrderCopyNumber').addEventListener('click', async function () {
      if (!selectedOrder || !selectedOrder.order_no) return;
      var number = selectedOrder.order_no;
      var status = document.getElementById('studentOrderCopyStatus');
      try {
        await navigator.clipboard.writeText(number);
        if (selectedOrder && selectedOrder.order_no === number) status.textContent = '订单号已复制';
      } catch (error) {
        if (selectedOrder && selectedOrder.order_no === number) status.textContent = '请选中或长按上方订单号复制';
      }
    });
    function closeDialog() { if (!paying) dialog.close(); }
    document.getElementById('studentOrderDialogClose').addEventListener('click', closeDialog);
    document.getElementById('studentOrderDialogCancel').addEventListener('click', closeDialog);
    dialog.addEventListener('cancel', function (event) { if (paying) event.preventDefault(); });
    dialog.addEventListener('close', function () {
      if (sourceButton && sourceButton.isConnected) sourceButton.focus();
      else heading.focus();
      selectedOrder = null;
      selectedAction = null;
    });
    actionForm.addEventListener('submit', async function (event) {
      event.preventDefault();
      if (paying || !selectedOrder) return;
      var isRefund = selectedAction === 'refund';
      var reason = reasonInput.value.trim();
      if (isRefund && (!reason || reason.length > 500)) {
        dialogStatus.textContent = '请填写500字以内的申请原因';
        reasonInput.focus();
        return;
      }
      dialogStatus.textContent = '';
      dialogSubmit.disabled = true;
      dialogSubmit.textContent = '正在提交…';
      var completed = await submitAction(sourceButton, isRefund ? 'POST' : 'DELETE',
        '/api/orders/' + encodeURIComponent(selectedOrder.id) + (isRefund ? '/refund' : ''),
        isRefund ? { reason: reason } : undefined);
      dialogSubmit.disabled = false;
      dialogSubmit.textContent = isRefund ? '提交申请' : '确认删除';
      if (completed) dialog.close();
      else dialogStatus.textContent = notice.textContent;
    });
  }

  list.addEventListener('click', async function (event) {
    if (paying) return;
    var remove = event.target.closest('[data-order-delete]');
    if (remove) {
      openAction('delete', remove, remove.dataset.orderDelete);
      return;
    }
    var refund = event.target.closest('[data-order-refund]');
    if (refund) {
      openAction('refund', refund, refund.dataset.orderRefund);
      return;
    }
    var button = event.target.closest('[data-order-pay]');
    if (!button || paying) return;
    var paymentWindow = window.open('about:blank', '_blank');
    if (!paymentWindow) {
      notice.textContent = '请允许浏览器打开新标签页后，再点击支付宝支付';
      return;
    }
    paymentWindow.opener = null;
    paying = true;
    button.disabled = true;
    notice.textContent = '';
    try {
      var response = await fetch('/api/orders/' + encodeURIComponent(button.dataset.orderPay) + '/pay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channel: 'alipay' })
      });
      var result = await response.json();
      if (!response.ok || !result.ok) throw Error(result.error || '发起支付失败，请重试');
      if (result.alreadyPaid) {
        paymentWindow.close();
      } else {
        if (!result.paymentUrl) throw Error('暂时无法发起支付，请重试');
        if (paymentWindow.closed) throw Error('支付标签页已关闭，请重新点击支付宝支付');
        paymentWindow.location.replace(result.paymentUrl);
      }
    } catch (error) {
      paymentWindow.close();
      notice.textContent = error.message || '支付请求失败，请重试';
    } finally {
      paying = false;
      button.disabled = false;
    }
    if (result && result.alreadyPaid) load();
  });

  window.addEventListener('focus', function () {
    if (view.classList.contains('active') && !(dialog && dialog.open)) load();
  });
  window.StudentOrders = { load: load };
  if (view.classList.contains('active') && !(dialog && dialog.open)) load();
}());
