/* 社区 v2 社交页签：找搭子 / 消息（通知 + 私信）。
 * 依赖 window.CZCommunity（共享工具）与 window.CZCommunityShell（页签壳）。
 * 所有服务器文本通过 textContent / CZCommunity.el 注入，不做任何 HTML 字符串拼接。 */
(function () {
  'use strict';

  var CZ = window.CZCommunity;
  var SHELL = window.CZCommunityShell;
  var API = '/api/community';
  var POLL_INTERVAL = 30000;
  var MAX_MESSAGE = 500;

  var partnerState = {
    container: null,
    list: null,
    provinceSelect: null,
    yearSelect: null,
    province: '',
    year: '',
    initialized: false,
    loading: false
  };

  var messageState = {
    container: null,
    body: null,
    list: null,
    chatList: null,
    noticeBtn: null,
    dmBtn: null,
    view: 'notifications',
    peer: null,
    peerId: 0,
    rows: [],
    lastId: 0,
    noticePage: 1,
    convPage: 1,
    sending: false,
    loading: false,
    pollTimer: null
  };

  // 从搭子卡点「私信」时暂存对端，切到消息页后直接打开对话。
  var pendingPeer = null;

  function el(tag, cls, text) {
    return CZ.el(tag, cls, text);
  }

  function button(label, cls, onClick) {
    var node = el('button', cls, label);
    node.type = 'button';
    if (onClick) node.addEventListener('click', onClick);
    return node;
  }

  function levelBadge(card) {
    if (!card || !card.level) return null;
    return el('span', 'cs-level', 'L' + card.level + (card.levelTitle ? ' · ' + card.levelTitle : ''));
  }

  function loginPrompt(tip) {
    var box = el('div', 'cs-login');
    box.appendChild(el('p', 'cs-login-text', tip));
    box.appendChild(button('去登录', 'cs-btn cs-btn-primary', function () {
      CZ.requireLogin('查看社区');
    }));
    return box;
  }

  function errorBlock(text, retry) {
    var box = el('div', 'cs-error');
    box.appendChild(el('p', 'cs-error-text', text));
    box.appendChild(button('重试', 'cs-btn cs-btn-ghost cs-btn-small', function () { retry(); }));
    return box;
  }

  function setChildren(node, children) {
    CZ.clear(node);
    for (var i = 0; i < children.length; i += 1) node.appendChild(children[i]);
  }

  // 异步返回时用来判断当前消息页主体是否已被新的 render 替换，避免把旧数据画进新视图。
  function viewChanged(body) {
    return !body || messageState.body !== body;
  }

  // ────────────────────────────── 找搭子 ──────────────────────────────

  function renderPartner(container) {
    stopPolling();
    partnerState.container = container;
    CZ.clear(container);

    var page = el('div', 'cs-partner');
    container.appendChild(page);

    var head = el('div', 'cs-panel-head');
    head.appendChild(el('h3', 'cs-panel-title', '找学习搭子'));
    head.appendChild(el('p', 'cs-panel-sub', '同省 · 同年 · 同目标，找到一起上岸的同路人'));
    page.appendChild(head);

    if (!CZ.signedIn()) {
      page.appendChild(loginPrompt('登录后查看学习搭子匹配'));
      return;
    }

    var filters = el('div', 'cs-filters');
    var provinceField = el('label', 'cs-filter-field');
    provinceField.appendChild(el('span', 'cs-filter-label', '省份'));
    partnerState.provinceSelect = document.createElement('select');
    partnerState.provinceSelect.className = 'cs-select';
    partnerState.provinceSelect.setAttribute('aria-label', '按省份筛选搭子');
    provinceField.appendChild(partnerState.provinceSelect);
    filters.appendChild(provinceField);

    var yearField = el('label', 'cs-filter-field');
    yearField.appendChild(el('span', 'cs-filter-label', '考试年份'));
    partnerState.yearSelect = document.createElement('select');
    partnerState.yearSelect.className = 'cs-select';
    partnerState.yearSelect.setAttribute('aria-label', '按考试年份筛选搭子');
    yearField.appendChild(partnerState.yearSelect);
    filters.appendChild(yearField);

    filters.appendChild(button('重置', 'cs-btn cs-btn-ghost cs-btn-small', function () {
      if (partnerState.provinceSelect) partnerState.provinceSelect.value = '';
      if (partnerState.yearSelect) partnerState.yearSelect.value = '';
      partnerState.province = '';
      partnerState.year = '';
      loadPartner(false);
    }));
    page.appendChild(filters);

    partnerState.provinceSelect.addEventListener('change', function () {
      partnerState.province = partnerState.provinceSelect.value;
      loadPartner(false);
    });
    partnerState.yearSelect.addEventListener('change', function () {
      partnerState.year = partnerState.yearSelect.value;
      loadPartner(false);
    });

    partnerState.list = el('div', 'cs-partner-list');
    page.appendChild(partnerState.list);

    loadPartner(true);
  }

  function partnerUrl() {
    var params = [];
    if (partnerState.province) params.push('province=' + encodeURIComponent(partnerState.province));
    if (partnerState.year) params.push('year=' + encodeURIComponent(partnerState.year));
    params.push('limit=20');
    return API + '/partners?' + params.join('&');
  }

  function fillPartnerFilters(filters, me) {
    var provinceSelect = partnerState.provinceSelect;
    var yearSelect = partnerState.yearSelect;
    if (!provinceSelect || !yearSelect) return;
    var provinces = (filters && filters.provinces) || [];
    var years = (filters && filters.years) || [];
    var provinceOptions = [el('option', '', '全部省份')];
    provinceOptions[0].value = '';
    for (var i = 0; i < provinces.length; i += 1) {
      var item = provinces[i];
      var option = el('option', '', item.name || ('省份 ' + item.code));
      option.value = String(item.code || '');
      provinceOptions.push(option);
    }
    setChildren(provinceSelect, provinceOptions);
    var yearOptions = [el('option', '', '全部年份')];
    yearOptions[0].value = '';
    for (var j = 0; j < years.length; j += 1) {
      var y = el('option', '', String(years[j]) + ' 年');
      y.value = String(years[j]);
      yearOptions.push(y);
    }
    setChildren(yearSelect, yearOptions);

    partnerState.province = me && me.provinceCode ? String(me.provinceCode) : '';
    partnerState.year = me && me.examYear ? String(me.examYear) : '';
    provinceSelect.value = partnerState.province;
    yearSelect.value = partnerState.year;
    // 我的省份不在下拉里时补一个，避免显示为空。
    if (partnerState.province && provinceSelect.value !== partnerState.province) {
      var mine = el('option', '', '省份 ' + partnerState.province);
      mine.value = partnerState.province;
      provinceSelect.appendChild(mine);
      provinceSelect.value = partnerState.province;
    }
    if (partnerState.year && yearSelect.value !== partnerState.year) {
      var mineYear = el('option', '', partnerState.year + ' 年');
      mineYear.value = partnerState.year;
      yearSelect.appendChild(mineYear);
      yearSelect.value = partnerState.year;
    }
  }

  async function loadPartner(initial) {
    var list = partnerState.list;
    if (!list || partnerState.loading) return;
    if (!CZ.signedIn()) return;
    partnerState.loading = true;
    CZ.clear(list);
    list.appendChild(CZ.loadingEl('正在匹配同路人…'));
    try {
      if (initial) {
        var meta = await CZ.request(API + '/partners?limit=50');
        if (!meta.ok || !meta.data) {
          CZ.clear(list);
          list.appendChild(errorBlock('搭子列表加载失败', function () { loadPartner(true); }));
          return;
        }
        if (!partnerState.initialized) {
          fillPartnerFilters(meta.data.filters || {}, meta.data.me || {});
          partnerState.initialized = true;
        }
      }
      var response = await CZ.request(partnerUrl());
      if (!response.ok || !response.data) {
        CZ.clear(list);
        list.appendChild(errorBlock('搭子列表加载失败', function () { loadPartner(false); }));
        return;
      }
      renderPartnerRows(list, response.data.rows || []);
    } finally {
      partnerState.loading = false;
    }
  }

  function renderPartnerRows(list, rows) {
    if (!list) return;
    CZ.clear(list);
    if (!rows.length) {
      list.appendChild(CZ.emptyEl('完善目标院校专业后更容易匹配'));
      var tip = el('p', 'cs-empty-tip', '也可以放宽省份或考试年份筛选，先认识更多同路人');
      list.appendChild(tip);
      return;
    }
    for (var i = 0; i < rows.length; i += 1) list.appendChild(partnerCard(rows[i]));
  }

  function partnerCard(card) {
    var article = el('article', 'cs-partner-card');

    var top = el('div', 'cs-card-top');
    top.appendChild(CZ.avatarEl(card, 48));
    var identity = el('div', 'cs-card-identity');
    var nameRow = el('div', 'cs-card-name-row');
    nameRow.appendChild(el('strong', 'cs-card-name', card.name || '学员'));
    var badge = levelBadge(card);
    if (badge) nameRow.appendChild(badge);
    identity.appendChild(nameRow);

    var meta = [];
    if (card.provinceName || card.provinceCode) meta.push(card.provinceName || ('省份 ' + card.provinceCode));
    if (card.examYear) meta.push(card.examYear + ' 年考试');
    identity.appendChild(el('p', 'cs-card-meta', meta.length ? meta.join(' · ') : '资料待完善'));
    top.appendChild(identity);
    article.appendChild(top);

    if (card.targetSchool || card.targetMajor) {
      article.appendChild(el('p', 'cs-card-target',
        '目标：' + (card.targetSchool || '院校待定') + ' · ' + (card.targetMajor || '专业待定')));
    }
    if (card.bio) article.appendChild(el('p', 'cs-card-bio', card.bio));
    if (card.studyTags && card.studyTags.length) {
      var tags = el('div', 'cs-card-tags');
      for (var i = 0; i < card.studyTags.length; i += 1) tags.appendChild(el('span', 'cs-tag', card.studyTags[i]));
      article.appendChild(tags);
    }
    var reasons = (card.matchReasons || []).slice(0, 4);
    var reasonRow = el('div', 'cs-card-reasons');
    if (reasons.length) {
      for (var j = 0; j < reasons.length; j += 1) reasonRow.appendChild(el('span', 'cs-reason', reasons[j]));
    } else {
      reasonRow.appendChild(el('span', 'cs-reason cs-reason-muted', '先关注，慢慢熟悉'));
    }
    article.appendChild(reasonRow);

    var actions = el('div', 'cs-card-actions');
    var follow = button(card.followingHim ? '已关注' : '关注', 'cs-btn cs-btn-primary cs-btn-small' + (card.followingHim ? ' is-following' : ''));
    follow.addEventListener('click', function () { toggleFollow(card, follow); });
    actions.appendChild(follow);
    actions.appendChild(button('私信', 'cs-btn cs-btn-ghost cs-btn-small', function () {
      openMessageWith(card);
    }));
    article.appendChild(actions);
    return article;
  }

  async function toggleFollow(card, btn) {
    if (!CZ.requireLogin('关注')) return;
    if (!card || !card.id || btn.disabled) return;
    btn.disabled = true;
    var response = await CZ.request(API + '/follow/' + card.id, { method: 'POST' });
    btn.disabled = false;
    if (!response.ok) {
      CZ.toast((response.data && response.data.error) || '操作失败，请稍后再试');
      return;
    }
    var following = !!(response.data && response.data.following);
    card.followingHim = following;
    btn.textContent = following ? '已关注' : '关注';
    if (following) btn.classList.add('is-following');
    else btn.classList.remove('is-following');
    CZ.toast(following ? '已关注' : '已取消关注');
  }

  function openMessageWith(peer) {
    if (!CZ.requireLogin('私信')) return;
    if (!peer || !peer.id) return;
    pendingPeer = peer;
    messageState.peer = peer;
    messageState.peerId = Number(peer.id) || 0;
    messageState.view = 'conversation';
    messageState.lastId = 0;
    SHELL.show('message');
  }

  // ────────────────────────────── 消息页壳 ──────────────────────────────

  function renderMessage(container) {
    stopPolling();
    messageState.container = container;
    messageState.body = null;
    CZ.clear(container);

    var page = el('div', 'cs-message');
    container.appendChild(page);

    if (!CZ.signedIn()) {
      page.appendChild(loginPrompt('登录后查看通知与私信'));
      SHELL.setBadge(0);
      return;
    }

    if (pendingPeer) {
      messageState.peer = pendingPeer;
      messageState.peerId = Number(pendingPeer.id) || 0;
      messageState.view = 'conversation';
      messageState.lastId = 0;
      pendingPeer = null;
    }

    var head = el('div', 'cs-panel-head');
    head.appendChild(el('h3', 'cs-panel-title', '消息'));
    head.appendChild(el('p', 'cs-panel-sub', '通知与私信都在这里'));
    page.appendChild(head);

    var seg = el('div', 'cs-seg');
    messageState.noticeBtn = button('通知', 'cs-seg-btn', function () {
      messageState.view = 'notifications';
      messageState.peer = null;
      messageState.peerId = 0;
      messageState.noticePage = 1;
      updateSegment();
      renderMessageBody();
    });
    messageState.dmBtn = button('私信', 'cs-seg-btn', function () {
      messageState.view = 'conversations';
      messageState.peer = null;
      messageState.peerId = 0;
      messageState.convPage = 1;
      updateSegment();
      renderMessageBody();
    });
    seg.appendChild(messageState.noticeBtn);
    seg.appendChild(messageState.dmBtn);
    page.appendChild(seg);

    messageState.body = el('div', 'cs-message-body');
    page.appendChild(messageState.body);

    updateSegment();
    startPolling();
    refreshUnread();
    if (messageState.view === 'conversation' && messageState.peerId) renderConversation();
    else if (messageState.view === 'conversations') renderConversations();
    else {
      messageState.view = 'notifications';
      updateSegment();
      renderNotifications();
    }
  }

  function updateSegment() {
    var noticeActive = messageState.view === 'notifications';
    var dmActive = !noticeActive;
    if (messageState.noticeBtn) {
      messageState.noticeBtn.classList.toggle('active', noticeActive);
      messageState.noticeBtn.setAttribute('aria-selected', noticeActive ? 'true' : 'false');
    }
    if (messageState.dmBtn) {
      messageState.dmBtn.classList.toggle('active', dmActive);
      messageState.dmBtn.setAttribute('aria-selected', dmActive ? 'true' : 'false');
    }
  }

  function renderMessageBody() {
    if (!messageState.body) return;
    if (messageState.view === 'conversation' && messageState.peerId) renderConversation();
    else if (messageState.view === 'conversations') renderConversations();
    else renderNotifications();
  }

  // ────────────────────────────── 通知 ──────────────────────────────

  function notificationIcon(type) {
    if (type === 'like') return '👍';
    if (type === 'comment') return '💬';
    if (type === 'reply') return '↩';
    if (type === 'follow') return '＋';
    if (type === 'favorite') return '★';
    return '🔔';
  }

  async function renderNotifications() {
    var body = messageState.body;
    if (!body) return;
    messageState.noticePage = 1;
    CZ.clear(body);
    body.appendChild(CZ.loadingEl('加载通知…'));
    var response = await CZ.request(API + '/notifications?page=1');
    if (viewChanged(body) || messageState.view !== 'notifications') return;
    CZ.clear(body);
    if (!response.ok || !response.data) {
      body.appendChild(errorBlock('通知加载失败', function () { renderNotifications(); }));
      return;
    }
    renderNotificationRows(body, response.data);
  }

  function renderNotificationRows(body, data) {
    var rows = data.rows || [];
    var head = el('div', 'cs-notice-head');
    head.appendChild(el('span', 'cs-notice-count', '未读 ' + (Number(data.unread) || 0)));
    var readAll = button('全部已读', 'cs-link-btn', function () { markAllNotificationsRead(); });
    if (!Number(data.unread)) readAll.disabled = true;
    head.appendChild(readAll);
    body.appendChild(head);

    if (!rows.length) {
      body.appendChild(CZ.emptyEl('暂无通知，去广场和大家互动吧'));
      return;
    }
    var list = el('div', 'cs-notify-list');
    for (var i = 0; i < rows.length; i += 1) list.appendChild(notificationItem(rows[i]));
    body.appendChild(list);

    if ((Number(data.total) || 0) > rows.length) {
      var more = button('加载更多', 'cs-btn cs-btn-ghost cs-btn-small', async function () {
        if (more.disabled) return;
        more.disabled = true;
        messageState.noticePage += 1;
        var res = await CZ.request(API + '/notifications?page=' + messageState.noticePage);
        more.disabled = false;
        if (!res.ok || !res.data) {
          messageState.noticePage -= 1;
          CZ.toast('加载失败，请稍后再试');
          return;
        }
        var extra = res.data.rows || [];
        for (var k = 0; k < extra.length; k += 1) list.appendChild(notificationItem(extra[k]));
        if (!extra.length && more.parentNode) more.parentNode.removeChild(more);
      });
      body.appendChild(more);
    }
  }

  function notificationItem(item) {
    var row = el('div', 'cs-notify-item' + (item.isRead ? '' : ' is-unread'));
    row.appendChild(el('span', 'cs-notify-icon', notificationIcon(item.type)));
    var main = el('div', 'cs-notify-main');
    var content = String(item.content || '');
    var actorName = item.actor && item.actor.name ? String(item.actor.name) : '';
    // 通知文案由各模块写入，老数据可能不含昵称，这里补上触发者名字。
    if (item.type !== 'system' && actorName && content.indexOf(actorName) < 0) {
      content = actorName + ' ' + content;
    }
    if (!content) {
      content = (actorName || '有人') + ' 有一条新消息';
    }
    main.appendChild(el('p', 'cs-notify-text', content));
    var meta = el('div', 'cs-notify-meta');
    meta.appendChild(el('span', 'cs-notify-time', CZ.timeAgo(item.createdAt)));
    if (!item.isRead) meta.appendChild(el('span', 'cs-unread-dot'));
    main.appendChild(meta);
    row.appendChild(main);
    row.addEventListener('click', function () { handleNotification(item, row); });
    return row;
  }

  async function handleNotification(item, row) {
    if (!item.isRead) {
      item.isRead = true;
      row.classList.remove('is-unread');
      var dot = row.querySelector('.cs-unread-dot');
      if (dot && dot.parentNode) dot.parentNode.removeChild(dot);
      CZ.request(API + '/notifications/read', { body: { ids: [item.id] } }).then(function () {
        refreshUnread();
      });
    }
    var actor = item.actor || {};
    if (item.type === 'follow' || item.targetType === 'student') {
      if (actor.id) {
        messageState.peer = { id: actor.id, name: actor.name || '学员', avatar: actor.avatar || '',gender:actor.gender||'unknown' };
        messageState.peerId = Number(actor.id);
        messageState.view = 'conversation';
        messageState.lastId = 0;
        updateSegment();
        renderMessageBody();
        return;
      }
    }
    if (item.type === 'system') {
      if (item.content) CZ.toast(item.content);
      return;
    }
    // 点赞 / 评论 / 回复 / 收藏：回到广场继续看帖子。
    SHELL.show('plaza');
  }

  async function markAllNotificationsRead() {
    var response = await CZ.request(API + '/notifications/read', { body: { all: true } });
    if (!response.ok) {
      CZ.toast((response.data && response.data.error) || '操作失败');
      return;
    }
    CZ.toast('全部已读');
    refreshUnread();
    if (messageState.view === 'notifications') renderNotifications();
  }

  // ────────────────────────────── 私信会话列表 ──────────────────────────────

  async function renderConversations(silent) {
    var body = messageState.body;
    if (!body) return;
    if (!silent) {
      CZ.clear(body);
      body.appendChild(CZ.loadingEl('加载私信…'));
    }
    var response = await CZ.request(API + '/messages/conversations?page=1');
    if (viewChanged(body) || messageState.view !== 'conversations') return;
    if (!response.ok || !response.data) {
      if (silent) return;
      CZ.clear(body);
      body.appendChild(errorBlock('私信加载失败', function () { renderConversations(); }));
      return;
    }
    CZ.clear(body);
    var data = response.data;
    var rows = data.rows || [];
    if ((Number(data.total) || 0) > rows.length) {
      body.appendChild(el('p', 'cs-list-tip', '共 ' + (Number(data.total) || 0) + ' 个会话，仅显示最近 ' + rows.length + ' 个'));
    }
    if (!rows.length) {
      body.appendChild(CZ.emptyEl('还没有私信，去「找搭子」认识同路人吧'));
      return;
    }
    var list = el('div', 'cs-conv-list');
    for (var i = 0; i < rows.length; i += 1) list.appendChild(conversationItem(rows[i]));
    body.appendChild(list);
  }

  function conversationItem(conversation) {
    var peer = conversation.peer || {};
    var row = el('div', 'cs-conv-item');
    row.appendChild(CZ.avatarEl(peer, 44));
    var main = el('div', 'cs-conv-main');
    var top = el('div', 'cs-conv-top');
    top.appendChild(el('strong', 'cs-conv-name', peer.name || '学员'));
    top.appendChild(el('span', 'cs-conv-time', CZ.timeAgo(conversation.lastAt)));
    main.appendChild(top);
    main.appendChild(el('p', 'cs-conv-last', conversation.lastMessage || ''));
    row.appendChild(main);
    if (Number(conversation.unread) > 0) {
      row.appendChild(el('span', 'cs-conv-badge', Number(conversation.unread) > 99 ? '99+' : String(conversation.unread)));
    }
    row.addEventListener('click', function () { openConversation(peer); });
    return row;
  }

  function openConversation(peer) {
    if (!peer || !peer.id) return;
    messageState.peer = peer;
    messageState.peerId = Number(peer.id);
    messageState.view = 'conversation';
    messageState.rows = [];
    messageState.lastId = 0;
    updateSegment();
    renderMessageBody();
  }

  // ────────────────────────────── 对话 ──────────────────────────────

  function parseStamp(text) {
    var raw = String(text || '');
    if (!raw) return 0;
    var normalized = raw.replace(' ', 'T');
    if (!/Z|[+-]\d\d:?\d\d$/.test(raw)) normalized += 'Z';
    var stamp = Date.parse(normalized);
    return Number.isFinite(stamp) ? stamp : 0;
  }

  function messageRow(row, previous) {
    var wrap = el('div', 'cs-msg-row' + (row.isMine ? ' is-mine' : ''));
    var prevStamp = previous ? parseStamp(previous.createdAt) : 0;
    var stamp = parseStamp(row.createdAt);
    if (!previous || (stamp && prevStamp && stamp - prevStamp > 5 * 60 * 1000)) {
      wrap.appendChild(el('div', 'cs-msg-time', CZ.timeAgo(row.createdAt)));
    }
    var bubble = el('div', 'cs-bubble', row.body);
    wrap.appendChild(bubble);
    return wrap;
  }

  function renderChatRows(list, rows) {
    if (!list) return;
    CZ.clear(list);
    for (var i = 0; i < rows.length; i += 1) {
      var prev = i === 0 ? null : rows[i - 1];
      list.appendChild(messageRow(rows[i], prev));
    }
  }

  function scrollChatToBottom() {
    if (messageState.chatList) messageState.chatList.scrollTop = messageState.chatList.scrollHeight;
  }

  async function renderConversation() {
    var body = messageState.body;
    if (!body || !messageState.peerId) return;
    var peer = messageState.peer || { id: messageState.peerId, name: '学员' };
    CZ.clear(body);
    var chat = el('div', 'cs-chat');
    var head = el('div', 'cs-chat-head');
    head.appendChild(button('←', 'cs-back', function () {
      messageState.view = 'conversations';
      messageState.peer = null;
      messageState.peerId = 0;
      messageState.rows = [];
      messageState.lastId = 0;
      updateSegment();
      renderMessageBody();
    }));
    head.appendChild(CZ.avatarEl(peer, 34));
    var who = el('div', 'cs-chat-peer');
    who.appendChild(el('strong', 'cs-chat-name', peer.name || '学员'));
    var badge = levelBadge(peer);
    if (badge) who.appendChild(badge);
    head.appendChild(who);
    head.appendChild(button('会话列表', 'cs-link-btn', function () {
      messageState.view = 'conversations';
      messageState.peer = null;
      messageState.peerId = 0;
      messageState.rows = [];
      messageState.lastId = 0;
      updateSegment();
      renderMessageBody();
    }));
    chat.appendChild(head);

    var list = el('div', 'cs-chat-body');
    messageState.chatList = list;
    list.appendChild(CZ.loadingEl('加载消息…'));
    chat.appendChild(list);

    var composer = el('div', 'cs-composer');
    chat.appendChild(composer);
    body.appendChild(chat);

    var response = await CZ.request(API + '/messages/' + messageState.peerId);
    if (viewChanged(body) || messageState.view !== 'conversation') return;
    CZ.clear(list);
    if (!response.ok || !response.data) {
      list.appendChild(errorBlock('消息加载失败', function () { renderConversation(); }));
      return;
    }
    var data = response.data;
    if (data.peer) {
      messageState.peer = data.peer;
      if (data.peer.name) {
        var nameNode = who.querySelector('.cs-chat-name');
        if (nameNode) nameNode.textContent = data.peer.name;
      }
    }
    messageState.rows = data.rows || [];
    messageState.lastId = messageState.rows.length ? messageState.rows[messageState.rows.length - 1].id : 0;
    renderChatRows(list, messageState.rows);
    if (!messageState.rows.length) list.appendChild(CZ.emptyEl('还没有消息，打个招呼吧'));
    buildComposer(composer);
    scrollChatToBottom();
    refreshUnread();
  }

  function buildComposer(composer) {
    if (!composer) return;
    var textarea = document.createElement('textarea');
    textarea.className = 'cs-composer-input';
    textarea.rows = 1;
    textarea.maxLength = MAX_MESSAGE;
    textarea.placeholder = '说点什么…（Enter 发送，Shift+Enter 换行）';
    textarea.setAttribute('aria-label', '私信内容');
    var counter = el('span', 'cs-composer-count', '0/' + MAX_MESSAGE);
    textarea.addEventListener('input', function () {
      counter.textContent = Array.from(textarea.value).length + '/' + MAX_MESSAGE;
    });
    var send = button('发送', 'cs-btn cs-btn-primary cs-send', function () { sendMessage(textarea, counter, send); });
    textarea.addEventListener('keydown', function (event) {
      if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        send.click();
      }
    });
    composer.appendChild(textarea);
    composer.appendChild(counter);
    composer.appendChild(send);
  }

  async function sendMessage(textarea, counter, sendBtn) {
    if (messageState.sending) return;
    if (!CZ.requireLogin('发送私信')) return;
    var value = String(textarea.value || '').trim();
    if (!value) {
      CZ.toast('请输入消息内容');
      return;
    }
    if (Array.from(value).length > MAX_MESSAGE) {
      CZ.toast('消息最多 ' + MAX_MESSAGE + ' 个字');
      return;
    }
    messageState.sending = true;
    sendBtn.disabled = true;
    var response = await CZ.request(API + '/messages/' + messageState.peerId, { body: { body: value } });
    messageState.sending = false;
    sendBtn.disabled = false;
    if (!response.ok || !response.data) {
      CZ.toast((response.data && response.data.error) || '发送失败，请稍后再试');
      return;
    }
    textarea.value = '';
    counter.textContent = '0/' + MAX_MESSAGE;
    var message = response.data.message;
    messageState.rows.push(message);
    messageState.lastId = message.id;
    if (messageState.chatList) {
      var empty = messageState.chatList.querySelector('.cm-empty');
      if (empty) CZ.clear(messageState.chatList);
      messageState.chatList.appendChild(messageRow(message, messageState.rows.length > 1 ? messageState.rows[messageState.rows.length - 2] : null));
      scrollChatToBottom();
    }
    refreshUnread();
  }

  // ────────────────────────────── 轮询 / 未读角标 ──────────────────────────────

  async function refreshUnread() {
    if (!CZ.signedIn()) {
      SHELL.setBadge(0);
      return;
    }
    var response = await CZ.request(API + '/messages/unread');
    if (response.ok && response.data && typeof response.data.total === 'number') {
      SHELL.setBadge(response.data.total);
    }
  }

  function startPolling() {
    stopPolling();
    messageState.pollTimer = setInterval(pollTick, POLL_INTERVAL);
  }

  function stopPolling() {
    if (messageState.pollTimer) {
      clearInterval(messageState.pollTimer);
      messageState.pollTimer = null;
    }
  }

  async function pollTick() {
    // 离开消息页签后停止轮询；页面隐藏时跳过本轮。
    if (SHELL.current() !== 'message') {
      stopPolling();
      return;
    }
    if (document.hidden) return;
    await refreshUnread();
    if (!CZ.signedIn() || !messageState.body) return;
    if (messageState.view === 'conversation' && messageState.peerId) pollConversation();
    else if (messageState.view === 'conversations') renderConversations(true);
  }

  async function pollConversation() {
    var response = await CZ.request(API + '/messages/' + messageState.peerId + '?limit=20');
    if (!response.ok || !response.data) return;
    if (messageState.view !== 'conversation') return;
    var rows = response.data.rows || [];
    var newest = rows.length ? rows[rows.length - 1].id : 0;
    if (!newest || newest <= messageState.lastId) return;
    var known = {};
    for (var i = 0; i < messageState.rows.length; i += 1) known[messageState.rows[i].id] = true;
    var additions = [];
    for (var j = 0; j < rows.length; j += 1) {
      if (!known[rows[j].id]) additions.push(rows[j]);
    }
    if (!additions.length) return;
    messageState.rows = messageState.rows.concat(additions);
    messageState.lastId = additions[additions.length - 1].id;
    if (messageState.chatList) {
      for (var k = 0; k < additions.length; k += 1) {
        var prev = k === 0 ? messageState.rows[messageState.rows.length - additions.length - 1] : additions[k - 1];
        messageState.chatList.appendChild(messageRow(additions[k], prev));
      }
      scrollChatToBottom();
    }
    refreshUnread();
  }

  // ────────────────────────────── 注册 ──────────────────────────────

  function boot() {
    CZ = window.CZCommunity;
    SHELL = window.CZCommunityShell;
    if (!CZ || !SHELL) return;
    CZCommunityShellRegister();
  }

  function CZCommunityShellRegister() {
    window.CZCommunityShell.register('partner', {
      render: renderPartner,
      refresh: function () {
        if (SHELL.current() === 'partner' && partnerState.list) loadPartner(false);
      }
    });
    window.CZCommunityShell.register('message', {
      render: renderMessage,
      refresh: function () {
        if (SHELL.current() === 'message' && messageState.container) refreshUnread();
      }
    });
    // 页签壳在脚本加载时已按 location.hash 选过一次页签，那时社交模块可能还没注册；
    // 这里补一次深链跳转（只处理本模块的两个页签）。
    var hash = String(window.location.hash || '').replace('#community-', '');
    if (hash === 'partner' || hash === 'message') {
      window.setTimeout(function () { SHELL.show(hash); }, 0);
    }
  }

  document.addEventListener('visibilitychange', function () {
    if (!document.hidden && SHELL && SHELL.current() === 'message' && messageState.container) pollTick();
  });

  if (window.CZCommunity && window.CZCommunityShell) boot();
  else document.addEventListener('DOMContentLoaded', boot);
})();
