(function(){
 window.createTeachingPointer=function(stage){
  var point=null;
  stage.addEventListener('pointermove',function(e){
   if(e.target.closest('button,input,select,.pen-toolbar,.tool-pop')){point=null;return;}
   var r=stage.getBoundingClientRect();point={x:(e.clientX-r.left)/r.width,y:(e.clientY-r.top)/r.height};
  });
  stage.addEventListener('pointerleave',function(){point=null});
  window.addEventListener('blur',function(){point=null});
  return {draw:function(ctx,width,height){
   if(!point)return;
   ctx.save();ctx.translate(point.x*width,point.y*height);
   ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(0,18);ctx.lineTo(4.5,14);ctx.lineTo(8,22);ctx.lineTo(11,20.5);ctx.lineTo(7.5,12.5);ctx.lineTo(14,12.5);ctx.closePath();
   ctx.fillStyle='#FFFFFF';ctx.strokeStyle='#262A2E';ctx.lineWidth=1.5;ctx.lineJoin='round';ctx.fill();ctx.stroke();ctx.restore();
  }};
 };
})();
