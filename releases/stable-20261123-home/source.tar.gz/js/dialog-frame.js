/* One content-height owner for same-origin form iframes; the outer dialog owns scrolling. */
(function(root){
 if(root.ChengzeDialogFrame)return;
 root.ChengzeDialogFrame={attach:function(dialog,frame,options){
  let resize,removal,raf=0,disposed=false;
  function stop(){if(resize)resize.disconnect();if(raf)cancelAnimationFrame(raf);raf=0;}
  function fit(content){if(disposed||!dialog.open||!dialog.isConnected)return;const height=Math.ceil(Math.max(content.scrollHeight,content.getBoundingClientRect().height));if(height>0&&Math.abs(frame.getBoundingClientRect().height-height)>1)frame.style.height=height+'px';}
  function loaded(){
   stop();if(disposed||!dialog.open)return;
   try{
    const doc=frame.contentDocument,path=frame.contentWindow.location.pathname;
    if(options.completedPaths.includes(path)){dialog.close();options.onSaved();return;}
    const content=doc.querySelector(options.content);if(!content)return;
    const schedule=()=>{if(!raf)raf=requestAnimationFrame(()=>{raf=0;fit(content);});};
    fit(content);resize=new ResizeObserver(schedule);resize.observe(content);
    const close=doc.getElementById(options.closeId);if(close)close.addEventListener('click',()=>dialog.close(),{once:true});
   }catch(error){console.error('Embedded dialog:',error.message);}
  }
  function destroy(){if(disposed)return;disposed=true;stop();removal.disconnect();frame.removeEventListener('load',loaded);dialog.removeEventListener('close',stop);}
  frame.addEventListener('load',loaded);dialog.addEventListener('close',stop);
  removal=new MutationObserver(()=>{if(!dialog.isConnected)destroy();});removal.observe(document.body,{childList:true,subtree:true});
  return {destroy};
 }};
})(window);
