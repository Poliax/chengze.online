(function(){
 const groups=[['.volume-box','#volRange',false],['.rate-wrap','#rateRange',true]].map(([q,id,rate])=>{const group=document.querySelector('.replay-studio .controls '+q+',.live-studio .player-controls '+q),input=document.querySelector(id);if(!group||!input)return null;const popup=group.querySelector('.volume-popover,.rate-menu');const value=document.createElement('output');value.className='vertical-slider-value';value.setAttribute('for',input.id);popup.prepend(value);
 function sync(){const n=Number(input.value),percent=(n-Number(input.min))/(Number(input.max)-Number(input.min))*100;input.style.setProperty('--slider-fill',percent+'%');value.textContent=rate?(Number.isInteger(n)?n.toFixed(1):String(n))+'x':String(Math.round(n));input.removeAttribute('title');}
 input.addEventListener('input',sync);input.addEventListener('change',sync);input.addEventListener('pointerenter',sync);group.addEventListener('click',()=>setTimeout(sync,0));const video=document.getElementById('mainVideo');if(video)video.addEventListener('volumechange',sync);sync();
 return {group,popup,input};}).filter(Boolean);
 function close(current){clearTimeout(current.timer);current.popup.classList.remove('open');current.group.classList.add('slider-suppressed');const toggle=current.group.querySelector('button');if(toggle)toggle.setAttribute('aria-expanded','false');}
 function open(current){clearTimeout(current.timer);for(const other of groups)if(other!==current)close(other);current.group.classList.remove('slider-suppressed');current.popup.classList.add('open');const toggle=current.group.querySelector('button');if(toggle)toggle.setAttribute('aria-expanded','true');}
 for(const current of groups){
  current.group.addEventListener('pointerenter',()=>open(current));
  current.popup.addEventListener('pointerenter',()=>open(current));
  current.group.addEventListener('pointerleave',()=>{if(!current.dragging)current.timer=setTimeout(()=>{if(!current.group.matches(':hover'))close(current);},300);});
  current.input.addEventListener('pointerdown',()=>{current.dragging=true;open(current);});
  const finish=()=>{if(current.dragging){current.dragging=false;if(!current.group.matches(':hover'))close(current);}};
  window.addEventListener('pointerup',finish);window.addEventListener('pointercancel',finish);
  current.input.addEventListener('focus',()=>open(current));
  current.input.addEventListener('keydown',event=>{if(event.key==='Escape'){current.input.blur();close(current);}});
 }
 document.addEventListener('pointerdown',event=>{if(!event.target.closest('.rate-wrap,.volume-box'))for(const current of groups)close(current);});
})();
