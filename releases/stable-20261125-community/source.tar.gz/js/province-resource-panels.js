(function(){'use strict';
 var province=document.getElementById('globalProvince'),year=document.getElementById('globalYear'),version=0,lastData=null;
 if(!province||!year||!window.ChengzeStudyResources)return;
 var panes=[['考试公告','resMajor'],['考试大纲','resSyllabus'],['历年真题','resPapers'],['备考经验','resExperience'],['备考资料','resPreparation']];
 function node(tag,text,cls){var e=document.createElement(tag);if(text)e.textContent=text;if(cls)e.className=cls;return e;}
 function render(data){
  if(!data||String(data.code)!==String(province.value))return;
  document.getElementById('homeResourceContent').removeAttribute('data-resources-pending');
  lastData=data;var target=Number(year.value),rows=window.ChengzeStudyResources.catalog(data);
  panes.forEach(function(pair){var box=document.getElementById(pair[1]);if(!box)return;box.replaceChildren();var list=rows.filter(function(r){return r.type===pair[0]&&(!r.year||(r.type==='历年真题'?r.year<=target:r.type==='考试公告'?r.year>=target-2&&r.year<=target:(r.type==='备考经验'||r.type==='备考资料')?r.year<=target:r.year===target));});
   if(!list.length){box.append(node('div','当前省份'+(pair[0]==='考试公告'?(target-2)+'—'+target:target)+'年暂无'+pair[0],'res-empty'));return;}
   list.forEach(function(r){var file=node('a','','res-file resource-card'),icon=node('span','','resource-file-icon'),info=node('div','','info');
    icon.setAttribute('aria-hidden','true');var ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg'),path=document.createElementNS(ns,'path'),mark=document.createElementNS(ns,'text');svg.setAttribute('viewBox','0 0 28 34');path.setAttribute('d','M4 1h13l7 7v25H4z M17 1v8h7');path.setAttribute('fill','none');path.setAttribute('stroke','currentColor');path.setAttribute('stroke-width','1.3');mark.setAttribute('x','14');mark.setAttribute('y','24');mark.setAttribute('text-anchor','middle');mark.setAttribute('font-size','7');mark.setAttribute('fill','currentColor');mark.textContent=/\.pdf(?:[?#]|$)/i.test(r.url)?'PDF':'文档';svg.append(path,mark);icon.append(svg);
    info.append(node('strong',r.title));file.href=r.url;file.target='_blank';file.rel='noopener';if(!/^\/notices\/\d+$/.test(r.url))file.dataset.resourcePreview='';else mark.textContent='公告';file.dataset.resourceTitle=r.title;file.setAttribute('aria-label','查看'+r.title);file.append(icon,info);box.append(file);});
  });
 if(window.saveHomePublicSnapshot)window.saveHomePublicSnapshot();

 }
 async function load(){var id=++version,code=province.value;if(!document.getElementById('homeResourceContent').hasAttribute('data-initial-restored'))panes.forEach(function(pair){var e=document.getElementById(pair[1]);if(e)e.replaceChildren(node('div','正在加载本省资料…','res-empty'));});try{var r=await fetch('/provinces/api/'+encodeURIComponent(code),{cache:'no-store'});if(!r.ok)throw Error();var data=await r.json();if(id!==version)return;if(!data)throw Error();render(data);}catch{if(id!==version)return;document.getElementById('homeResourceContent').removeAttribute('data-resources-pending');panes.forEach(function(pair){var box=document.getElementById(pair[1]);if(!box)return;var message=node('div','资料加载失败，请重试。','res-empty'),button=node('button','重新加载');button.type='button';button.addEventListener('click',load);message.append(button);box.replaceChildren(message);});}}
 province.addEventListener('change',load);year.addEventListener('change',function(){if(lastData&&String(lastData.code)===String(province.value))render(lastData);else load();});
 window.ChengzeResourcePanels={render:render};load();
})();
