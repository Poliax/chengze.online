// 社区 v2 广场（学员端）：动态流（推荐/关注）与右侧热门推荐+ 帖子/瞬间/匿名发布 +
// 点赞/收藏/评论（楼中楼）/举报/删除。纯 DOM API 与 textContent 注入，不拼 HTML。
// 注册到 CZCommunityShell 的 plaza 页签；保留 window.CommunityStudio = { refresh } 导出。
(function () {
  'use strict';

  var API = '/api/community';
  var C = window.CZCommunity;
  if (!C) return;

  var FLOWS = [
    { key: 'recommend', label: '推荐' },
    { key: 'following', label: '关注' },
    { key: 'qa', label: '问答' }
  ];
  var REASONS = ['广告骚扰', '联系方式', '辱骂攻击', '违法违规', '其他'];
  var FALLBACK_TAGS = ['学习打卡', '找学习搭子', '问答', '备考建议', '资料分享', '上岸喜报', '其他'];
  function topicLabel(tag){return ({'找学习搭子':'找搭子','问答':'提问'})[tag]||tag;}
  var PAGE_SIZE = 10;
  var EMPTY_TEXT = {
    recommend: '还没有人分享，来发第一条备考记录吧',
    following: '关注的人还没有发布内容，去「找搭子」发现同路人',
    peer: '登录并完善省份/考试年份后，才能看到同路人',
    treehole: '树洞里还没有匿名分享，说出你的心里话吧',
    hot: '近 7 天还没有上榜内容，先来发一条吧'
  };

  var state = {
    tab: 'recommend',
    tag: '',
    tags: FALLBACK_TAGS.slice(),
    page: 1,
    total: 0,
    loading: false,
    seq: 0
  };
  var root = null;
  var refs = {};
  var openComposer = function () {};

  // ── 小工具 ──
  function el(tag, className, text) {
    return C.el(tag, className, text);
  }

  function setText(node, text) {
    node.textContent = text === undefined || text === null ? '' : String(text);
  }

  function charCount(text) {
    return Array.from(String(text === undefined || text === null ? '' : text)).length;
  }

  function avatarNode(item, size) {
    if (!item || item.isAnonymous) {
      return C.avatarEl({ id: 0, name: '匿名同学' }, size || 40);
    }
    return C.avatarEl({ id: item.authorId, name: item.authorName, avatar: item.authorAvatar, gender:item.authorGender }, size || 40);
  }

  function button(className, text, onClick) {
    var node = el('button', className, text);
    node.type = 'button';
    if (onClick) node.addEventListener('click', onClick);
    return node;
  }

  function errorMessage(response, fallback) {
    if (response && response.data && response.data.error) return response.data.error;
    if (response && response.status === 401) return '请先登录';
    return fallback || '加载失败，请稍后重试';
  }

  // ── 页面骨架 ──
  function render(container) {
    root = container || document.getElementById('communityBox');
    if (!root) return;
    root.classList.add('cm-root', 'cm-plaza');

    C.clear(root);

    var layout = el('div', 'cm-plaza-layout');
    var main = el('div', 'cm-plaza-main');
    root.appendChild(layout);
    layout.appendChild(main);

    var daily=el('div','cm-daily-compose');main.appendChild(daily);
    refs.composeSlot = el('div', 'cm-compose-slot');
    daily.appendChild(refs.composeSlot);
    renderComposer();
    var feedHead=el('div','cm-feed-heading');main.appendChild(feedHead);
    feedHead.appendChild(buildHead());

    refs.tagbar = el('div', 'cm-tagbar');
    feedHead.appendChild(refs.tagbar);
    renderTagbar();
    feedHead.appendChild(daily);
    root.insertBefore(feedHead,layout);

    refs.feed = el('div', 'cm-feed');
    refs.errorBox = el('div', 'cm-feed-error');
    refs.errorBox.hidden = true;
    refs.loadingBox = el('div', 'cm-feed-loading');
    refs.loadingBox.hidden = true;
    refs.emptyBox = el('div', 'cm-feed-empty');
    refs.emptyBox.hidden = true;
    refs.list = el('div', 'cm-post-list');
    refs.more = button('cm-feed-more', '加载更多');
    refs.more.hidden = true;
    refs.more.addEventListener('click', function () {
      if (state.loading) return;
      loadFeed(state.page + 1, true);
    });
    refs.feed.appendChild(refs.errorBox);
    refs.feed.appendChild(refs.loadingBox);
    refs.feed.appendChild(refs.emptyBox);
    refs.feed.appendChild(refs.list);
    refs.feed.appendChild(refs.more);
    main.appendChild(refs.feed);
    layout.appendChild(buildSide());

    loadFeed(1, false);
  }

  function compose(options) {
    if (!C.requireLogin('分享')) return;
    openComposer(options || {});
    if (refs.composeSlot) refs.composeSlot.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function buildPeers(){
    var card=el('section','cm-side-card cm-recommend-card cm-peer-summary');card.appendChild(el('span','cm-eyebrow','Mate'));
    var list=el('div','cm-peer-list');card.appendChild(list);
    if(!C.signedIn()){list.appendChild(el('p','cm-side-text','登录后发现一起备考的同学。'));return card;}
    C.request(API+'/partners?limit=3').then(function(r){if(!card.isConnected)return;if(!r.ok){list.appendChild(el('p','cm-side-text','同路人暂时未能加载'));return;}
      var rows=(r.data.rows||[]).slice(0,3);if(!rows.length)list.appendChild(el('p','cm-side-text','完善备考资料，发现更多同路人。'));
      rows.forEach(function(person){var row=el('div','cm-peer-row');row.appendChild(C.avatarEl(person,36));var copy=el('div','cm-peer-copy');copy.appendChild(el('strong','',person.name||'同学'));copy.appendChild(el('small','',[person.provinceName,person.examYear,person.targetMajor].filter(Boolean).join(' · ')));row.appendChild(copy);var follow=button('cm-peer-follow',person.followingHim?'已关注':'关注',async function(){follow.disabled=true;var response=await C.request(API+'/follow/'+person.id,{method:'POST'});follow.disabled=false;if(!response.ok){C.toast((response.data&&response.data.error)||'操作失败');return;}follow.textContent=response.data.following?'已关注':'关注';});row.appendChild(follow);list.appendChild(row);});
    });return card;
  }

  function buildQuestions(kind){
    var trending=kind==='hot',limit=trending?10:3;
    var card=el('section','cm-side-card cm-recommend-card cm-question-summary'+(trending?' cm-trending-summary':''));
    card.appendChild(el('span','cm-eyebrow',trending?'Trending':'Q&A'));
    var list=el('div','cm-question-list');list.setAttribute('aria-live','polite');list.appendChild(el('p','cm-side-text',trending?'正在加载热门内容…':'正在加载推荐问答…'));card.appendChild(list);
    async function showQuestion(id){
      var result=await C.request(API+'/posts/'+encodeURIComponent(id));
      if(!card.isConnected)return;
      if(!result.ok||!result.data.post){C.toast(trending?'内容暂时无法查看，请稍后重试':'问题暂时无法查看，请稍后重试');return;}
      state.seq++;state.loading=false;hideStates();refs.more.hidden=true;C.clear(refs.list);
      var postCard=createPostCard(result.data.post);refs.list.appendChild(postCard);
      var comments=postCard.querySelector('.cm-comment-toggle');if(comments&&!trending)comments.click();
      postCard.scrollIntoView({behavior:'smooth',block:'start'});
    }
    C.request(API+'/feed?tab='+(trending?'hot':'recommend')+(trending?'':'&tag='+encodeURIComponent('问答'))+'&page=1&pageSize='+limit).then(function(result){
      if(!card.isConnected)return;C.clear(list);
      if(!result.ok){list.appendChild(el('p','cm-side-text',trending?'热门内容暂时未能加载':'问答暂时未能加载'));return;}
      var questions=(result.data.posts||[]).slice(0,limit);
      if(!questions.length){list.appendChild(el('p','cm-side-text',trending?'暂无热门内容':'暂无推荐问答'));return;}
      questions.forEach(function(post,index){
        var row=button('cm-question-row',null,function(){showQuestion(post.id);});
        row.appendChild(el('span','cm-question-rank',String(index+1)));
        var copy=el('span','cm-question-copy');
        var title=String(post.body||'').trim().split(/\r?\n/)[0].replace(/^想请教[：:]\s*/, '');
        copy.appendChild(el('strong','cm-question-title',title||(trending?'备考分享':'备考问题')));
        if(!trending)copy.appendChild(el('small','cm-question-meta',C.fmtCount(post.commentCount||0)+' 个回答 · 我来回答 →'));
        row.appendChild(copy);list.appendChild(row);
      });
    });return card;
  }

  function buildSide() {
    var side = el('aside', 'cm-plaza-side');
    side.setAttribute('aria-label', '社区灵感与指南');
    side.appendChild(buildPeers());
    side.appendChild(buildQuestions());
    return side;
  }

  function buildHead() {
    var head = el('div', 'cm-plaza-head');
    var pills = el('div', 'cm-flow-pills');
    FLOWS.forEach(function (flow) {
      var active = state.tab === flow.key;
      var pill = button('cm-flow-pill' + (active ? ' active' : ''), flow.label, function () {
        selectFlow(flow.key);
      });
      pill.dataset.flow = flow.key;
      pill.setAttribute('aria-pressed', String(active));
      pills.appendChild(pill);
    });
    head.appendChild(pills);
    var publish = button('cm-publish-entry', '＋ 发布', function () {
      if (!C.requireLogin('发布')) return;
      openComposer();
    });
    head.appendChild(publish);
    return head;
  }

  function selectFlow(key) {
    if (state.tab === key) return;
    if ((key === 'following' || key === 'peer') && !C.signedIn()) {
      C.requireLogin('查看关注');
    }
    state.tab = key;
    state.page = 1;
    renderTagbar();
    var pills = root.querySelectorAll('.cm-flow-pill');
    Array.prototype.forEach.call(pills, function (pill) {
      pill.classList.toggle('active', pill.dataset.flow === key);
      pill.setAttribute('aria-pressed', String(pill.dataset.flow === key));
    });
    loadFeed(1, false);
  }

  // ── 发布区 ──
  function renderComposer() {
    openComposer = function () { C.requireLogin('分享'); };
    refs.updateTagChoices = null;
    var slot = refs.composeSlot;
    if (!slot) return;
    C.clear(slot);
    if (!C.signedIn()) {
      var guest = el('div', 'cm-compose-guest');
      guest.appendChild(el('span', 'cm-compose-guest-text', '登录后可以发布帖子、瞬间或匿名树洞'));
      guest.appendChild(button('cm-compose-login', '登录 / 注册', function () {
        C.requireLogin('登录');
      }));
      slot.appendChild(guest);
      return;
    }

    var viewer = C.viewer();
    var launch=el('div','cm-composer-launch');
    var composeSymbol=button('cm-compose-symbol cz-icon-action',null,function(){openComposer();});
    composeSymbol.setAttribute('aria-label','写想法');composeSymbol.setAttribute('aria-haspopup','dialog');composeSymbol.title='写想法';
    composeSymbol.innerHTML='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.2 3.8a5.2 5.2 0 0 1 0 7.4L11.4 20H4v-7.4l8.8-8.8a5.2 5.2 0 0 1 7.4 0ZM2 22 16 8M15 5l4 4M9 13h6"/></svg>';
    launch.appendChild(composeSymbol);slot.appendChild(launch);

    var card = el('dialog', 'cm-compose-card cm-editor-dialog');
    card.setAttribute('aria-label','发表动态');
    card.setAttribute('data-dialog-layout','custom');
    var editorHead=el('div','cm-editor-head');
    var closeEditor=button('cm-editor-close','×',function(){if(!busy)card.close();});closeEditor.setAttribute('aria-label','关闭编辑器');editorHead.appendChild(closeEditor);card.appendChild(editorHead);
    var textarea = el('textarea', 'cm-compose-textarea');
    textarea.setAttribute('aria-label', '分享内容');
    textarea.rows = 6;
    textarea.maxLength = 500;
    textarea.placeholder = '记录一句进度，或一件小开心…';
    var counter = el('span', 'cm-compose-count', '0/500');
    textarea.addEventListener('input', function () {
      setText(counter, charCount(textarea.value) + '/500');
    });

    var selected = [];
    var tagBox = el('div', 'cm-compose-tags'),topicsOpen=false;
    function renderTagChoices() {
      C.clear(tagBox);
      var addTopic=button('cm-topic-add','＋话题',function(){topicsOpen=!topicsOpen;renderTagChoices();});addTopic.setAttribute('aria-expanded',String(topicsOpen));tagBox.appendChild(addTopic);
      selected.forEach(function(tag){tagBox.appendChild(button('cm-tag-choice active', '# '+topicLabel(tag)+' ×',function(){selected.splice(selected.indexOf(tag),1);renderTagChoices();}));});
      if(topicsOpen){var picker=el('div','cm-topic-picker');state.tags.forEach(function(tag){var chip=button('cm-tag-choice'+(selected.indexOf(tag)>=0?' active':''),topicLabel(tag),function(){var at=selected.indexOf(tag);if(at<0){if(selected.length>=3)return C.toast('最多选择 3 个标签');selected.push(tag);}else selected.splice(at,1);topicsOpen=false;renderTagChoices();});chip.setAttribute('aria-pressed',String(selected.indexOf(tag)>=0));picker.appendChild(chip);});tagBox.appendChild(picker);}
    }
    refs.updateTagChoices = renderTagChoices;
    renderTagChoices();

    var anonLabel = el('label', 'cm-anon-toggle');
    var anonInput = document.createElement('input');
    anonInput.type = 'checkbox';
    anonInput.className = 'cm-anon-input';
    anonLabel.appendChild(anonInput);
    anonLabel.appendChild(el('span', 'cm-anon-text', '匿名'));

    var postBtn = button('cm-publish-post', '发布', function () { submit(); });

    var busy = false;

    function submit() {
      if (busy) return;
      if(photoEditor&&photoEditor.pending())return C.toast('照片正在处理，请稍候');
      var body = textarea.value.trim();
      var length = charCount(body);
      if (length < 5) return C.toast('内容至少 5 个字');
      if (charCount(body) > 500) return C.toast('内容最多 500 个字');
      busy = true;
      postBtn.disabled = true;
      var payload = { body: body, tags: selected.slice(), kind: 'post', anonymous: !!anonInput.checked };
      var files=photoEditor?photoEditor.files():[],request;
      if(files.length){var form=new FormData();form.append('body',payload.body);form.append('tags',JSON.stringify(payload.tags));form.append('kind','post');form.append('anonymous',String(payload.anonymous));files.forEach(function(file){form.append('photos',file,file.name);});request=fetch(API+'/posts',{method:'POST',credentials:'same-origin',body:form}).then(async function(r){return {ok:r.ok,status:r.status,data:await r.json()};});}
      else request=C.request(API + '/posts', { method: 'POST', body: payload });
      if(photoEditor)photoEditor.refresh();
      request.then(function (response) {
        if (!response.ok) {
          C.toast(errorMessage(response, '发布失败，请稍后重试'));
          return;
        }
        textarea.value = '';
        if(photoEditor)photoEditor.clear();
        setText(counter, '0/500');
        selected = [];
        renderTagChoices();
        anonInput.checked = false;
        card.close();
        C.toast('发布成功');
        loadFeed(1, false);
      }).catch(function(){C.toast('发布未完成，请检查网络后重试');}).finally(function () {
        busy = false;
        if(photoEditor)photoEditor.refresh();
        postBtn.disabled = false;
      });
    }

    tagBox.classList.add('cm-editor-topics');card.appendChild(tagBox);
    card.appendChild(textarea);
    var photoSlot=el('div','cm-photo-editor');
    var photoEditor=window.CZCommunityPhotos?window.CZCommunityPhotos.create(photoSlot,function(){return busy;}):null;
    var previews=photoSlot.querySelector('.cm-photo-previews');if(previews)card.appendChild(previews);
    var footer=el('div','cm-editor-footer');footer.appendChild(anonLabel);footer.appendChild(photoSlot);footer.appendChild(counter);footer.appendChild(postBtn);card.appendChild(footer);
    card.addEventListener('cancel',function(e){if(busy)e.preventDefault();});
    slot.appendChild(card);

    openComposer = function (options) {
      options = options || {};
      // 话题入口不覆盖用户已经输入的草稿。
      if (options.text && !textarea.value.trim()) textarea.value = options.text;
      if (options.tag && state.tags.indexOf(options.tag) >= 0 && selected.indexOf(options.tag) < 0 && selected.length < 3) {
        selected.push(options.tag);
        renderTagChoices();
      }
      if (options.anonymous) anonInput.checked = true;
      setText(counter, charCount(textarea.value) + '/500');
      textarea.placeholder='分享今天的想法…';
      if(!card.open)card.showModal();
      textarea.focus();
    };


  }

  // ── 标签筛选 ──
  function renderTagbar() {
    var bar = refs.tagbar;
    if (!bar) return;
    C.clear(bar);
    bar.hidden=state.tab==='qa'||!state.tag;
    if(state.tag&&state.tab!=='qa'){
      var selectedTopic=button('cm-tag-pill active','# '+topicLabel(state.tag)+' ×',function(){selectTag('');});
      selectedTopic.setAttribute('aria-label','取消话题筛选：'+topicLabel(state.tag));bar.appendChild(selectedTopic);
    }
  }

  function selectTag(tag) {
    if (state.tag === tag) return;
    state.tag = tag;
    state.page = 1;
    renderTagbar();
    loadFeed(1, false);
  }

  // ── 信息流 ──
  function showLoading() {
    C.clear(refs.loadingBox);
    refs.loadingBox.appendChild(C.loadingEl('社区加载中…'));
    refs.loadingBox.hidden = false;
  }

  function hideStates() {
    refs.errorBox.hidden = true;
    refs.loadingBox.hidden = true;
    refs.emptyBox.hidden = true;
  }

  function showError(message) {
    C.clear(refs.errorBox);
    refs.errorBox.appendChild(el('span', 'cm-feed-error-text', message));
    refs.errorBox.appendChild(button('cm-feed-retry', '重试', function () {
      loadFeed(state.page || 1, false);
    }));
    refs.errorBox.hidden = false;
  }

  function showLoginGate(message) {
    C.clear(refs.emptyBox);
    refs.emptyBox.appendChild(el('p', 'cm-feed-empty-text', message));
    refs.emptyBox.appendChild(button('cm-feed-login', '去登录', function () {
      C.requireLogin('登录');
    }));
    refs.emptyBox.hidden = false;
  }

  function showEmpty() {
    C.clear(refs.emptyBox);
    refs.emptyBox.appendChild(el('p', 'cm-empty-title', '暂无动态'));
    refs.emptyBox.hidden = false;
  }

  function loadFeed(page, append) {
    if (append && state.loading) return;
    if (state.tab === 'following' && !C.signedIn()) {
      state.seq += 1; // 让仍在路上的请求失效，避免覆盖登录引导
      state.loading = false;
      C.clear(refs.list);
      C.clear(refs.loadingBox);
      refs.loadingBox.hidden = true;
      refs.emptyBox.hidden = true;
      refs.more.hidden = true;
      showLoginGate('登录后查看你关注的人的最新动态');
      return;
    }
    state.loading = true;
    var seq = (state.seq += 1);
    hideStates();
    refs.more.hidden = true;
    if (!append) {
      C.clear(refs.list);
      showLoading();
    }
    var url = API + '/feed?tab=' + encodeURIComponent(state.tab==='qa'?'recommend':state.tab) + '&page=' + page + '&pageSize=' + PAGE_SIZE;
    var feedTag=state.tab==='qa'?'问答':state.tag;
    if (feedTag) url += '&tag=' + encodeURIComponent(feedTag);
    C.request(url).then(function (response) {
      if (seq !== state.seq) return;
      refs.loadingBox.hidden = true;
      if (!response.ok) {
        if (response.status === 401) showLoginGate('请先登录后再查看');
        else showError(errorMessage(response));
        return;
      }
      var data = response.data || {};
      state.page = Number(data.page) || page;
      state.total = Number(data.total) || 0;
      if (Array.isArray(data.tags) && data.tags.length && data.tags.join('|') !== state.tags.join('|')) {
        state.tags = data.tags.slice().sort(function(a,b){return FALLBACK_TAGS.indexOf(a)-FALLBACK_TAGS.indexOf(b);});
        renderTagbar();
        // 标签更新不重建发布器，保留正在输入的草稿。
        if (refs.updateTagChoices) refs.updateTagChoices();
      }
      (data.posts || []).forEach(function (post) {
        refs.list.appendChild(createPostCard(post));
      });
      if (!refs.list.firstChild) showEmpty(EMPTY_TEXT[state.tab] || '暂无内容');
      refs.more.hidden = state.page * PAGE_SIZE >= state.total;
    }).catch(function () {
      if (seq !== state.seq) return;
      refs.loadingBox.hidden = true;
      showError('网络异常，请稍后重试');
    }).finally(function () {
      if (seq === state.seq) state.loading = false;
    });
  }

  // ── 帖子卡 ──
  function createPostCard(post) {
    var card = el('article', 'cm-post');
    card.dataset.id = String(post.id);

    var head = el('div', 'cm-post-head');
    head.appendChild(avatarNode(post, 40));
    var meta = el('div', 'cm-post-meta');
    var nameRow = el('div', 'cm-post-name-row');
    nameRow.appendChild(el('span', 'cm-post-author', post.authorName));
    if (!post.isAnonymous) {var context=[post.authorProvince,post.authorExamYear].filter(Boolean).join(' · ');if(context)nameRow.appendChild(el('span','cm-post-context',context));}
    if (post.isAnonymous) nameRow.appendChild(el('span', 'cm-kind cm-kind-anon', '匿名'));
    if (post.kind === 'moment') nameRow.appendChild(el('span', 'cm-kind cm-kind-moment', '瞬间 24h'));
    if (post.kind === 'checkin') nameRow.appendChild(el('span', 'cm-kind cm-kind-checkin', '打卡'));
    meta.appendChild(nameRow);
    head.appendChild(meta);
    head.appendChild(el('time', 'cm-post-time', C.timeAgo(post.createdAt)));
    card.appendChild(head);

    card.appendChild(el('div', 'cm-post-body', post.body));
    if(Array.isArray(post.photos)&&post.photos.length){var gallery=el('div','cm-post-photos');post.photos.slice(0,3).forEach(function(url,index){if(!/^\/public\/images\/community\/[a-f0-9]{40}\.(jpg|png|webp)$/.test(url))return;var link=el('a','cm-post-photo'),image=document.createElement('img');link.href=url;link.target='_blank';link.rel='noopener noreferrer';link.setAttribute('aria-label','查看第'+(index+1)+'张照片');image.src=url;image.alt='动态照片 '+(index+1);image.loading='lazy';link.appendChild(image);gallery.appendChild(link);});card.appendChild(gallery);}


    if (Array.isArray(post.tags) && post.tags.length) {
      var tagRow = el('div', 'cm-post-tags');
      post.tags.forEach(function (tag) {
        tagRow.appendChild(button('cm-post-tag', '# ' + topicLabel(tag), function () { selectTag(tag); }));
      });
      card.appendChild(tagRow);
    }

    var actions = el('div', 'cm-post-actions');
    var likeBtn = button('cm-action cm-like' + (post.liked ? ' active' : ''));
    var favBtn = button('cm-action cm-favorite' + (post.favorited ? ' active' : ''));
    var commentBtn = button('cm-action cm-comment-toggle');
    actions.appendChild(likeBtn);
    actions.appendChild(favBtn);
    actions.appendChild(commentBtn);
    card.appendChild(actions);

    function actionIcon(node, kind, label, count) {
      var paths={like:'M12 21C8.7 18.9 2 14.4 2 8.7 2 5.6 4.3 3.5 7.1 3.5c2.2 0 3.9 1.2 4.9 2.8 1-1.6 2.7-2.8 4.9-2.8 2.8 0 5.1 2.1 5.1 5.2 0 5.7-6.7 10.2-10 12.3Z',comment:'M12 3C6.7 3 3 6.5 3 11c0 4.6 3.7 8 8.3 8H13v3l5.4-4.3C20.1 16.3 21 14 21 11c0-4.5-3.7-8-9-8Z',favorite:'M5 3.5A1.5 1.5 0 0 1 6.5 2h11A1.5 1.5 0 0 1 19 3.5V22l-7-4.5L5 22V3.5Z'};
      node.classList.add('cm-post-icon');
      node.title=label+' '+C.fmtCount(count||0);node.setAttribute('aria-label',node.title);
      node.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'+paths[kind]+'"/></svg>';
      node.appendChild(el('span','cm-post-action-count',C.fmtCount(count||0)));
    }
    function setLike(liked, count) {
      likeBtn.classList.toggle('active', !!liked);
      likeBtn.setAttribute('aria-pressed', String(!!liked));
      actionIcon(likeBtn,'like',liked?'取消点赞':'点赞',count);
    }
    function setFavorite(favorited, count) {
      favBtn.classList.toggle('active', !!favorited);
      favBtn.setAttribute('aria-pressed', String(!!favorited));
      actionIcon(favBtn,'favorite',favorited?'取消收藏':'收藏',count);
    }
    function setCommentCount(count) {
      actionIcon(commentBtn,'comment','评论',count);
    }
    setLike(post.liked, post.likeCount);
    setCommentCount(post.commentCount);
    setFavorite(post.favorited, post.favoriteCount);

    var commentsBox = el('div', 'cm-comments');
    commentsBox.hidden = true;
    card.appendChild(commentsBox);

    var reportBox = el('div', 'cm-report');
    reportBox.hidden = true;
    card.appendChild(reportBox);

    likeBtn.addEventListener('click', function () {
      if (!C.requireLogin('点赞')) return;
      if (likeBtn.dataset.busy === '1') return;
      likeBtn.dataset.busy = '1';
      C.request(API + '/posts/' + post.id + '/like', { method: 'POST' }).then(function (response) {
        if (!response.ok) {
          C.toast(errorMessage(response, '点赞失败，请稍后重试'));
          return;
        }
        setLike(response.data.liked, response.data.likeCount);
      }).finally(function () {
        delete likeBtn.dataset.busy;
      });
    });

    favBtn.addEventListener('click', function () {
      if (!C.requireLogin('收藏')) return;
      if (favBtn.dataset.busy === '1') return;
      favBtn.dataset.busy = '1';
      C.request(API + '/posts/' + post.id + '/favorite', { method: 'POST' }).then(function (response) {
        if (!response.ok) {
          C.toast(errorMessage(response, '收藏失败，请稍后重试'));
          return;
        }
        setFavorite(response.data.favorited, response.data.favoriteCount);
      }).finally(function () {
        delete favBtn.dataset.busy;
      });
    });

    commentBtn.addEventListener('click', function () {
      var open = commentsBox.hidden;
      commentsBox.hidden = !open;
      if (open) loadComments(post, commentsBox, setCommentCount);
    });

    return card;
  }

  // ── 评论（楼中楼） ──
  async function loadComments(post, box, onCountChange) {
    var ctx = box.__cmCtx;
    if (!ctx) {
      ctx = { post: post, box: box, target: null, allReplies: false, onCountChange: onCountChange };
      box.__cmCtx = ctx;
    }
    if (ctx.loading) return;
    ctx.loading = true;
    C.clear(box);
    box.appendChild(C.loadingEl('评论加载中…'));
    var url = API + '/posts/' + post.id + '/comments?page=1&pageSize=20' + (ctx.allReplies ? '&replies=all' : '')+(box.dataset.focusId?'&focus='+encodeURIComponent(box.dataset.focusId):'');
    var response = await C.request(url);
    ctx.loading = false;
    C.clear(box);
    if (!response.ok) {
      box.appendChild(el('div', 'cm-comment-status', errorMessage(response, '评论加载失败，请稍后重试')));
      box.appendChild(button('cm-comment-retry', '重试', function () {
        loadComments(post, box, onCountChange);
      }));
      return;
    }
    var rows = (response.data && response.data.rows) || [];
    var list = el('div', 'cm-comment-list');
    if (!rows.length) list.appendChild(el('div', 'cm-comments-empty', '还没有评论，来抢沙发'));
    rows.forEach(function (comment) {
      list.appendChild(createCommentItem(ctx, comment));
    });
    box.appendChild(list);
    if(box.dataset.focusId){var focused=list.querySelector('[data-comment-id="'+Number(box.dataset.focusId)+'"]');if(focused){focused.classList.add('cm-comment-focused');focused.scrollIntoView({behavior:'smooth',block:'center'});}}
    if (C.signedIn()) {
      box.appendChild(buildCommentForm(ctx));
    } else {
      var hint = el('div', 'cm-comment-login');
      hint.appendChild(el('span', 'cm-comment-login-text', '登录后可参与评论'));
      hint.appendChild(button('cm-comment-login-btn', '去登录', function () {
        C.requireLogin('评论');
      }));
      box.appendChild(hint);
    }
  }

  function replyTargetText(comment) {
    return '回复 @' + (comment.isAnonymous ? '匿名同学' : comment.authorName);
  }

  function commentIdentity(comment, className) {
    var copy=el('span','cm-comment-identity');
    copy.appendChild(el('span',className,comment.isAnonymous?'匿名同学':comment.authorName));
    if(!comment.isAnonymous){var context=[comment.authorProvince,comment.authorExamYear].filter(Boolean).join(' · ');if(context)copy.appendChild(el('small','cm-comment-context',context));}
    return copy;
  }

  function createCommentItem(ctx, comment) {
    var item = el('div', 'cm-comment');
    item.dataset.commentId=String(comment.id);
    var head = el('div', 'cm-comment-head');
    head.appendChild(avatarNode(comment,28));
    head.appendChild(commentIdentity(comment,'cm-comment-author'));
    head.appendChild(el('span', 'cm-comment-time', C.timeAgo(comment.createdAt)));
    if (comment.isMine) {
      head.appendChild(button('cm-comment-delete', '删除', function () {
        deleteComment(ctx, comment);
      }));
    }
    item.appendChild(head);
    item.appendChild(el('div', 'cm-comment-body', comment.body));

    var actions = el('div', 'cm-comment-actions');
    if (C.signedIn()) {
      actions.appendChild(button('cm-comment-reply', '回复', function () {
        ctx.target = comment;
        var hint = ctx.box.querySelector('.cm-reply-hint');
        if (hint) {
          hint.hidden = false;
          setText(hint.querySelector('.cm-reply-hint-text'), replyTargetText(comment));
          var input = ctx.box.querySelector('.cm-comment-input');
          if (input) input.focus();
        }
      }));
    }
    head.appendChild(actions);

    var replies = Array.isArray(comment.replies) ? comment.replies : [];
    if (replies.length || comment.replyCount > 0) {
      var replyList = el('div', 'cm-reply-list');
      replies.forEach(function (reply) {
        replyList.appendChild(createReplyItem(ctx, reply));
      });
      item.appendChild(replyList);
      if (comment.replyCount > replies.length) {
        item.appendChild(button('cm-reply-expand', '展开全部 ' + comment.replyCount + ' 条回复', function () {
          ctx.allReplies = true;
          loadComments(ctx.post, ctx.box, ctx.onCountChange);
        }));
      }
    }
    return item;
  }

  function createReplyItem(ctx, reply) {
    var item = el('div', 'cm-reply');
    item.dataset.commentId=String(reply.id);
    var head = el('div', 'cm-reply-head');
    head.appendChild(avatarNode(reply,24));
    head.appendChild(commentIdentity(reply,'cm-reply-author'));
    head.appendChild(el('span', 'cm-comment-time', C.timeAgo(reply.createdAt)));
    if (reply.isMine) {
      head.appendChild(button('cm-comment-delete', '删除', function () {
        deleteComment(ctx, reply);
      }));
    }
    item.appendChild(head);
    item.appendChild(el('div', 'cm-reply-body', reply.body));
    return item;
  }

  function buildCommentForm(ctx) {
    var form = el('div', 'cm-comment-form');
    var hint = el('div', 'cm-reply-hint');
    hint.hidden = true;
    hint.appendChild(el('span', 'cm-reply-hint-text', ''));
    hint.appendChild(button('cm-reply-cancel', '取消', function () {
      ctx.target = null;
      hint.hidden = true;
    }));
    var input = el('textarea', 'cm-comment-input');
    input.rows = 2;
    input.maxLength = 200;
    input.placeholder = '写下你的评论…（1–200 字）';
    var send = button('cm-comment-send', '发送', function () {
      if (send.dataset.busy === '1') return;
      var body = input.value.trim();
      var length = charCount(body);
      if (!length) return C.toast('请输入评论内容');
      if (length > 200) return C.toast('评论最多 200 个字');
      if (!ctx.target && !C.requireLogin('评论')) return;
      send.dataset.busy = '1';
      send.disabled = true;
      var payload = { body: body };
      if (ctx.target) payload.parentId = ctx.target.id;
      C.request(API + '/posts/' + ctx.post.id + '/comments', { method: 'POST', body: payload }).then(function (response) {
        if (!response.ok) {
          C.toast(errorMessage(response, '评论失败，请稍后重试'));
          return;
        }
        input.value = '';
        ctx.target = null;
        hint.hidden = true;
        if (typeof response.data.commentCount === 'number' && ctx.onCountChange) {
          ctx.onCountChange(response.data.commentCount);
        }
        loadComments(ctx.post, ctx.box, ctx.onCountChange);
      }).finally(function () {
        delete send.dataset.busy;
        send.disabled = false;
      });
    });
    form.appendChild(hint);
    var row = el('div', 'cm-comment-form-row');
    row.appendChild(input);
    row.appendChild(send);
    form.appendChild(row);
    return form;
  }

  function deleteComment(ctx, comment) {
    if (!window.confirm('确定删除这条评论？')) return;
    C.request(API + '/comments/' + comment.id, { method: 'DELETE' }).then(function (response) {
      if (!response.ok) {
        C.toast(errorMessage(response, '删除失败，请稍后重试'));
        return;
      }
      if (typeof response.data.commentCount === 'number' && ctx.onCountChange) {
        ctx.onCountChange(response.data.commentCount);
      }
      C.toast('已删除');
      loadComments(ctx.post, ctx.box, ctx.onCountChange);
    });
  }

  // ── 举报 ──
  function buildReportPanel(box, postId) {
    C.clear(box);
    var panel = el('div', 'cm-report-panel');
    panel.appendChild(el('div', 'cm-report-title', '选择举报原因'));
    var reasons = el('div', 'cm-report-reasons');
    REASONS.forEach(function (reason) {
      reasons.appendChild(button('cm-report-reason', reason, function () {
        if (panel.dataset.busy === '1') return;
        panel.dataset.busy = '1';
        C.request(API + '/reports', {
          method: 'POST',
          body: { targetType: 'post', targetId: postId, reason: reason }
        }).then(function (response) {
          if (!response.ok) {
            C.toast(errorMessage(response, '举报提交失败，请稍后重试'));
            delete panel.dataset.busy;
            return;
          }
          C.clear(box);
          box.appendChild(el('div', 'cm-report-done', '已提交，运营会尽快处理'));
        });
      }));
    });
    panel.appendChild(reasons);
    panel.appendChild(button('cm-report-cancel', '取消', function () {
      box.hidden = true;
    }));
    box.appendChild(panel);
  }

  // ── 注册到页签壳 / 导出 ──
  function refresh() {
    if (!root) return;
    render(root);
  }

  async function openPost(id,commentId){
    if(!/^[1-9]\d*$/.test(String(id)))return;
    window.CZCommunityShell.show('plaza');
    var seq=++state.seq;state.loading=false;hideStates();refs.more.hidden=true;C.clear(refs.list);showLoading();
    var result=await C.request(API+'/posts/'+encodeURIComponent(id));
    if(seq!==state.seq)return;refs.loadingBox.hidden=true;
    if(!result.ok||!result.data.post){showError('这条动态已不可查看');return;}
    var card=createPostCard(result.data.post);refs.list.appendChild(card);card.scrollIntoView({behavior:'smooth',block:'start'});
    if(commentId){var comments=card.querySelector('.cm-comments');comments.dataset.focusId=String(Number(commentId));card.querySelector('.cm-comment-toggle').click();}
  }
  window.CommunityStudio = { refresh: refresh,openPost:openPost };

  // defer 脚本按顺序执行：页签壳可能已在本脚本注册前 boot（此时 current() 仍为 null），
  // 需要在注册后按 hash/默认页签补渲染广场，避免首屏空白。
  function tryInitialRender() {
    var shell = window.CZCommunityShell;
    var box = document.getElementById('communityBox');
    if (!box) return;
    var current = shell && typeof shell.current === 'function' ? shell.current() : null;
    if (current && current !== 'plaza') return;
    if (current === 'plaza') {
      if (root !== box) render(box);
      return;
    }
    var hash = String(window.location.hash || '').replace('#community-', '');
    if (hash !== '' && hash !== 'plaza') return;
    // 走壳的 show()，让 current() 与页签高亮状态一致（而不是绕过壳直接 render）。
    if (shell && typeof shell.show === 'function') shell.show('plaza');
    else render(box);
  }

  if (window.CZCommunityShell && typeof window.CZCommunityShell.register === 'function') {
    window.CZCommunityShell.register('plaza', { render: render, refresh: refresh, deactivate: function () { state.seq += 1; state.loading = false; } });
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', tryInitialRender);
    } else {
      tryInitialRender();
    }
  } else if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      render(document.getElementById('communityBox'));
    });
  } else {
    render(document.getElementById('communityBox'));
  }
})();
