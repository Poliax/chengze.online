/* Private community history and profile editor. */
(function(){'use strict';
var C=window.CZCommunity,Shell=window.CZCommunityShell;if(!C||!Shell)return;
var API='/api/community',lastBox=null,renderSequence=0,activitySequence=0,section='posts';
var STUDY_TAGS=['英语','高数','语文','计算机','政治','管理学','教育学','医学','会计','经济学','法学','艺术','体育'];
function el(tag,cls,text){return C.el(tag,cls,text);}
function button(label,cls,run){var e=el('button','cm-me-btn '+(cls||''),label);e.type='button';if(run)e.addEventListener('click',run);return e;}
  function renderEditForm(profile) {
    var form = el('div', 'cm-me-card cm-me-edit');
    form.id = 'cmMeEdit';
    form.hidden = true;
    form.appendChild(el('h3', 'cm-me-section-title', '编辑资料'));
    form.appendChild(el('p', 'cm-me-edit-hint', '资料会展示在个人资料与 mate里，请勿填写联系方式。'));

    function field(labelText, value, maxLength, multiline) {
      var wrap = el('label', 'cm-me-field');
      wrap.appendChild(el('span', 'cm-me-field-label', labelText));
      var input = document.createElement(multiline ? 'textarea' : 'input');
      if (!multiline) input.type = 'text';
      input.className = 'cm-me-input';
      input.maxLength = maxLength;
      input.value = value || '';
      wrap.appendChild(input);
      return { wrap: wrap, input: input };
    }

    var nickname = field('昵称（1–20 字）', profile.name, 20, false);
    var school = field('目标院校（≤40 字）', profile.targetSchool, 40, false);
    var major = field('目标专业（≤40 字）', profile.targetMajor, 40, false);
    var bio = field('学习宣言（≤100 字）', profile.bio, 100, true);
    form.appendChild(nickname.wrap);
    form.appendChild(school.wrap);
    form.appendChild(major.wrap);
    form.appendChild(bio.wrap);

    var tagWrap = el('div', 'cm-me-field');
    tagWrap.appendChild(el('span', 'cm-me-field-label', '学习标签（最多 5 个）'));
    var tagBox = el('div', 'cm-me-tag-choices');
    var selected = (profile.studyTags || []).slice(0, 5);
    var tagNodes = [];
    for (var i = 0; i < STUDY_TAGS.length; i += 1) {
      (function (tag) {
        var choice = button(tag, 'cm-me-tag-choice', null);
        if (selected.indexOf(tag) >= 0) choice.classList.add('is-active');
        choice.addEventListener('click', function () {
          var at = selected.indexOf(tag);
          if (at >= 0) {
            selected.splice(at, 1);
            choice.classList.remove('is-active');
            return;
          }
          if (selected.length >= 5) {
            C.toast('最多选择 5 个学习标签');
            return;
          }
          selected.push(tag);
          choice.classList.add('is-active');
        });
        tagNodes.push(choice);
        tagBox.appendChild(choice);
      })(STUDY_TAGS[i]);
    }
    tagWrap.appendChild(tagBox);
    form.appendChild(tagWrap);

    var counter = el('span', 'cm-me-counter', (bio.input.value || '').length + '/100');
    bio.wrap.appendChild(counter);
    bio.input.addEventListener('input', function () {
      counter.textContent = Array.from(bio.input.value || '').length + '/100';
    });

    var actions = el('div', 'cm-me-edit-actions');
    var saving = false;
    var saveBtn = button('保存', 'cm-me-btn-primary', async function () {
      if (saving) return;
      var nicknameValue = String(nickname.input.value || '').trim();
      if (!nicknameValue) {
        C.toast('昵称不能为空');
        return;
      }
      saving = true;
      saveBtn.disabled = true;
      var payload = {
        nickname: nicknameValue,
        targetSchool: String(school.input.value || '').trim(),
        targetMajor: String(major.input.value || '').trim(),
        bio: String(bio.input.value || '').trim(),
        studyTags: selected.slice()
      };
      var response = await C.request(API + '/me/profile', { method: 'PATCH', body: payload });
      if (!response.ok) {
        saving = false;
        saveBtn.disabled = false;
        C.toast((response.data && response.data.error) || '保存失败，请稍后再试');
        return;
      }
      C.toast('资料已更新');
      renderPage(lastBox);
    });
    actions.appendChild(saveBtn);
    actions.appendChild(button('取消', 'cm-me-btn-ghost', function () {
      form.hidden = true;
    }));
    form.appendChild(actions);
    return form;
  }


function profileCard(profile){
 var card=el('section','cm-personal-profile');card.appendChild(C.avatarEl(profile,52));var copy=el('div','cm-personal-copy');copy.appendChild(el('h3','',profile.name||'同学'));
 var meta=[profile.provinceName,profile.examYear?profile.examYear+'年':'',profile.targetMajor].filter(Boolean);if(meta.length)copy.appendChild(el('p','',meta.join(' · ')));if(profile.bio)copy.appendChild(el('p','',profile.bio));card.appendChild(copy);
 card.appendChild(button('编辑资料','cm-me-btn-ghost',function(){var form=document.getElementById('cmMeEdit');form.hidden=!form.hidden;}));return card;
}
function activityRow(row){
 var post=row.post,entry=button('','cm-activity-row',function(){window.CommunityStudio.openPost(post.id,row.comment&&row.comment.id);});
 var meta=el('div','cm-activity-meta');meta.appendChild(el('span','',row.comment?'我的评论':post.isAnonymous?'匿名动态':post.authorName||'同学'));meta.appendChild(el('time','',C.timeAgo(row.comment?row.comment.createdAt:post.createdAt)));entry.appendChild(meta);
 if(row.comment)entry.appendChild(el('p','cm-activity-comment',row.comment.body));
 var excerpt=el('div',row.comment?'cm-activity-source':'cm-activity-excerpt');excerpt.appendChild(el('p','',post.body));entry.appendChild(excerpt);
 if(post.photos&&post.photos.length){var photos=el('div','cm-activity-photos');post.photos.slice(0,3).forEach(function(url){if(!/^\/public\/images\/community\/[a-f0-9]{40}\.(jpg|png|webp)$/.test(url))return;var image=document.createElement('img');image.src=url;image.alt='动态照片';image.loading='lazy';photos.appendChild(image);});entry.appendChild(photos);}
 entry.appendChild(el('small','cm-activity-counts','赞 '+(post.likeCount||0)+' · 评论 '+(post.commentCount||0)+' · 收藏 '+(post.favoriteCount||0)));var item=el('div','cm-own-activity-item');item.appendChild(entry);
 if(section==='posts')item.appendChild(button('删除','cm-own-post-delete',async function(){if(!window.confirm('确定删除这条动态？删除后不可恢复。'))return;this.disabled=true;var result=await C.request(API+'/posts/'+post.id,{method:'DELETE'});if(!result.ok){this.disabled=false;C.toast((result.data&&result.data.error)||'删除失败');return;}C.toast('已删除');renderPage(lastBox);}));return item;
}
function activityPanel(){
 var wrap=el('section','cm-activity-panel'),tabs=el('div','cm-personal-tabs');wrap.appendChild(tabs);var list=el('div','cm-activity-list');wrap.appendChild(list);
 var choices=[['posts','动态'],['likes','点赞'],['favorites','收藏'],['comments','评论']];
 choices.forEach(function(choice){var tab=button('','cm-personal-tab',function(){section=choice[0];update();load(1);});var paths={posts:['M4 3h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z','M15 3h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z','M4 14h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1Z','M15 14h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1Z'],favorites:['M5 3.5A1.5 1.5 0 0 1 6.5 2h11A1.5 1.5 0 0 1 19 3.5V22l-7-4.5L5 22V3.5Z'],likes:['M12 21C8.7 18.9 2 14.4 2 8.7 2 5.6 4.3 3.5 7.1 3.5c2.2 0 3.9 1.2 4.9 2.8 1-1.6 2.7-2.8 4.9-2.8 2.8 0 5.1 2.1 5.1 5.2 0 5.7-6.7 10.2-10 12.3Z'],comments:['M12 3C6.7 3 3 6.5 3 11c0 4.6 3.7 8 8.3 8H13v3l5.4-4.3C20.1 16.3 21 14 21 11c0-4.5-3.7-8-9-8Z']};var ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('fill','none');svg.setAttribute('stroke','currentColor');svg.setAttribute('stroke-linecap','round');svg.setAttribute('stroke-linejoin','round');svg.setAttribute('aria-hidden','true');paths[choice[0]].forEach(function(d){var path=document.createElementNS(ns,'path');path.setAttribute('d',d);svg.appendChild(path);});tab.setAttribute('aria-label',choice[1]);tab.title=choice[1];tab.style.minWidth='36px';tab.insertBefore(svg,tab.firstChild);tab.dataset.section=choice[0];tabs.appendChild(tab);});
 function update(){Array.prototype.forEach.call(tabs.children,function(tab){var on=tab.dataset.section===section;tab.classList.toggle('active',on);tab.setAttribute('aria-pressed',String(on));});}
 async function load(page){var sequence=++activitySequence,key=section;if(page===1){C.clear(list);list.appendChild(C.loadingEl('正在加载…'));}var result=await C.request(API+'/me/activity?section='+key+'&page='+page);if(sequence!==activitySequence||!wrap.isConnected)return;
  if(page===1)C.clear(list);else{var prior=list.querySelector('.cm-activity-more');if(prior)prior.remove();}
  if(!result.ok){list.appendChild(el('p','cm-activity-empty','记录暂时未能加载'));list.appendChild(button('重试','cm-me-btn-ghost',function(){load(page);}));return;}
  var data=result.data,rows=data.rows||[];if(!rows.length&&page===1){list.appendChild(el('p','cm-activity-empty',({posts:'还没有发布动态',favorites:'还没有收藏内容',likes:'还没有赞过的内容',comments:'还没有评论记录'})[key]));return;}
  rows.forEach(function(row){list.appendChild(activityRow(row));});if(page*data.pageSize<data.total){var more=button('加载更多','cm-activity-more',function(){more.disabled=true;load(page+1);});list.appendChild(more);}
 }
 update();setTimeout(function(){load(1);},0);return wrap;
}
async function renderPage(box){
 if(!box)return;lastBox=box;var sequence=++renderSequence;activitySequence++;C.clear(box);
 if(!C.signedIn()){box.appendChild(el('p','cm-activity-empty','登录后查看你的动态与互动记录'));box.appendChild(button('登录','cm-me-btn-ghost',function(){C.requireLogin('查看我的');}));return;}
 box.appendChild(C.loadingEl('正在加载个人资料…'));var me=await C.request(API+'/growth/me');if(sequence!==renderSequence)return;
 if(!me.ok){C.clear(box);box.appendChild(el('p','cm-activity-empty','个人资料暂时未能加载'));box.appendChild(button('重试','cm-me-btn-ghost',function(){renderPage(box);}));return;}
 var result=await C.request(API+'/profile/'+me.data.studentId);if(sequence!==renderSequence)return;C.clear(box);
 if(!result.ok){box.appendChild(el('p','cm-activity-empty','个人资料暂时未能加载'));box.appendChild(button('重试','cm-me-btn-ghost',function(){renderPage(box);}));return;}
 var wrap=el('div','cm-personal-root');wrap.appendChild(profileCard(result.data.profile));wrap.appendChild(renderEditForm(result.data.profile));wrap.appendChild(activityPanel());box.appendChild(wrap);
}
var module={render:renderPage,refresh:function(){if(lastBox)renderPage(lastBox);},deactivate:function(){renderSequence++;activitySequence++;}};
var hubBox=null;
function renderHub(box){hubBox=box;C.clear(box);var hub=el('div','cm-personal-hub'),inbox=el('section','cm-hub-inbox'),activity=el('section','cm-hub-activity');inbox.setAttribute('aria-label','我的消息');activity.setAttribute('aria-label','我的动态');hub.append(inbox,activity);box.appendChild(hub);activity.appendChild(el('h3','cm-hub-column-title','我的动态'));var activityBody=el('div','cm-hub-activity-body');activity.appendChild(activityBody);renderPage(activityBody);if(window.CZCommunityMessages)window.CZCommunityMessages.render(inbox);}
var hubModule={render:renderHub,refresh:function(){if(hubBox)renderHub(hubBox);},deactivate:function(){module.deactivate();if(window.CZCommunityMessages&&window.CZCommunityMessages.deactivate)window.CZCommunityMessages.deactivate();}};
Shell.register('me',hubModule);Shell.register('message',hubModule);window.CZCommunityGrowth={refresh:module.refresh};
})();
