/* 社区 v2 页签壳：广场 / 找搭子 / 消息 / 我的。
 * 各模块用 CZCommunityShell.register(name, {render, refresh}) 注册自己的页签；
 * 切换时清空 #communityBox 并调用对应模块的 render。 */
(function () {
  'use strict';

  const modules = {};
  let current = null;
  const VALID = ['plaza', 'partner', 'message', 'me'];

  function tabs() {
    return Array.prototype.slice.call(document.querySelectorAll('#communityTabs [data-ctab]'));
  }

  function currentViewer() {
    return window.CZ_VIEWER || { signedIn: false };
  }

  function setBadge(count) {
    const badge = document.getElementById('communityBadge');
    if (!badge) return;
    const n = Number(count) || 0;
    badge.hidden = n <= 0;
    badge.textContent = n > 99 ? '99+' : String(n);
  }

  function show(name) {
    const tab = name==='me'?'message':VALID.indexOf(name) >= 0 ? name : 'plaza';
    const module = modules[tab];
    if (!module) return;
    const box = document.getElementById('communityBox');
    if (!box) return;
    if (current && modules[current] && typeof modules[current].deactivate === 'function') modules[current].deactivate();
    const view = document.getElementById('viewCommunity');
    const locked = !window.CZCommunity.signedIn();
    if (view) view.toggleAttribute('data-access-locked', locked);
    box.inert = locked;
    tabs().forEach(function (button) {
      const active = button.getAttribute('data-ctab') === tab;
      button.classList.toggle('active', active);
      button.setAttribute('aria-selected', String(active));
      button.setAttribute('tabindex', active ? '0' : '-1');
      button.id = 'community-tab-' + button.getAttribute('data-ctab');
      button.setAttribute('aria-controls', 'communityBox');
    });
    window.CZCommunity.clear(box);
    box.classList.remove('cm-plaza');
    box.classList.add('cm-root');
    box.setAttribute('role', 'tabpanel');
    if(document.getElementById('community-tab-'+tab)){box.setAttribute('aria-labelledby','community-tab-'+tab);box.removeAttribute('aria-label');}else{box.removeAttribute('aria-labelledby');box.setAttribute('aria-label',tab==='me'?'我的动态':'社区内容');}
    const masthead=document.querySelector('#viewCommunity .community-intro h2'),navigation=document.querySelector('#viewCommunity .community-tabbar');
    if(masthead)masthead.textContent=tab==='me'||tab==='message'?'消息与动态':'备考社区';
    if(navigation){navigation.hidden=tab==='me';navigation.style.display=tab==='me'?'none':'';}
    current = tab;
    document.querySelectorAll('.menu-item[data-view="community"]').forEach(function (button) {
      button.classList.toggle('on', !!document.getElementById('viewCommunity')?.classList.contains('active') && tab !== 'message' && tab !== 'me');
    });
    const section = document.getElementById('viewCommunity');
    if ((section && section.classList.contains('active')) || /^#community-/.test(window.location.hash)) {
      try { window.history.replaceState(null, '', '#community-' + tab); } catch (e) { /* 忽略 */ }
    }
    try {
      module.render(box);
    } catch (error) {
      box.appendChild(window.CZCommunity.emptyEl('页面渲染失败，请刷新重试'));
    }
  }

  function refresh() {
    if (current && modules[current] && typeof modules[current].refresh === 'function') {
      modules[current].refresh();
    }
  }

  function register(name, module) {
    if (VALID.indexOf(name) < 0 || !module || typeof module.render !== 'function') return false;
    modules[name] = module;
    return true;
  }

  function boot() {
    document.querySelectorAll('.menu-item[data-view="community"]').forEach(function (button) {
      button.addEventListener('click', function () { show('plaza'); });
    });
    tabs().forEach(function (button) {
      button.addEventListener('click', function () { show(button.getAttribute('data-ctab')); });
      button.addEventListener('keydown', function (event) {
        const items = tabs();
        let index = items.indexOf(button);
        if (event.key === 'ArrowRight') index = (index + 1) % items.length;
        else if (event.key === 'ArrowLeft') index = (index + items.length - 1) % items.length;
        else if (event.key === 'Home') index = 0;
        else if (event.key === 'End') index = items.length - 1;
        else return;
        event.preventDefault();
        items[index].focus();
        show(items[index].getAttribute('data-ctab'));
      });
    });
    const hash = String(window.location.hash || '').replace('#community-', '');
    // 未登录时消息页会显示登录引导；默认广场。
    show(VALID.indexOf(hash) >= 0 ? hash : 'plaza');
  }

  // defer 脚本执行时 readyState 已是 interactive，此时其它模块可能尚未注册；
  // 统一等到 DOMContentLoaded（所有 defer 执行完毕）再渲染首屏。
  if (document.readyState === 'complete') {
    boot();
  } else {
    document.addEventListener('DOMContentLoaded', boot);
  }

  window.CZCommunityShell = {
    register: register,
    show: show,
    refresh: refresh,
    current: function () { return current; },
    setBadge: setBadge,
    viewer: currentViewer
  };
})();
