/* Local photo selection; upload only with the post, never while drafting. */
(function(){
 'use strict';
 window.CZCommunityPhotos={create:function(container,publishing){
  var items=[],pending=false,input=document.createElement('input'),add=document.createElement('button'),hint=document.createElement('span'),grid=document.createElement('div');
  container.className='cm-photo-editor';input.type='file';input.accept='image/jpeg,image/png,image/webp';input.multiple=true;input.hidden=true;
  add.type='button';add.className='cm-photo-add cz-icon-action';add.innerHTML='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>';add.style.display='inline-flex';add.style.alignItems='center';add.style.justifyContent='center';add.style.minWidth='24px';add.title='添加照片：最多3张，单张5MB以内';add.setAttribute('aria-label','添加照片');hint.className='cm-photo-hint';hint.hidden=true;grid.className='cm-photo-previews';container.append(add,hint,input,grid);
  function message(text){window.CZCommunity.toast(text);}
  function render(){grid.replaceChildren();add.disabled=pending||items.length>=3||publishing();items.forEach(function(item,index){var tile=document.createElement('div'),image=document.createElement('img'),remove=document.createElement('button');tile.className='cm-photo-preview';image.src=item.url;image.alt='待发布照片 '+(index+1);remove.type='button';remove.className='cm-photo-remove';remove.textContent='×';remove.setAttribute('aria-label','移除第'+(index+1)+'张照片');remove.disabled=pending||publishing();remove.onclick=function(){if(pending||publishing())return;URL.revokeObjectURL(item.url);items.splice(index,1);render();};tile.append(image,remove);grid.append(tile);});}
  async function encode(file){
   if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>5*1024*1024)throw Error('请选择5MB以内的JPG、PNG或WebP照片');
   var url=URL.createObjectURL(file),image=new Image();
   try{await new Promise(function(resolve,reject){image.onload=resolve;image.onerror=function(){reject(Error('照片无法读取，请换一张'));};image.src=url;});
    var scale=Math.min(1,1920/Math.max(image.naturalWidth,image.naturalHeight)),canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(image.naturalWidth*scale));canvas.height=Math.max(1,Math.round(image.naturalHeight*scale));var ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);
    var blob=await new Promise(function(resolve){canvas.toBlob(resolve,'image/jpeg',.88);});if(!blob)throw Error('照片处理失败，请重新选择');return new File([blob],'photo.jpg',{type:'image/jpeg'});
   }finally{URL.revokeObjectURL(url);}
  }
  add.onclick=function(){if(!pending&&!publishing())input.click();};
  input.onchange=async function(){var files=Array.from(input.files||[]);input.value='';if(publishing()||pending)return;if(items.length+files.length>3){message('每条动态最多添加3张照片');return;}pending=true;render();try{for(var file of files){var encoded=await encode(file);items.push({file:encoded,url:URL.createObjectURL(encoded)});}}catch(error){message(error.message);}finally{pending=false;render();}};
  return {files:function(){return items.map(function(item){return item.file;});},pending:function(){return pending;},clear:function(){items.forEach(function(item){URL.revokeObjectURL(item.url);});items=[];render();},refresh:render};
 }};
})();
