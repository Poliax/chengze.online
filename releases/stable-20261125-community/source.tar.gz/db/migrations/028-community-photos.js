module.exports = db => {
  const info=db.exec('PRAGMA table_info(community_posts)');
  const columns=info.length?info[0].values.map(row=>row[1]):[];
  if(columns.length&&!columns.includes('photos_json'))db.run("ALTER TABLE community_posts ADD COLUMN photos_json TEXT NOT NULL DEFAULT '[]'");
};
