// 社区 v2 社交模块：关注关系 / 学习搭子匹配 / 站内通知 / 私信。
// 挂载 /api/community，须在内容路由之前；本文件不写 catch-all 404 与错误中间件（由内容路由与 app 级兜底）。
// 约定：requireStudentApi → 参数校验 → 内容过滤 → 归属/存在性（404）→ 事务写入 → JSON。
'use strict';

const express = require('express');
const router = express.Router();
const db = require('../db');
const filter = require('../lib/community-filter');
const notify = require('../lib/community-notify');
const growth = require('../lib/community-growth');
const { currentStudent, requireStudentApi } = require('../middleware/student-auth');

const PAGE_SIZE = 20;
const PARTNER_LIMIT_DEFAULT = 20;
const PARTNER_LIMIT_MAX = 50;
// 匹配候选池上限：v2 用户规模有限，先取最近 500 个活跃学员算分，避免全表扫。
const PARTNER_CANDIDATE_MAX = 500;
const MESSAGE_PAGE_LIMIT_DEFAULT = 50;
const MESSAGE_PAGE_LIMIT_MAX = 100;
const MESSAGE_MIN_LENGTH = 1;
const MESSAGE_MAX_LENGTH = 500;
const MESSAGE_PER_MINUTE = 20;
const MESSAGE_PER_DAY = 200;
const MESSAGE_MINUTE_WINDOW_MS = 60 * 1000;

router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

// All community content requires an active student session.
router.use(requireStudentApi);

function fail(res, status, error) {
  return res.status(status).json({ ok: false, error });
}

function intParam(raw, fallback, min, max) {
  const n = parseInt(raw, 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function positiveId(raw) {
  const text = String(raw == null ? '' : raw);
  if (!/^[1-9]\d*$/.test(text)) return null;
  const n = Number(text);
  return Number.isSafeInteger(n) ? n : null;
}

function textParam(raw, maxLength) {
  if (raw == null) return '';
  const text = String(raw).trim();
  return text.slice(0, maxLength);
}

function readStudyTags(raw) {
  try {
    const list = JSON.parse(raw || '[]');
    if (!Array.isArray(list)) return [];
    const tags = [];
    for (const item of list) {
      const tag = typeof item === 'string' ? item.trim() : '';
      if (tag && !tags.includes(tag)) tags.push(tag);
    }
    return tags.slice(0, 20);
  } catch (e) {
    return [];
  }
}

// ── 身份卡（字段严格按契约 5.1，与成长模块 /profile/:id 保持一致；不返回手机号等敏感字段） ──
const IDENTITY_SELECT = `SELECT s.id, s.name, s.nickname, s.avatar, s.gender, s.province_code, s.exam_year,
  s.target_school, s.target_major, s.bio, s.study_tags, s.status,
  COALESCE(g.points, 0) AS points,
  (SELECT COUNT(*) FROM community_follows f WHERE f.following_id = s.id) AS followers,
  (SELECT COUNT(*) FROM community_follows f WHERE f.follower_id = s.id) AS following_count,
  (SELECT COUNT(*) FROM community_posts p WHERE p.student_id = s.id AND p.status = 'published' AND COALESCE(p.is_anonymous, 0) = 0) AS post_count,
  EXISTS(SELECT 1 FROM community_follows f WHERE f.follower_id = ? AND f.following_id = s.id) AS following_him,
  EXISTS(SELECT 1 FROM community_follows f WHERE f.follower_id = s.id AND f.following_id = ?) AS following_me
  FROM students s LEFT JOIN student_growth g ON g.student_id = s.id`;

// provinces 表在精简部署/测试环境可能不存在，名称留空即可。
function loadProvinceNames() {
  const map = {};
  try {
    const rows = db.query('SELECT code, name FROM provinces');
    for (const row of rows) {
      const code = String(row.code == null ? '' : row.code).trim();
      if (code && !map[code]) map[code] = String(row.name == null ? '' : row.name);
    }
  } catch (e) {
    // 表不存在：忽略
  }
  return map;
}

function mapIdentityCard(row, viewerId, provinceNames) {
  const provinceCode = String(row.province_code == null ? '' : row.province_code);
  const points = Number(row.points) || 0;
  const info = growth.levelFor(points);
  const id = Number(row.id);
  return {
    id: id,
    name: filter.displayName({ name: row.name, nickname: row.nickname }),
    avatar: row.avatar || '',
    gender: row.gender || 'unknown',
    provinceCode: provinceCode,
    provinceName: provinceNames[provinceCode] || '',
    examYear: String(row.exam_year == null ? '' : row.exam_year),
    targetSchool: String(row.target_school == null ? '' : row.target_school),
    targetMajor: String(row.target_major == null ? '' : row.target_major),
    bio: String(row.bio == null ? '' : row.bio),
    studyTags: readStudyTags(row.study_tags),
    level: info.level,
    levelTitle: info.title,
    points: points,
    followers: Number(row.followers) || 0,
    following: Number(row.following_count) || 0,
    posts: Number(row.post_count) || 0,
    followingMe: !!Number(row.following_me),
    followingHim: !!Number(row.following_him),
    isSelf: Number(viewerId) > 0 && Number(viewerId) === id
  };
}

// 批量读取身份卡；保持传入 id 顺序，已停用/不存在的账号自动跳过。
function loadIdentityCards(ids, viewerId) {
  const viewer = Number(viewerId) || 0;
  const unique = [];
  for (const raw of ids) {
    const id = Number(raw);
    if (Number.isSafeInteger(id) && id > 0 && !unique.includes(id)) unique.push(id);
  }
  if (!unique.length) return [];
  const placeholders = unique.map(() => '?').join(',');
  const rows = db.query(
    IDENTITY_SELECT + " WHERE COALESCE(s.status, 'active') <> 'disabled' AND s.id IN (" + placeholders + ')',
    [viewer, viewer].concat(unique)
  );
  const provinceNames = loadProvinceNames();
  const byId = new Map();
  for (const row of rows) byId.set(Number(row.id), mapIdentityCard(row, viewer, provinceNames));
  const cards = [];
  for (const id of unique) {
    const card = byId.get(id);
    if (card) cards.push(card);
  }
  return cards;
}

function loadIdentityCard(studentId, viewerId) {
  const cards = loadIdentityCards([studentId], viewerId);
  return cards.length ? cards[0] : null;
}

function studentExists(studentId) {
  const row = db.get("SELECT id, status FROM students WHERE id=?", [studentId]);
  return !!row && row.status !== 'disabled';
}

// ── 关注 / 取关 ──
router.post('/follow/:studentId', requireStudentApi, (req, res) => {
  const targetId = positiveId(req.params.studentId);
  if (!targetId) return fail(res, 404, '用户不存在');
  const sid = req.student.id;
  if (targetId === sid) return fail(res, 400, '不能关注自己');
  if (!studentExists(targetId)) return fail(res, 404, '用户不存在');

  let following = false;
  db.atomic(() => {
    const existing = db.get(
      'SELECT 1 AS x FROM community_follows WHERE follower_id=? AND following_id=?',
      [sid, targetId]
    );
    if (existing) {
      db.run('DELETE FROM community_follows WHERE follower_id=? AND following_id=?', [sid, targetId]);
      following = false;
    } else {
      db.run('INSERT INTO community_follows (follower_id, following_id) VALUES (?,?)', [sid, targetId]);
      following = true;
    }
  });

  if (following) {
    // 通知与积分属于辅助动作：失败不影响关注主流程。
    try {
      notify.notify(db, {
        studentId: targetId,
        actorId: sid,
        type: 'follow',
        targetType: 'student',
        targetId: sid,
        content: filter.displayName(req.student) + ' 关注了你'
      });
    } catch (e) {
      console.error('[community-social] follow notify failed:', e && e.message);
    }
    try {
      growth.award(db, targetId, 'follow_received');
    } catch (e) {
      console.error('[community-social] follow award failed:', e && e.message);
    }
  }

  const countRow = db.get('SELECT COUNT(*) AS c FROM community_follows WHERE following_id=?', [targetId]);
  res.json({ ok: true, following: following, followerCount: Number(countRow && countRow.c) || 0 });
});

// ── 粉丝列表 ──
router.get('/followers/:studentId', (req, res) => {
  const targetId = positiveId(req.params.studentId);
  if (!targetId) return fail(res, 404, '用户不存在');
  if (!studentExists(targetId)) return fail(res, 404, '用户不存在');
  const viewer = currentStudent(req);
  const viewerId = viewer ? viewer.id : 0;
  const page = intParam(req.query.page, 1, 1, 1000000);
  const totalRow = db.get(
    "SELECT COUNT(*) AS c FROM community_follows f JOIN students s ON s.id = f.follower_id" +
      " WHERE f.following_id=? AND COALESCE(s.status, 'active') <> 'disabled'",
    [targetId]
  );
  const rows = db.query(
    "SELECT f.follower_id FROM community_follows f JOIN students s ON s.id = f.follower_id" +
      " WHERE f.following_id=? AND COALESCE(s.status, 'active') <> 'disabled'" +
      ' ORDER BY f.created_at DESC, f.follower_id DESC LIMIT ? OFFSET ?',
    [targetId, PAGE_SIZE, (page - 1) * PAGE_SIZE]
  );
  res.json({
    ok: true,
    page: page,
    pageSize: PAGE_SIZE,
    total: Number(totalRow && totalRow.c) || 0,
    rows: loadIdentityCards(rows.map(row => row.follower_id), viewerId)
  });
});

// ── 关注列表 ──
router.get('/following/:studentId', (req, res) => {
  const targetId = positiveId(req.params.studentId);
  if (!targetId) return fail(res, 404, '用户不存在');
  if (!studentExists(targetId)) return fail(res, 404, '用户不存在');
  const viewer = currentStudent(req);
  const viewerId = viewer ? viewer.id : 0;
  const page = intParam(req.query.page, 1, 1, 1000000);
  const totalRow = db.get(
    "SELECT COUNT(*) AS c FROM community_follows f JOIN students s ON s.id = f.following_id" +
      " WHERE f.follower_id=? AND COALESCE(s.status, 'active') <> 'disabled'",
    [targetId]
  );
  const rows = db.query(
    "SELECT f.following_id FROM community_follows f JOIN students s ON s.id = f.following_id" +
      " WHERE f.follower_id=? AND COALESCE(s.status, 'active') <> 'disabled'" +
      ' ORDER BY f.created_at DESC, f.following_id DESC LIMIT ? OFFSET ?',
    [targetId, PAGE_SIZE, (page - 1) * PAGE_SIZE]
  );
  res.json({
    ok: true,
    page: page,
    pageSize: PAGE_SIZE,
    total: Number(totalRow && totalRow.c) || 0,
    rows: loadIdentityCards(rows.map(row => row.following_id), viewerId)
  });
});

// ── 学习搭子匹配 ──
function partnerFilterOptions(myProvinceCode, myExamYear) {
  const provinces = [];
  const seen = new Map();
  try {
    const rows = db.query('SELECT code, name FROM provinces ORDER BY id ASC');
    for (const row of rows) {
      const code = String(row.code == null ? '' : row.code).trim();
      if (!code || seen.has(code)) continue;
      const name = String(row.name == null ? '' : row.name);
      seen.set(code, true);
      provinces.push({ code: code, name: name });
    }
  } catch (e) {
    // provinces 表不存在：退化为 students 里出现过的省份编码
  }
  if (!provinces.length) {
    const rows = db.query(
      "SELECT DISTINCT province_code FROM students WHERE province_code IS NOT NULL AND province_code <> '' ORDER BY province_code ASC"
    );
    for (const row of rows) {
      const code = String(row.province_code == null ? '' : row.province_code).trim();
      if (!code || seen.has(code)) continue;
      seen.set(code, true);
      provinces.push({ code: code, name: '' });
    }
  }
  const mine = String(myProvinceCode == null ? '' : myProvinceCode).trim();
  if (mine && !seen.has(mine)) provinces.push({ code: mine, name: '' });

  const years = [];
  const yearRows = db.query(
    "SELECT DISTINCT exam_year FROM students WHERE exam_year IS NOT NULL AND exam_year <> '' ORDER BY exam_year DESC"
  );
  for (const row of yearRows) {
    const year = String(row.exam_year == null ? '' : row.exam_year).trim();
    if (year && !years.includes(year)) years.push(year);
  }
  const myYear = String(myExamYear == null ? '' : myExamYear).trim();
  if (myYear && !years.includes(myYear)) years.unshift(myYear);
  return { provinces: provinces, years: years };
}

router.get('/partners', requireStudentApi, (req, res) => {
  const sid = req.student.id;
  const limit = intParam(req.query.limit, PARTNER_LIMIT_DEFAULT, 1, PARTNER_LIMIT_MAX);
  const provinceFilter = textParam(req.query.province, 12);
  const yearFilter = textParam(req.query.year, 12);

  const me = db.get(
    'SELECT id, name, nickname, avatar, gender, province_code, exam_year, target_school, target_major, bio, study_tags FROM students WHERE id=?',
    [sid]
  );
  if (!me) return fail(res, 401, '请先登录');

  const myProvince = String(me.province_code == null ? '' : me.province_code).trim();
  const myYear = String(me.exam_year == null ? '' : me.exam_year).trim();
  const myMajor = String(me.target_major == null ? '' : me.target_major).trim();
  const mySchool = String(me.target_school == null ? '' : me.target_school).trim();
  const myTags = readStudyTags(me.study_tags);

  const where = ["s.id <> ?", "COALESCE(s.status, 'active') <> 'disabled'"];
  const params = [sid];
  if (provinceFilter) {
    where.push('s.province_code = ?');
    params.push(provinceFilter);
  }
  if (yearFilter) {
    where.push('s.exam_year = ?');
    params.push(yearFilter);
  }
  // 候选池按「同省 / 同年」优先保留，再按 id 倒序（新人优先），上限 500。
  const candidates = db.query(
    'SELECT s.id, s.name, s.nickname, s.avatar, s.gender, s.province_code, s.exam_year, s.target_school, s.target_major, s.bio, s.study_tags' +
      ' FROM students s WHERE ' + where.join(' AND ') +
      ' ORDER BY (s.province_code = ? AND ? <> \'\') DESC, (s.exam_year = ? AND ? <> \'\') DESC, s.id DESC LIMIT ?',
    params.concat([myProvince, myProvince, myYear, myYear, PARTNER_CANDIDATE_MAX])
  );

  const scored = [];
  for (const row of candidates) {
    const provinceCode = String(row.province_code == null ? '' : row.province_code).trim();
    const examYear = String(row.exam_year == null ? '' : row.exam_year).trim();
    const major = String(row.target_major == null ? '' : row.target_major).trim();
    const school = String(row.target_school == null ? '' : row.target_school).trim();
    const tags = readStudyTags(row.study_tags);
    let score = 0;
    const reasons = [];
    if (myProvince && provinceCode === myProvince) {
      score += 30;
      reasons.push('同省');
    }
    if (myYear && examYear === myYear) {
      score += 30;
      reasons.push('同年考试');
    }
    if (myMajor && major === myMajor) {
      score += 20;
      reasons.push('目标专业相同');
    }
    if (mySchool && school === mySchool) {
      score += 20;
      reasons.push('目标院校相同');
    }
    const sharedTags = tags.filter(tag => myTags.includes(tag));
    if (sharedTags.length) {
      score += sharedTags.length * 5;
      reasons.push('共同学习科目：' + sharedTags.join('、'));
    }
    scored.push({ id: Number(row.id), score: score, reasons: reasons });
  }
  scored.sort((a, b) => b.score - a.score || a.id - b.id);
  const picked = scored.slice(0, limit);

  const cards = loadIdentityCards(picked.map(item => item.id), sid);
  const cardById = new Map(cards.map(card => [card.id, card]));
  const rows = [];
  for (const item of picked) {
    const card = cardById.get(item.id);
    if (!card) continue;
    rows.push(Object.assign({}, card, {
      // 契约 5.1 中 following 已是「我关注的人数」，关系状态用 followingHim / isFollowing 表达，避免字段冲突。
      isFollowing: card.followingHim,
      matchScore: item.score,
      matchReasons: item.reasons
    }));
  }

  const options = partnerFilterOptions(myProvince, myYear);
  res.json({
    ok: true,
    rows: rows,
    filters: { provinces: options.provinces, years: options.years },
    // 前端筛选下拉默认取我的资料：额外返回本人省份/年份（只含非敏感字段）。
    me: { provinceCode: myProvince, examYear: myYear }
  });
});

// ── 通知列表 ──
function notificationGroups(sid){
 const counts={comments:0,reactions:0,system:0};
 for(const row of db.query('SELECT type,COUNT(*) n FROM community_notifications WHERE student_id=? AND is_read=0 GROUP BY type',[sid])){
  const group=['comment','reply'].includes(row.type)?'comments':['like','favorite'].includes(row.type)?'reactions':'system';counts[group]+=Number(row.n)||0;
 }
 return counts;
}
router.get('/notifications', requireStudentApi, (req, res) => {
  const sid = req.student.id;
  const page = intParam(req.query.page, 1, 1, 1000000);
  const unreadOnly = String(req.query.unread == null ? '' : req.query.unread) === '1';
  const group=['comments','reactions','system'].includes(req.query.group)?req.query.group:'';
  const where = ['n.student_id = ?'];
  if(group==='comments')where.push("n.type IN ('comment','reply')");
  if(group==='reactions')where.push("n.type IN ('like','favorite')");
  if(group==='system')where.push("n.type NOT IN ('comment','reply','like','favorite')");
  const params = [sid];
  if (unreadOnly) where.push('n.is_read = 0');
  const whereSql = where.join(' AND ');
  const totalRow = db.get('SELECT COUNT(*) AS c FROM community_notifications n WHERE ' + whereSql, params);
  const rows = db.query(
    'SELECT n.id, n.actor_id, n.type, n.target_type, n.target_id, n.content, n.is_read, n.created_at,' +
      ' s.name AS actor_name, s.nickname AS actor_nickname, s.gender AS actor_gender, s.avatar AS actor_avatar' +
      ' FROM community_notifications n LEFT JOIN students s ON s.id = n.actor_id' +
      ' WHERE ' + whereSql + ' ORDER BY n.created_at DESC, n.id DESC LIMIT ? OFFSET ?',
    params.concat([PAGE_SIZE, (page - 1) * PAGE_SIZE])
  );
  const out = rows.map(row => {
    const actorId = Number(row.actor_id) || 0;
    const hasActor = actorId > 0 && row.actor_name != null;
    const actor = hasActor
      ? { id: actorId, name: filter.displayName({ name: row.actor_name, nickname: row.actor_nickname }), avatar: row.actor_avatar || '',gender:row.actor_gender||'unknown' }
      : { id: actorId, name: '系统', avatar: '' };
    return {
      id: Number(row.id),
      type: String(row.type || ''),
      actor: actor,
      content: String(row.content || ''),
      targetType: String(row.target_type || ''),
      targetId: Number(row.target_id) || 0,
      postId: row.target_type==='post'?Number(row.target_id)||0:row.target_type==='comment'?Number((db.get("SELECT post_id FROM community_comments WHERE id=? AND status='published'",[row.target_id])||{}).post_id)||0:0,
      isRead: !!Number(row.is_read),
      createdAt: row.created_at
    };
  });
  res.json({
    ok: true,
    page: page,
    pageSize: PAGE_SIZE,
    total: Number(totalRow && totalRow.c) || 0,
    unread: notify.unreadCount(db, sid),
    groups:notificationGroups(sid),
    groupUnread:group?notificationGroups(sid)[group]:notify.unreadCount(db,sid),
    rows: out
  });
});

// ── 标记通知已读 ──
router.post('/notifications/read', requireStudentApi, (req, res) => {
  const sid = req.student.id;
  const body = req.body || {};
  if (body.all === true) {
    db.run('UPDATE community_notifications SET is_read=1 WHERE student_id=? AND is_read=0', [sid]);
  } else {
    if (!Array.isArray(body.ids)) return fail(res, 400, '参数不正确');
    const ids = [];
    for (const raw of body.ids) {
      const id = positiveId(raw);
      if (!id) return fail(res, 400, '参数不正确');
      if (!ids.includes(id)) ids.push(id);
    }
    if (!ids.length) return fail(res, 400, '参数不正确');
    if (ids.length > 100) return fail(res, 400, '一次最多标记 100 条通知');
    const placeholders = ids.map(() => '?').join(',');
    db.run(
      'UPDATE community_notifications SET is_read=1 WHERE student_id=? AND is_read=0 AND id IN (' + placeholders + ')',
      [sid].concat(ids)
    );
  }
  res.json({ ok: true, unread: notify.unreadCount(db, sid) });
});

// ── 未读数汇总（通知 + 私信） ──
router.get('/messages/unread', requireStudentApi, (req, res) => {
  const sid = req.student.id;
  let notifications = 0;
  try {
    notifications = notify.unreadCount(db, sid);
  } catch (e) {
    notifications = 0;
  }
  const messageRow = db.get(
    'SELECT COUNT(*) AS c FROM community_messages WHERE receiver_id=? AND is_read=0',
    [sid]
  );
  const messages = Number(messageRow && messageRow.c) || 0;
  res.json({ ok: true, notifications: notifications, messages: messages, total: notifications + messages,groups:notificationGroups(sid) });
});

// ── 会话列表 ──
router.get('/messages/conversations', requireStudentApi, (req, res) => {
  const sid = req.student.id;
  const page = intParam(req.query.page, 1, 1, 1000000);
  const totalRow = db.get(
    'SELECT COUNT(DISTINCT CASE WHEN sender_id=? THEN receiver_id ELSE sender_id END) AS c FROM community_messages WHERE sender_id=? OR receiver_id=?',
    [sid, sid, sid]
  );
  const rows = db.query(
    'SELECT MAX(id) AS last_id, CASE WHEN sender_id=? THEN receiver_id ELSE sender_id END AS peer_id' +
      ' FROM community_messages WHERE sender_id=? OR receiver_id=?' +
      ' GROUP BY peer_id ORDER BY last_id DESC LIMIT ? OFFSET ?',
    [sid, sid, sid, PAGE_SIZE, (page - 1) * PAGE_SIZE]
  );
  const lastIds = rows.map(row => Number(row.last_id)).filter(id => Number.isSafeInteger(id) && id > 0);
  const messagesById = new Map();
  if (lastIds.length) {
    const placeholders = lastIds.map(() => '?').join(',');
    const lastRows = db.query(
      'SELECT id, sender_id, receiver_id, body, created_at FROM community_messages WHERE id IN (' + placeholders + ')',
      lastIds
    );
    for (const row of lastRows) messagesById.set(Number(row.id), row);
  }
  const unreadByPeer = new Map();
  const unreadRows = db.query(
    'SELECT sender_id, COUNT(*) AS c FROM community_messages WHERE receiver_id=? AND is_read=0 GROUP BY sender_id',
    [sid]
  );
  for (const row of unreadRows) unreadByPeer.set(Number(row.sender_id), Number(row.c) || 0);

  const peerIds = rows.map(row => Number(row.peer_id)).filter(id => Number.isSafeInteger(id) && id > 0);
  const cards = loadIdentityCards(peerIds, sid);
  const cardById = new Map(cards.map(card => [card.id, card]));
  const out = [];
  for (const row of rows) {
    const peerId = Number(row.peer_id);
    const card = cardById.get(peerId);
    const message = messagesById.get(Number(row.last_id));
    if (!card || !message) continue;
    out.push({
      peer: card,
      lastMessage: String(message.body || ''),
      lastAt: message.created_at,
      unread: unreadByPeer.get(peerId) || 0
    });
  }
  res.json({
    ok: true,
    page: page,
    pageSize: PAGE_SIZE,
    total: Number(totalRow && totalRow.c) || 0,
    rows: out
  });
});

// ── 与某人的私信记录（只返回双方消息；读取即把对方发来的未读置已读） ──
router.get('/messages/:studentId', requireStudentApi, (req, res) => {
  const sid = req.student.id;
  const peerId = positiveId(req.params.studentId);
  if (!peerId) return fail(res, 404, '用户不存在');
  if (peerId === sid) return fail(res, 400, '不能和自己私信');
  if (!studentExists(peerId)) return fail(res, 404, '用户不存在');

  const before = intParam(req.query.before, 0, 0, Number.MAX_SAFE_INTEGER);
  const limit = intParam(req.query.limit, MESSAGE_PAGE_LIMIT_DEFAULT, 1, MESSAGE_PAGE_LIMIT_MAX);
  let sql =
    'SELECT id, sender_id, receiver_id, body, is_read, created_at FROM community_messages' +
    ' WHERE ((sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?))';
  const params = [sid, peerId, peerId, sid];
  if (before > 0) {
    sql += ' AND id < ?';
    params.push(before);
  }
  sql += ' ORDER BY id DESC LIMIT ?';
  params.push(limit);
  const rows = db.query(sql, params).reverse();

  db.run('UPDATE community_messages SET is_read=1 WHERE sender_id=? AND receiver_id=? AND is_read=0', [peerId, sid]);

  res.json({
    ok: true,
    peer: loadIdentityCard(peerId, sid),
    rows: rows.map(row => ({
      id: Number(row.id),
      senderId: Number(row.sender_id),
      body: String(row.body || ''),
      isMine: Number(row.sender_id) === sid,
      createdAt: row.created_at
    }))
  });
});

// ── 私信发送限流：每学员 20 条/分钟、200 条/天（进程内 Map，带过期清理） ──
const minuteBuckets = new Map();
const dayBuckets = new Map();

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function allowSendMessage(studentId) {
  const now = Date.now();
  // 回收过期的分钟桶，避免 Map 无界增长。
  for (const [key, times] of minuteBuckets) {
    const alive = times.filter(stamp => now - stamp < MESSAGE_MINUTE_WINDOW_MS);
    if (alive.length) minuteBuckets.set(key, alive);
    else minuteBuckets.delete(key);
  }
  // 回收非当天的日桶。
  const day = todayKey();
  for (const key of Array.from(dayBuckets.keys())) {
    if (!key.endsWith(':' + day)) dayBuckets.delete(key);
  }

  const times = minuteBuckets.get(studentId) || [];
  if (times.length >= MESSAGE_PER_MINUTE) return { ok: false, reason: 'minute' };
  const dayKey = studentId + ':' + day;
  if ((dayBuckets.get(dayKey) || 0) >= MESSAGE_PER_DAY) return { ok: false, reason: 'day' };

  times.push(now);
  minuteBuckets.set(studentId, times);
  dayBuckets.set(dayKey, (dayBuckets.get(dayKey) || 0) + 1);
  return { ok: true };
}

function charLength(text) {
  return Array.from(String(text == null ? '' : text)).length;
}

// 私信正文规则：1–500 字，等价于 filter.checkComment 的纯文本校验 + filter.scan（联系方式/违规词）。
function checkMessageBody(body) {
  if (typeof body !== 'string') return { ok: false, error: '消息格式不正确' };
  const text = body.trim();
  const len = charLength(text);
  if (len < MESSAGE_MIN_LENGTH) return { ok: false, error: '请输入消息内容' };
  if (len > MESSAGE_MAX_LENGTH) return { ok: false, error: '消息最多 500 个字' };
  const safe = filter.scan(text);
  if (!safe.ok) return { ok: false, error: safe.reason };
  return { ok: true, body: text };
}

// ── 发送私信 ──
router.post('/messages/:studentId', requireStudentApi, (req, res) => {
  const sid = req.student.id;
  const peerId = positiveId(req.params.studentId);
  if (!peerId) return fail(res, 404, '用户不存在');
  if (peerId === sid) return fail(res, 400, '不能给自己发私信');
  if (!studentExists(peerId)) return fail(res, 404, '用户不存在');

  const allowed = allowSendMessage(sid);
  if (!allowed.ok) {
    return fail(res, 429, allowed.reason === 'day' ? '今日私信已达上限，请明天再试' : '发送太频繁，请稍后再试');
  }

  const checked = checkMessageBody(req.body && req.body.body);
  if (!checked.ok) return fail(res, 400, checked.error);

  const id = db.run(
    'INSERT INTO community_messages (sender_id, receiver_id, body, is_read) VALUES (?,?,?,0)',
    [sid, peerId, checked.body]
  );
  const row = db.get(
    'SELECT id, sender_id, receiver_id, body, is_read, created_at FROM community_messages WHERE id=?',
    [id]
  );
  res.json({
    ok: true,
    message: {
      id: Number(row.id),
      senderId: Number(row.sender_id),
      receiverId: Number(row.receiver_id),
      body: String(row.body || ''),
      isMine: true,
      createdAt: row.created_at
    }
  });
});

module.exports = router;
