const express = require('express');
const fs = require('fs');
const path = require('path');
const db = require('../db');
const provinceScope = require('../lib/practice-scope');
const { currentStudent, requireStudentApi } = require('../middleware/student-auth');

const router = express.Router();

const EXAM_DURATION = 600;
const DEFAULT_EXAM_COUNT = 8;
const MAX_EXAM_COUNT = 30;
const DEFAULT_LIMIT = 50;
const MAX_LIMIT = 100;
const MAX_PAGE_SIZE = 50;

router.use(function (req, res, next) {
  res.set('Cache-Control', 'no-store');
  next();
});

// Public interface metadata only; questions and student records remain private.
router.get('/catalog', handle(function (req, res) {
  const scope = provinceScope.resolve(db, req.query.province);
  const subjects = scope ? Array.from(new Set(scope.entries.map(row => row.name))) : Array.from(new Set(loadQuestions(null).map(row => row.subject).filter(Boolean)));
  res.json({ ok: true, subjects });
}));

router.use(requireStudentApi);

router.use('/papers', require('./past-papers'));

// ── 通用小工具 ──

function fail(res, status, error) {
  return res.status(status).json({ ok: false, error: error });
}

// 同步处理器统一包一层，异常返回 JSON 500。
function handle(fn) {
  return function (req, res) {
    try {
      return fn(req, res);
    } catch (error) {
      console.error('[practice]', error && error.message);
      if (!res.headersSent) fail(res, error.status === 400 ? 400 : 500, error.status === 400 ? error.message : '服务器错误');
      return undefined;
    }
  };
}

function positiveInt(value) {
  if (!/^[1-9]\d*$/.test(String(value))) return null;
  const n = Number(value);
  return Number.isSafeInteger(n) ? n : null;
}

// 选项下标：只接受 0-3 的整数（允许纯数字字符串）；无法识别返回 null。
function choice(value) {
  const n = typeof value === 'string' && /^\d+$/.test(value) ? Number(value) : value;
  if (typeof n !== 'number' || !Number.isInteger(n) || n < 0 || n > 3) return null;
  return n;
}

function bodyOf(req) {
  const body = req.body;
  if (!body || typeof body !== 'object' || Array.isArray(body)) return null;
  return body;
}

// ── 题库读取 ──

function parseOptions(raw) {
  if (Array.isArray(raw)) return raw.map(function (o) { return String(o); });
  try {
    const list = JSON.parse(raw || '[]');
    return Array.isArray(list) ? list.map(function (o) { return String(o); }) : [];
  } catch (error) {
    return [];
  }
}

function normalizeQuestion(row, fallbackId) {
  return {
    id: positiveInt(row.id) || fallbackId,
    subject: String(row.subject || '').trim(),
    lessonId: Number(row.lesson_id) || 0,
    provinceCode: String(row.province_code || '').trim(),
    content: String(row.content || ''),
    options: parseOptions(row.options),
    answer: Number(row.answer) || 0,
    explanation: String(row.explanation || '')
  };
}

// 表为空时回退 data/questions.json；文件缺失按空题库处理。
function fallbackQuestions() {
  try {
    const file = path.join(__dirname, '..', 'data', 'questions.json');
    const list = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!Array.isArray(list)) return [];
    return list.map(function (row, index) { return normalizeQuestion(row, index + 1); });
  } catch (error) {
    return [];
  }
}

function loadQuestions(scope) {
  let rows = [];
  try {
    rows = db.query('SELECT * FROM questions ORDER BY id') || [];
  } catch (error) {
    rows = [];
  }
  const questions = rows.length ? rows.map(function (row, index) { return normalizeQuestion(row, index + 1); }) : fallbackQuestions();
  return provinceScope.filter(questions, scope);
}

function publicQuestion(question) {
  return {
    id: question.id,
    subject: question.subject,
    content: question.content,
    options: question.options.slice(),
    lessonId: question.lessonId
  };
}

function examQuestion(question) {
  return {
    id: question.id,
    subject: question.subject,
    content: question.content,
    options: question.options.slice()
  };
}

// ── 写入助手（都在调用方的 db.atomic 内执行） ──

function insertAttempt(studentId, questionId, selected, correct, mode, examId) {
  db.run('INSERT INTO practice_attempts (student_id, question_id, selected, correct, mode, exam_id) VALUES (?,?,?,?,?,?)',
    [studentId, questionId, selected, correct ? 1 : 0, mode, examId === undefined ? null : examId]);
}

function markWrong(studentId, questionId) {
  const existing = db.get('SELECT student_id FROM practice_wrong_book WHERE student_id=? AND question_id=?', [studentId, questionId]);
  if (existing) {
    db.run('UPDATE practice_wrong_book SET wrong_count=wrong_count+1, last_wrong_at=CURRENT_TIMESTAMP, resolved=0 WHERE student_id=? AND question_id=?', [studentId, questionId]);
  } else {
    db.run('INSERT INTO practice_wrong_book (student_id, question_id, wrong_count, resolved) VALUES (?,?,1,0)', [studentId, questionId]);
  }
}

// ── GET /questions：题目列表（绝不返回 answer/explanation） ──

router.get('/questions', handle(function (req, res) {
  const scope = provinceScope.resolve(db, req.query.province);
  const all = loadQuestions(scope);
  const subject = typeof req.query.subject === 'string' ? req.query.subject.trim() : '';

  let lessonId = null;
  if (req.query.lesson_id !== undefined && String(req.query.lesson_id).trim() !== '') {
    const parsed = Number(req.query.lesson_id);
    if (!Number.isInteger(parsed) || parsed < 0) return fail(res, 400, '课时参数无效');
    lessonId = parsed;
  }

  let limit = DEFAULT_LIMIT;
  if (req.query.limit !== undefined && String(req.query.limit).trim() !== '') {
    const parsed = Number(req.query.limit);
    if (!Number.isInteger(parsed) || parsed <= 0) return fail(res, 400, '题目数量无效');
    limit = Math.min(parsed, MAX_LIMIT);
  }

  const subjects = scope ? Array.from(new Set(scope.entries.map(row => row.name))) : [];
  all.forEach(function (question) {
    if (question.subject && subjects.indexOf(question.subject) < 0) subjects.push(question.subject);
  });

  const offset = req.query.offset === undefined ? 0 : Number(req.query.offset);
  if (!Number.isSafeInteger(offset) || offset < 0) return fail(res, 400, '题目位置无效');

  const matched = all.filter(function (question) {
    if (subject && question.subject !== subject) return false;
    if (lessonId !== null && Number(question.lessonId) !== lessonId) return false;
    return true;
  });

  res.json({
    ok: true,
    province: scope ? { code: scope.code, name: scope.name } : null,
    subjects: subjects,
    total: matched.length,
    offset: offset,
    lessonIds: Array.from(new Set(all.map(q => q.lessonId).filter(id => id > 0))),
    subjectCounts: subjects.map(subject => ({ subject, total: all.filter(q => q.subject === subject).length })),
    questions: matched.slice(offset, offset + limit).map(publicQuestion)
  });
}));

// ── POST /answer：服务端判分，游客可用；登录时记录流水与错题本 ──

router.post('/answer', handle(function (req, res) {
  const body = bodyOf(req);
  if (!body) return fail(res, 400, '请求参数无效');
  const questionId = positiveInt(body.questionId);
  if (!questionId) return fail(res, 400, '题目编号无效');
  const selected = choice(body.selected);
  if (selected === null) return fail(res, 400, '答案选项无效');

  const scope = provinceScope.resolve(db, body.province);
  const question = loadQuestions(scope).find(function (item) { return item.id === questionId; });
  if (!question) return fail(res, 404, '题目不存在');

  const student = currentStudent(req);
  // 防作弊：本人正在进行的模考包含该题时，公开判分接口不返回答案与解析。
  if (student) {
    const openExamItem = db.get(
      "SELECT 1 AS x FROM practice_exam_items i JOIN practice_exams e ON e.id = i.exam_id WHERE e.student_id=? AND e.status='open' AND e.created_at > datetime('now', '-10 minutes') AND i.question_id=? LIMIT 1",
      [student.id, question.id]
    );
    if (openExamItem) return fail(res, 409, '模考进行中，交卷后可查看该题答案与解析');
  }

  const correct = selected === question.answer;
  if (student) {
    db.atomic(function () {
      insertAttempt(student.id, question.id, selected, correct, 'practice', null);
      if (!correct) markWrong(student.id, question.id);
    });
  }

  res.json({ ok: true, correct: correct, answer: question.answer, explanation: question.explanation });
}));

// ── POST /exam/start：服务端出卷，返回不含答案的题目 ──

router.post('/exam/start', requireStudentApi, handle(function (req, res) {
  const body = bodyOf(req) || {};

  let count = DEFAULT_EXAM_COUNT;
  if (body.count !== undefined && body.count !== null) {
    const parsed = Number(body.count);
    if (!Number.isInteger(parsed) || parsed < 1 || parsed > MAX_EXAM_COUNT) return fail(res, 400, '考试题数需为 1-30 的整数');
    count = parsed;
  }

  const subject = typeof body.subject === 'string' ? body.subject.trim() : '';
  const scope = provinceScope.resolve(db, body.province);
  let pool = loadQuestions(scope);
  if (subject) pool = pool.filter(function (question) { return question.subject === subject; });
  if (!pool.length) return fail(res, 400, '题库暂无可用题目');

  const picked = shuffle(pool).slice(0, Math.min(count, pool.length));
  const examId = db.atomic(function () {
    const id = db.run('INSERT INTO practice_exams (student_id, question_count, score, duration_seconds, status) VALUES (?,?,0,0,?)',
      [req.student.id, picked.length, 'open']);
    picked.forEach(function (question, position) {
      db.run('INSERT INTO practice_exam_items (exam_id, question_id, position, selected, correct) VALUES (?,?,?,NULL,NULL)',
        [id, question.id, position]);
    });
    return id;
  });

  res.json({
    ok: true,
    exam: { id: examId, questionCount: picked.length, durationSeconds: EXAM_DURATION, province: scope ? { code: scope.code, name: scope.name } : null },
    questions: picked.map(examQuestion)
  });
}));

function shuffle(list) {
  const copy = list.slice();
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = copy[i];
    copy[i] = copy[j];
    copy[j] = tmp;
  }
  return copy;
}

// ── POST /exam/:id/submit：只认快照题目与顺序，服务端判分 ──

router.post('/exam/:id/submit', requireStudentApi, handle(function (req, res) {
  const examId = positiveInt(req.params.id);
  if (!examId) return fail(res, 400, '考试编号无效');

  const exam = db.get('SELECT id, student_id, status FROM practice_exams WHERE id=?', [examId]);
  if (!exam || Number(exam.student_id) !== req.student.id) return fail(res, 404, '考试不存在');
  if (exam.status !== 'open') return fail(res, 409, '本次考试已交卷');

  const body = bodyOf(req);
  if (!body) return fail(res, 400, '请求参数无效');

  if (body.answers !== undefined && !Array.isArray(body.answers)) return fail(res, 400, '答案数据无效');
  const answers = Array.isArray(body.answers) ? body.answers : [];
  const selectedByQuestion = new Map();
  for (const entry of answers) {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return fail(res, 400, '答案数据无效');
    const questionId = positiveInt(entry.questionId);
    if (!questionId) return fail(res, 400, '答案数据无效');
    let selected = null;
    if (entry.selected !== undefined && entry.selected !== null) {
      selected = choice(entry.selected);
      if (selected === null) return fail(res, 400, '答案选项无效');
    }
    selectedByQuestion.set(questionId, selected);
  }

  let duration = 0;
  if (body.durationSeconds !== undefined && body.durationSeconds !== null) {
    const parsed = Number(body.durationSeconds);
    if (!Number.isFinite(parsed)) return fail(res, 400, '用时无效');
    duration = Math.min(Math.max(0, Math.round(parsed)), 3600);
  }

  const items = db.query('SELECT question_id, position FROM practice_exam_items WHERE exam_id=? ORDER BY position', [examId]);
  const questionById = new Map();
  loadQuestions().forEach(function (question) { questionById.set(question.id, question); });

  let score = 0;
  const review = [];
  db.atomic(function () {
    items.forEach(function (item) {
      const questionId = Number(item.question_id);
      const question = questionById.get(questionId);
      const selected = selectedByQuestion.has(questionId) ? selectedByQuestion.get(questionId) : null;
      const correct = Boolean(question) && selected !== null && selected === question.answer;
      if (correct) score += 1;

      db.run('UPDATE practice_exam_items SET selected=?, correct=? WHERE exam_id=? AND position=?',
        [selected, correct ? 1 : 0, examId, item.position]);
      insertAttempt(req.student.id, questionId, selected, correct, 'exam', examId);
      if (!correct) markWrong(req.student.id, questionId);

      review.push({
        questionId: questionId,
        subject: question ? question.subject : '',
        content: question ? question.content : '题目已下架',
        options: question ? question.options.slice() : [],
        selected: selected === undefined ? null : selected,
        correct: correct,
        answer: question ? question.answer : null,
        explanation: question ? question.explanation : ''
      });
    });

    db.run("UPDATE practice_exams SET score=?, duration_seconds=?, status='submitted', submitted_at=CURRENT_TIMESTAMP WHERE id=?",
      [score, duration, examId]);
  });

  res.json({
    ok: true,
    result: { examId: examId, score: score, total: items.length, durationSeconds: duration, items: review }
  });
}));

// ── GET /stats：总答题、正确率、按科目、连续天数、近期模考 ──

router.get('/stats', requireStudentApi, handle(function (req, res) {
  const studentId = req.student.id;
  const scope = provinceScope.resolve(db, req.query.province);
  const questionById = new Map(loadQuestions(scope).map(q => [q.id, q]));
  const attempts = db.query("SELECT question_id, correct, date(created_at,'+8 hours') AS day FROM practice_attempts WHERE student_id=?", [studentId])
    .filter(row => !scope || questionById.has(Number(row.question_id)));
  const total = attempts.length;
  const correct = attempts.reduce((sum, row) => sum + Number(row.correct), 0);
  const currentDay = new Date(Date.now() + 8 * 3600000).toISOString().slice(0, 10);
  const todayAttempts = attempts.filter(row => row.day === currentDay);
  const today = { total: todayAttempts.length, correct: todayAttempts.reduce((sum, row) => sum + Number(row.correct), 0) };
  const wrong = db.query('SELECT question_id FROM practice_wrong_book WHERE student_id=? AND resolved=0', [studentId])
    .filter(row => !scope || questionById.has(Number(row.question_id)));
  const groups = new Map();
  attempts.forEach(row => {
    const question = questionById.get(Number(row.question_id));
    const subject = question ? question.subject : '已下架题目';
    const group = groups.get(subject) || { subject, total: 0, correct: 0 };
    group.total += 1; group.correct += Number(row.correct);
    groups.set(subject, group);
  });
  const bySubject = Array.from(groups.values()).sort((a, b) => b.total - a.total || a.subject.localeCompare(b.subject)).map(row => ({
    ...row, accuracy: row.total ? Math.round(row.correct / row.total * 100) : 0
  }));
  const days = new Set(attempts.map(row => row.day));
  let streakDays = 0;
  let cursor = currentDay;
  if (!days.has(cursor)) cursor = shiftDay(cursor, -1);
  while (days.has(cursor)) { streakDays += 1; cursor = shiftDay(cursor, -1); }
  const examRows = db.query("SELECT id, score, question_count, created_at FROM practice_exams WHERE student_id=? AND status='submitted' ORDER BY id DESC", [studentId])
    .filter(exam => !scope || db.query('SELECT question_id FROM practice_exam_items WHERE exam_id=?', [exam.id]).every(row => questionById.has(Number(row.question_id))))
    .slice(0, 10);

  res.json({
    ok: true,
    total: total,
    correct: correct,
    accuracy: total ? Math.round(correct / total * 100) : 0,
    today: { total: Number(today.total) || 0, correct: Number(today.correct) || 0 },
    wrongCount: wrong.length,
    streakDays: streakDays,
    bySubject: bySubject,
    exams: examRows.map(function (row) {
      return { id: Number(row.id), score: Number(row.score) || 0, total: Number(row.question_count) || 0, createdAt: String(row.created_at || '') };
    })
  });
}));

function shiftDay(day, delta) {
  const parts = day.split('-').map(Number);
  const stamp = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2] + delta));
  return stamp.toISOString().slice(0, 10);
}

// ── GET /wrong-book：未掌握错题分页 ──

router.get('/wrong-book', requireStudentApi, handle(function (req, res) {
  const studentId = req.student.id;
  const subject = typeof req.query.subject === 'string' ? req.query.subject.trim() : '';

  let page = 1;
  if (req.query.page !== undefined && String(req.query.page).trim() !== '') {
    const parsed = Number(req.query.page);
    if (!Number.isInteger(parsed) || parsed < 1 || parsed > 100000) return fail(res, 400, '页码无效');
    page = parsed;
  }
  let pageSize = 10;
  if (req.query.pageSize !== undefined && String(req.query.pageSize).trim() !== '') {
    const parsed = Number(req.query.pageSize);
    if (!Number.isInteger(parsed) || parsed < 1) return fail(res, 400, '每页数量无效');
    pageSize = Math.min(parsed, MAX_PAGE_SIZE);
  }

  const scope = provinceScope.resolve(db, req.query.province);
  const questionById = new Map(loadQuestions(scope).map(q => [q.id, q]));
  const matched = db.query('SELECT question_id, wrong_count, last_wrong_at FROM practice_wrong_book WHERE student_id=? AND resolved=0 ORDER BY last_wrong_at DESC, question_id DESC', [studentId])
    .map(row => {
      const q = questionById.get(Number(row.question_id));
      return q ? { ...row, subject: q.subject, content: q.content, options: q.options } : null;
    }).filter(row => row && (!subject || row.subject === subject));
  const total = matched.length;
  const rows = matched.slice((page - 1) * pageSize, page * pageSize);

  res.json({
    ok: true,
    total: total,
    page: page,
    pageSize: pageSize,
    rows: rows.map(function (row) {
      return {
        questionId: Number(row.question_id),
        subject: String(row.subject || ''),
        content: String(row.content || ''),
        options: parseOptions(row.options),
        wrongCount: Number(row.wrong_count) || 0,
        lastWrongAt: String(row.last_wrong_at || '')
      };
    })
  });
}));

// ── POST /wrong-book/:questionId/resolve：标记已掌握 ──

router.post('/wrong-book/:questionId/resolve', requireStudentApi, handle(function (req, res) {
  const questionId = positiveInt(req.params.questionId);
  if (!questionId) return fail(res, 400, '题目编号无效');
  const scope = provinceScope.resolve(db, bodyOf(req) && req.body.province);
  if (scope && !loadQuestions(scope).some(q => q.id === questionId)) return fail(res, 404, '当前省份没有该错题');
  const existing = db.get('SELECT question_id FROM practice_wrong_book WHERE student_id=? AND question_id=?', [req.student.id, questionId]);
  if (!existing) return fail(res, 404, '错题不存在');
  db.run('UPDATE practice_wrong_book SET resolved=1 WHERE student_id=? AND question_id=?', [req.student.id, questionId]);
  res.json({ ok: true });
}));

router.use(function (req, res) {
  fail(res, 404, '接口不存在');
});

module.exports = router;
