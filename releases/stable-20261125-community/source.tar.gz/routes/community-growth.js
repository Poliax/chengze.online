// 社区 v2 成长模块学员端接口，挂载 /api/community。
// 职责：每日打卡 / 积分等级 / 排行榜 / 身份卡 / 资料完善。
// 依赖 Lead 已写好的 lib/community-growth（服务端权威积分，带每日上限），不重复实现。
const express = require('express');
const router = express.Router();
const db = require('../db');
const filter = require('../lib/community-filter');
const growth = require('../lib/community-growth');
const { currentStudent, requireStudentApi } = require('../middleware/student-auth');

const LEADERBOARD_DEFAULT = 50;
const LEADERBOARD_MAX = 100;
const PROFILE_POST_LIMIT = 10;
const CHECKIN_NOTE_MAX = 200;
const NICKNAME_MAX = 20;
const TARGET_MAX = 40;
const BIO_MAX = 100;
const STUDY_TAG_MAX = 5;

// 学习标签白名单（个人资料；与「找搭子」匹配共用）。
const STUDY_TAGS = ['英语', '高数', '语文', '计算机', '政治', '管理学', '教育学', '医学', '会计', '经济学', '法学', '艺术', '体育'];

router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

// All community content requires an active student session.
router.use(requireStudentApi);

function fail(res, status, error) {
  return res.status(status).json({ ok: false, error });
}

function intParam(raw, fallback, min, max) {
  const n = parseInt(raw, 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function positiveId(raw) {
  const text = String(raw == null ? '' : raw);
  if (!/^[1-9]\d*$/.test(text)) return null;
  const n = Number(text);
  return Number.isSafeInteger(n) ? n : null;
}

function charLength(text) {
  return Array.from(String(text == null ? '' : text)).length;
}

function readTags(raw) {
  try {
    const list = JSON.parse(raw || '[]');
    if (!Array.isArray(list)) return [];
    return list.filter(t => typeof t === 'string');
  } catch (e) {
    return [];
  }
}

function readStudyTags(raw) {
  try {
    const list = JSON.parse(raw || '[]');
    if (!Array.isArray(list)) return [];
    return list.filter(t => typeof t === 'string' && t.trim()).map(t => t.trim());
  } catch (e) {
    return [];
  }
}

// ── 身份卡（字段与社交模块 5.1 完全一致，不返回手机号/邮箱等敏感字段） ──
const IDENTITY_SELECT = `SELECT s.id, s.name, s.nickname, s.avatar, s.gender, s.province_code, s.exam_year,
  s.target_school, s.target_major, s.bio, s.study_tags, s.status,
  COALESCE(g.points, 0) AS points,
  (SELECT COUNT(*) FROM community_follows f WHERE f.following_id = s.id) AS followers,
  (SELECT COUNT(*) FROM community_follows f WHERE f.follower_id = s.id) AS following_count,
  (SELECT COUNT(*) FROM community_posts p WHERE p.student_id = s.id AND p.status = 'published' AND (p.is_anonymous = 0 OR s.id = ?)) AS post_count,
  EXISTS(SELECT 1 FROM community_follows f WHERE f.follower_id = ? AND f.following_id = s.id) AS following_him,
  EXISTS(SELECT 1 FROM community_follows f WHERE f.follower_id = s.id AND f.following_id = ?) AS following_me
  FROM students s LEFT JOIN student_growth g ON g.student_id = s.id WHERE s.id = ?`;

function provinceNameOf(code) {
  const value = String(code == null ? '' : code).trim();
  if (!value) return '';
  try {
    const row = db.get('SELECT name FROM provinces WHERE code = ?', [value]);
    return row ? String(row.name || '') : '';
  } catch (e) {
    // provinces 表可能不存在（精简部署/测试环境），名称留空即可，不影响身份卡。
    return '';
  }
}

function loadIdentityCard(targetId, viewerId) {
  const viewer = Number(viewerId) || 0;
  const row = db.get(IDENTITY_SELECT, [viewer, viewer, viewer, targetId]);
  if (!row || row.status === 'disabled') return null;
  const points = Number(row.points) || 0;
  const info = growth.levelFor(points);
  return {
    id: Number(row.id),
    name: filter.displayName({ name: row.name, nickname: row.nickname }),
    avatar: row.avatar || '',
    gender: row.gender || 'unknown',
    provinceCode: row.province_code || '',
    provinceName: provinceNameOf(row.province_code),
    examYear: row.exam_year || '',
    targetSchool: row.target_school || '',
    targetMajor: row.target_major || '',
    bio: row.bio || '',
    studyTags: readStudyTags(row.study_tags),
    level: info.level,
    levelTitle: info.title,
    points: points,
    followers: Number(row.followers) || 0,
    following: Number(row.following_count) || 0,
    posts: Number(row.post_count) || 0,
    followingMe: !!Number(row.following_me),
    followingHim: !!Number(row.following_him),
    isSelf: viewer > 0 && viewer === Number(row.id)
  };
}

// ── 帖子序列化（与内容模块 4.1 规则一致；匿名帖不返回真实 authorId/昵称/头像） ──
const PROFILE_POST_SELECT = `SELECT p.*, s.name AS s_name, s.nickname AS s_nickname, s.gender AS s_gender, s.avatar AS s_avatar,
  COALESCE(g.points, 0) AS author_points,
  EXISTS(SELECT 1 FROM community_likes l WHERE l.post_id = p.id AND l.student_id = ?) AS liked,
  EXISTS(SELECT 1 FROM community_favorites f WHERE f.post_id = p.id AND f.student_id = ?) AS favorited
  FROM community_posts p
  LEFT JOIN students s ON s.id = p.student_id
  LEFT JOIN student_growth g ON g.student_id = p.student_id
  WHERE p.student_id = ? AND p.status = 'published'
    AND (p.expires_at IS NULL OR p.expires_at = '' OR p.expires_at > CURRENT_TIMESTAMP)
    AND (p.is_anonymous = 0 OR p.student_id = ?)
  ORDER BY p.created_at DESC, p.id DESC LIMIT ?`;

function mapPost(row, viewerId) {
  const anonymous = Number(row.is_anonymous) === 1;
  const ownerId = Number(row.student_id);
  const points = Number(row.author_points) || 0;
  return {
    id: Number(row.id),
    body: row.body,
    tags: readTags(row.tags),
    kind: row.kind || 'post',
    isAnonymous: anonymous,
    likeCount: Number(row.like_count) || 0,
    commentCount: Number(row.comment_count) || 0,
    favoriteCount: Number(row.favorite_count) || 0,
    liked: !!Number(row.liked),
    favorited: !!Number(row.favorited),
    isMine: !!viewerId && ownerId === Number(viewerId),
    createdAt: row.created_at,
    expiresAt: row.expires_at || '',
    authorId: anonymous ? 0 : ownerId,
    authorName: anonymous ? '匿名同学' : filter.displayName({ name: row.s_name, nickname: row.s_nickname }),
    authorAvatar: anonymous ? '' : (row.s_avatar || ''),
    authorGender: anonymous ? 'unknown' : (row.s_gender || 'unknown'),
    // 匿名帖连等级也隐藏，避免与发帖历史组合出身份线索。
    authorLevel: anonymous ? 0 : growth.levelFor(points).level
  };
}

function loadProfilePosts(targetId, viewerId) {
  const viewer = Number(viewerId) || 0;
  const rows = db.query(PROFILE_POST_SELECT, [viewer, viewer, targetId, viewer, PROFILE_POST_LIMIT]);
  return rows.map(row => mapPost(row, viewer));
}

// 排名：比"我的分数"严格高的人数 + 1（未上榜也返回；与榜单同用并列名次口径）。
function rankOf(studentId, period) {
  const summary = growth.summary(db, studentId);
  if (period === 'week') {
    const row = db.get(
      "SELECT COUNT(*) AS c FROM student_growth g JOIN students s ON s.id = g.student_id " +
      "WHERE COALESCE(s.status, 'active') <> 'disabled' AND g.week_key = ? AND g.week_points > ?",
      [growth.weekKey(), summary.weekPoints]
    );
    return { rank: (Number(row && row.c) || 0) + 1, points: summary.weekPoints };
  }
  const row = db.get(
    "SELECT COUNT(*) AS c FROM student_growth g JOIN students s ON s.id = g.student_id " +
    "WHERE COALESCE(s.status, 'active') <> 'disabled' AND g.points > ?",
    [summary.points]
  );
  return { rank: (Number(row && row.c) || 0) + 1, points: summary.points };
}

// ── 每日打卡 ──
router.post('/checkin', requireStudentApi, (req, res) => {
  const sid = req.student.id;
  const rawNote = req.body ? req.body.note : undefined;
  let note = '';
  if (rawNote !== undefined && rawNote !== null) {
    if (typeof rawNote !== 'string') return fail(res, 400, '打卡内容格式不正确');
    note = rawNote.trim();
    if (charLength(note) > CHECKIN_NOTE_MAX) return fail(res, 400, '打卡内容最多 200 个字');
    const safe = filter.scan(note);
    if (!safe.ok) return fail(res, 400, safe.reason);
  }

  let result;
  try {
    result = db.atomic(() => growth.recordCheckin(db, sid, growth.today(), note));
  } catch (error) {
    return fail(res, 500, '服务器繁忙，请稍后再试');
  }
  if (result.duplicate) return fail(res, 409, '今天已经打过卡了');

  const summary = growth.summary(db, sid);
  return res.json({
    ok: true,
    streak: result.streak,
    checkinTotal: summary.checkinTotal,
    points: summary.points,
    level: summary.level,
    levelTitle: summary.levelTitle,
    weekPoints: summary.weekPoints,
    awarded: Number(result.growth && result.growth.awarded) || 0
  });
});

// ── 今日打卡状态 + 近 14 天记录 ──
router.get('/checkin/status', requireStudentApi, (req, res) => {
  const sid = req.student.id;
  try {
    const summary = growth.summary(db, sid);
    const recent = growth.recentCheckins(db, sid, 14).map(row => ({
      day: row.day,
      note: row.note || ''
    }));
    return res.json({
      ok: true,
      checkedToday: summary.checkedToday,
      streak: summary.checkinStreak,
      checkinTotal: summary.checkinTotal,
      recent: recent
    });
  } catch (error) {
    return fail(res, 500, '服务器繁忙，请稍后再试');
  }
});

// ── 我的成长概览（前端「我的」需要 studentId，故响应额外返回 studentId） ──
router.get('/growth/me', requireStudentApi, (req, res) => {
  const sid = req.student.id;
  try {
    const summary = growth.summary(db, sid);
    const weekRank = rankOf(sid, 'week');
    const allRank = rankOf(sid, 'all');
    const nextLevelPoints = summary.nextLevelPoints === null || summary.nextLevelPoints === undefined
      ? null
      : Number(summary.nextLevelPoints);
    return res.json({
      ok: true,
      studentId: sid,
      name: filter.displayName(req.student),
      avatar: req.student.avatar || '',
      gender: req.student.gender || 'unknown',
      points: summary.points,
      weekPoints: summary.weekPoints,
      todayPoints: summary.todayPoints,
      level: summary.level,
      levelTitle: summary.levelTitle,
      nextLevelPoints: nextLevelPoints,
      nextLevelTitle: summary.nextLevelTitle,
      pointsToNextLevel: nextLevelPoints === null ? 0 : Math.max(0, nextLevelPoints - summary.points),
      checkinStreak: summary.checkinStreak,
      checkinTotal: summary.checkinTotal,
      lastCheckinDay: summary.lastCheckinDay,
      checkedToday: summary.checkedToday,
      rankWeek: weekRank.rank,
      rankAll: allRank.rank
    });
  } catch (error) {
    return fail(res, 500, '服务器繁忙，请稍后再试');
  }
});

// ── 排行榜：周榜（week_points 且 week_key 为当周）/ 总榜（points） ──
const WEEK_BOARD_SELECT = `SELECT g.student_id, g.week_points AS score, g.points AS total_points,
  g.level AS growth_level, s.name AS s_name, s.nickname AS s_nickname, s.gender AS s_gender, s.avatar AS s_avatar
  FROM student_growth g JOIN students s ON s.id = g.student_id
  WHERE COALESCE(s.status, 'active') <> 'disabled' AND g.week_key = ? AND g.week_points > 0
  ORDER BY g.week_points DESC, g.points DESC, g.student_id ASC LIMIT ?`;

const ALL_BOARD_SELECT = `SELECT g.student_id, g.points AS score, g.points AS total_points,
  g.level AS growth_level, s.name AS s_name, s.nickname AS s_nickname, s.gender AS s_gender, s.avatar AS s_avatar
  FROM student_growth g JOIN students s ON s.id = g.student_id
  WHERE COALESCE(s.status, 'active') <> 'disabled' AND g.points > 0
  ORDER BY g.points DESC, g.student_id ASC LIMIT ?`;

router.get('/leaderboard', (req, res) => {
  const period = req.query.period === 'week' ? 'week' : 'all';
  const limit = intParam(req.query.limit, LEADERBOARD_DEFAULT, 1, LEADERBOARD_MAX);
  try {
    const rows = period === 'week'
      ? db.query(WEEK_BOARD_SELECT, [growth.weekKey(), limit])
      : db.query(ALL_BOARD_SELECT, [limit]);
    // 并列名次：分数相同的名次相同，后续名次按序号（1,2,3,3,5）。
    let lastScore = null;
    let lastRank = 0;
    const mapped = rows.map((row, index) => {
      const score = Number(row.score) || 0;
      const rank = score === lastScore ? lastRank : index + 1;
      lastScore = score;
      lastRank = rank;
      const info = growth.levelFor(Number(row.total_points) || 0);
      return {
        rank: rank,
        studentId: Number(row.student_id),
        name: filter.displayName({ name: row.s_name, nickname: row.s_nickname }),
        avatar: row.s_avatar || '',gender:row.s_gender||'unknown',
        level: info.level,
        levelTitle: info.title,
        points: score
      };
    });

    const viewer = currentStudent(req);
    let me = null;
    if (viewer) {
      const mine = rankOf(viewer.id, period);
      const summary = growth.summary(db, viewer.id);
      me = {
        rank: mine.rank,
        points: mine.points,
        level: summary.level,
        levelTitle: summary.levelTitle
      };
    }
    return res.json({ ok: true, period: period, rows: mapped, me: me });
  } catch (error) {
    return fail(res, 500, '服务器繁忙，请稍后再试');
  }
});

// ── 身份卡 + 最近 10 条帖子 ──
router.get('/profile/:studentId', (req, res) => {
  const targetId = positiveId(req.params.studentId);
  if (!targetId) return fail(res, 404, '用户不存在');
  const viewer = currentStudent(req);
  const viewerId = viewer ? viewer.id : 0;

  let card;
  let posts;
  try {
    card = loadIdentityCard(targetId, viewerId);
    if (!card) return fail(res, 404, '用户不存在');
    posts = loadProfilePosts(targetId, viewerId);
  } catch (error) {
    return fail(res, 500, '服务器繁忙，请稍后再试');
  }
  let checkedToday = false;
  if (card.isSelf) {
    try {
      checkedToday = growth.summary(db, targetId).checkedToday;
    } catch (error) {
      checkedToday = false;
    }
  }
  return res.json({ ok: true, profile: card, posts: posts, checkedToday: checkedToday });
});

// ── 资料完善：只改自己（无 studentId 参数），长度与标签白名单校验 ──
router.patch('/me/profile', requireStudentApi, (req, res) => {
  const sid = req.student.id;
  const body = req.body || {};
  const updates = [];
  const params = [];

  // 昵称：1–20 字，非空。
  if (body.nickname !== undefined) {
    if (typeof body.nickname !== 'string') return fail(res, 400, '昵称格式不正确');
    const nickname = body.nickname.trim();
    if (!nickname) return fail(res, 400, '昵称不能为空');
    if (charLength(nickname) > NICKNAME_MAX) return fail(res, 400, '昵称最多 20 个字');
    const safe = filter.scan(nickname);
    if (!safe.ok) return fail(res, 400, safe.reason);
    updates.push('nickname = ?');
    params.push(nickname);
  }
  // 目标院校 / 目标专业：≤40 字，允许传空串清空。
  for (const key of ['targetSchool', 'targetMajor']) {
    if (body[key] === undefined) continue;
    if (typeof body[key] !== 'string') return fail(res, 400, (key === 'targetSchool' ? '目标院校' : '目标专业') + '格式不正确');
    const value = body[key].trim();
    if (charLength(value) > TARGET_MAX) return fail(res, 400, (key === 'targetSchool' ? '目标院校' : '目标专业') + '最多 40 个字');
    const safe = filter.scan(value);
    if (!safe.ok) return fail(res, 400, safe.reason);
    updates.push((key === 'targetSchool' ? 'target_school' : 'target_major') + ' = ?');
    params.push(value);
  }
  // 宣言：≤100 字，允许传空串清空。
  if (body.bio !== undefined) {
    if (typeof body.bio !== 'string') return fail(res, 400, '宣言格式不正确');
    const bio = body.bio.trim();
    if (charLength(bio) > BIO_MAX) return fail(res, 400, '宣言最多 100 个字');
    const safe = filter.scan(bio);
    if (!safe.ok) return fail(res, 400, safe.reason);
    updates.push('bio = ?');
    params.push(bio);
  }
  // 学习标签：白名单，去重，最多 5 个。
  if (body.studyTags !== undefined) {
    if (!Array.isArray(body.studyTags)) return fail(res, 400, '学习标签格式不正确');
    const tags = [];
    for (const item of body.studyTags) {
      if (typeof item !== 'string') return fail(res, 400, '学习标签格式不正确');
      const tag = item.trim();
      if (!STUDY_TAGS.includes(tag)) return fail(res, 400, '学习标签不合法');
      if (!tags.includes(tag)) tags.push(tag);
    }
    if (tags.length > STUDY_TAG_MAX) return fail(res, 400, '最多选择 5 个学习标签');
    updates.push('study_tags = ?');
    params.push(JSON.stringify(tags));
  }

  if (!updates.length) return fail(res, 400, '没有需要保存的内容');

  try {
    params.push(sid);
    db.run('UPDATE students SET ' + updates.join(', ') + ' WHERE id = ?', params);
    const profile = loadIdentityCard(sid, sid);
    if (!profile) return fail(res, 404, '用户不存在');
    return res.json({ ok: true, profile: profile });
  } catch (error) {
    return fail(res, 500, '服务器繁忙，请稍后再试');
  }
});

module.exports = router;
