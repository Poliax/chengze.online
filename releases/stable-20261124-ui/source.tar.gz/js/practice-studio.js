/* Practice workspace: discover → train → review. Server owns grading and history. */
(function () {
  'use strict';
  var box = document.getElementById('practiceBox');
  var tabs = document.getElementById('practiceTabs');
  if (!box) return;
  var provinceField = document.getElementById('globalProvince');
  var provinces = provinceField && provinceField.options ? Array.prototype.map.call(provinceField.options, function (option) { return { code: option.value, name: option.text }; }).filter(function (p) { return p.code && p.code !== 'all'; }) : [];
  var state = {
    province: provinceField && provinceField.value !== 'all' ? provinceField.value : '', scopeError: '',
    activeSubject: '', showLibrary: false, mode: 'practice', loading: true, error: '', questions: [], subjects: [], lessonIds: [],
    stats: null, statsError: '', subject: '', count: 10,
    session: null, exam: null, starting: false,
    wrong: { rows: [], total: 0, page: 1, subject: '', loading: false, error: '' },
    recordsLoading: false
  };
  var requestVersion = 0;
  var timer = null;
  function esc(value) {
    return String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function signedIn() { return !!(window.CZ_VIEWER && window.CZ_VIEWER.signedIn); }
  function api(path, body) {
    if (state.province) {
      if (body === undefined) path += (path.indexOf('?') >= 0 ? '&' : '?') + 'province=' + encodeURIComponent(state.province);
      else body = Object.assign({}, body, { province: state.province });
    }
    return fetch('/api/practice' + path, {
      method: body === undefined ? 'GET' : 'POST', credentials: 'same-origin',
      headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body)
    }).then(function (response) {
      return response.json().then(function (data) {
        if (!response.ok || !data || data.ok === false) throw new Error(data && data.error || '请求失败，请稍后重试');
        return data;
      });
    });
  }
  function button(label, action, cls, attrs) {
    return '<button type="button" class="pz-btn ' + (cls || '') + '" data-action="' + action + '" ' + (attrs || '') + '>' + esc(label) + '</button>';
  }
  function alert(message, action) {
    return '<div class="pz-alert" role="alert">' + esc(message) + (action ? button('重新加载', action, 'pz-btn-text') : '') + '</div>';
  }
  function empty(title, detail, action, label) {
    return '<div class="pz-empty"><span class="pz-empty-symbol" aria-hidden="true">◇</span><h3>' + esc(title) + '</h3><p>' + esc(detail || '') + '</p>' + (action ? button(label || '开始练习', action, 'pz-btn-primary') : '') + '</div>';
  }
  function login(detail) { return empty('让每一次练习都有迹可循', detail, 'login', '登录并开始'); }
  function pool(subject) { return state.questions.filter(function (q) { return !subject || q.subject === subject; }); }
  function shuffle(list) {
    var copy = list.slice();
    for (var i = copy.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var temp = copy[i]; copy[i] = copy[j]; copy[j] = temp;
    }
    return copy;
  }
  function time(seconds) {
    var n = Math.max(0, Math.ceil(seconds));
    return String(Math.floor(n / 60)).padStart(2, '0') + ':' + String(n % 60).padStart(2, '0');
  }
  function subjectSelect(value, action) {
    if(state.activeSubject)return '<span class="pz-selected-subject">'+esc(state.activeSubject)+'</span>';
    return '<select class="pz-select" aria-label="选择科目" data-change="' + action + '"><option value="">全部科目</option>' + state.subjects.map(function (s) {
      return '<option value="' + esc(s) + '"' + (s === value ? ' selected' : '') + '>' + esc(s) + '</option>';
    }).join('') + '</select>';
  }
  function heading(kicker, title, detail) {
    return '<header class="pz-heading"><div><span class="pz-eyebrow">' + esc(kicker) + '</span><h2>' + esc(title) + '</h2><p>' + esc(detail) + '</p></div><span class="pz-heading-mark" aria-hidden="true">习</span></header>';
  }
  function provinceBar() { return state.scopeError ? alert(state.scopeError) : ''; }
  function changeProvince(code) {
    if (code === state.province) return;
    if (state.starting || (state.exam && !state.exam.complete)) {
      if (provinceField) provinceField.value = state.province;
      state.scopeError = '请完成当前自测并交卷后，再切换招考省份。'; render(); return;
    }
    state.province = code; state.scopeError = ''; state.session = null; state.exam = null;
    state.activeSubject = ''; state.mode='practice'; state.subject = ''; state.stats = null; state.questions = []; state.subjects = []; state.lessonIds = [];
    state.wrong.subject = ''; state.wrong.page = 1; state.wrong.rows = []; state.wrong.total = 0;
    wrongVersion++; requestVersion++;
    if (provinceField && provinceField.value !== code) {
      provinceField.value = code;
      provinceField.dispatchEvent(new Event('change'));
    }
    loadQuestions(); refreshStats();
    if (state.mode === 'wrong') loadWrong();
  }
  function render() {
    if(!state.activeSubject && state.subjects.length && !state.loading){state.activeSubject=state.subjects[0];state.subject=state.activeSubject;state.wrong.subject=state.activeSubject;}
    if (tabs && (state.mode === 'practice' && state.session || state.mode === 'exam' && state.exam)) tabs.innerHTML = '';
    else scopeNav();
    if (window.PastPaperStudio) window.PastPaperStudio.unmount();
    if(state.mode==='vocabulary'){
      if(tabs)Array.prototype.forEach.call(tabs.querySelectorAll('[data-mode]'),function(tab){var on=tab.getAttribute('data-mode')==='vocabulary';tab.classList.toggle('active',on);tab.setAttribute('aria-pressed',String(on));});
      if(window.CZVocabulary)window.CZVocabulary.mount(box);else box.innerHTML='<div class="empty">单词模块加载中，请刷新重试。</div>';
      return;
    }
    var session = state.mode === 'practice' ? state.session : state.mode === 'exam' ? state.exam : null;
    var html = session ? sessionView(session) : state.mode === 'subject' ? subjectWorkspace() : state.mode === 'practice' ? (state.activeSubject ? subjectWorkspace() : homeView()) : state.mode === 'exam' ? examHome() : state.mode === 'wrong' ? wrongView() : recordsView();
    if (state.mode === 'papers' && window.PastPaperStudio) {if(state.province==='61')window.PastPaperStudio.mount(box, state.activeSubject);else box.innerHTML=provinceBar()+empty('本科目真题正在整理中','当前已上线真题仅覆盖陕西，其他省份将继续补充。');}
    else box.innerHTML = provinceBar() + html;
    var shelf = box.querySelector('.pz-book-shelf');
    var selectedBook = shelf && shelf.querySelector('.is-current');
    if (selectedBook && shelf.scrollWidth > shelf.clientWidth) {
      var bookBounds = selectedBook.getBoundingClientRect();
      var shelfBounds = shelf.getBoundingClientRect();
      shelf.scrollLeft += bookBounds.left - shelfBounds.left - (shelf.clientWidth - bookBounds.width) / 2;
    }
    if (tabs) Array.prototype.forEach.call(tabs.querySelectorAll('[data-mode]'), function (tab) {
      var on = tab.getAttribute('data-mode') === state.mode || (tab.getAttribute('data-mode') === 'subject' && state.mode === 'practice');
      tab.classList.toggle('active', on);
      tab.setAttribute('aria-pressed', String(on));
    });
  }
  function refreshStats() {
    if (!signedIn()) return Promise.resolve();
    state.statsError = '';
    var province = state.province;
    return api('/stats').then(function (data) { if (province !== state.province) return; state.stats = data; render(); }).catch(function (error) {
      if (province !== state.province) return; state.statsError = error.message; render();
    });
  }
  // Load every page, so subject/lesson navigation never silently omits later questions.
  function loadQuestions() {
    var version = ++requestVersion;
    state.loading = true; state.error = ''; render();
    var questions = [];
    function page(offset) {
      return api('/questions?limit=100&offset=' + offset).then(function (data) {
        if (version !== requestVersion) return;
        questions = questions.concat(data.questions || []);
        if ((data.questions || []).length && questions.length < data.total) return page(questions.length);
        state.questions = questions;
        state.subjects = data.subjects || [];
        state.lessonIds = data.lessonIds || [];
        state.loading = false;
        window._czPracticeQuestions = questions.map(function (q) { return { id: q.id, subject: q.subject, lessonId: q.lessonId, lesson_id: q.lessonId }; });
        render();
      });
    }
    return page(0).catch(function (error) { if (version === requestVersion) { state.loading = false; state.error = error.message; render(); } });
  }
  function metric(value, label, unit) {
    return '<div class="pz-metric"><span>' + esc(label) + '</span><strong>' + esc(value) + '<small>' + esc(unit || '') + '</small></strong></div>';
  }
  function scopeNav() {
    if (!tabs) return;
    var region=(provinces.find(function(p){return p.code===state.province;})||{}).name||'';
    tabs.innerHTML = state.activeSubject ? '<div class="pz-context-heading"><button type="button" class="pz-back-button" data-mode="library" aria-label="返回科目" title="返回科目"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5m6-6-6 6 6 6"/></svg></button><div class="pz-context-copy"><small>'+esc(region?region+' · 专升本':'专升本')+'</small><h2>'+esc(state.activeSubject)+'</h2></div></div><div class="pz-context-tabs" role="group" aria-label="科目导航">'+[['subject','练习方式'],['records','学习记录']].map(function(item){var on=state.mode===item[0]||(item[0]==='subject'&&state.mode==='practice');return '<button type="button" class="practice-tab'+(on?' active':'')+'" data-mode="'+item[0]+'" aria-pressed="'+on+'">'+item[1]+'</button>';}).join('')+'</div>' : '';
  }
  function practiceOverview(){
    var stats=state.stats,ready=signedIn()&&stats&&!state.statsError;
    var summary='<div class="pz-catalogue-metrics" aria-label="当前省份全部科目练习统计">'+metric(ready?(stats.today||{}).total||0:'—','今日作答','题')+metric(ready?stats.total||0:'—','累计作答','题')+metric(ready?stats.accuracy||0:'—','正确率','%')+metric(ready?stats.wrongCount||0:'—','待巩固','题')+'</div>';
    return summary;
  }
  function practiceRecent(){
    var stats=state.stats,exams=stats&&(stats.exams||[]);
    var content=!signedIn()?'<p>登录后记录每一次练习。</p>'+button('登录','login','pz-btn-text'):state.statsError?'<p>学习记录暂时未能加载。</p>'+button('重试','stats-retry','pz-btn-text'):!stats?'<p>正在读取学习记录…</p>':exams&&exams.length?'<div class="pz-recent-tests">'+exams.slice(0,3).map(function(exam){return '<div><span>'+esc(String(exam.createdAt||'').slice(0,10))+'</span><strong>'+esc(exam.score)+'<small> / '+esc(exam.total)+' 题</small></strong></div>';}).join('')+'</div>':'<p>还没有自测记录，完成一份试卷后会显示在这里。</p>';
    return '<aside class="pz-catalogue-aside"><h3>最近自测</h3>'+content+button('学习记录','mode','pz-btn-text','data-mode="records"')+'</aside>';
  }
  function subjectWorkspace(){
    var region=(provinces.find(function(p){return p.code===state.province;})||{}).name||'';
    var selected=Math.max(0,state.subjects.indexOf(state.activeSubject));
    return '<div class="pz-subject-workspace pz-book-workspace"><aside class="pz-book-shelf" aria-label="选择科目">'+state.subjects.map(function(subject){var on=subject===state.activeSubject;return '<button type="button" class="pz-subject-card'+(on?' is-current':'')+'" data-action="subject-open" data-subject="'+esc(subject)+'" aria-pressed="'+on+'"><div class="pz-cover-heading"><span class="pz-cover-province">'+esc(region)+'专升本</span></div><h4>'+esc(subject)+'</h4><p>'+pool(subject).length+' 道练习题</p></button>';}).join('')+'</aside><div class="pz-subject-main pz-book-directory tone-'+selected%3+'">'+practiceOverview()+'<div class="pz-catalogue-layout"><div>'+subjectHub()+'</div>'+practiceRecent()+'</div></div></div>';
  }
  function subjectHub() {
    var s=state.activeSubject, count=pool(s).length;
    var modes=[['practice','题库练习',count ? '逐题作答，即时查看解析' : '本科目暂无可用题目',count>0],['exam','限时自测',count ? '按本科目组卷，交卷后复盘' : '本科目暂无可用题目',count>0],['wrong','错题巩固','集中复习本科目的错题',true],['papers','历年真题',state.province !== '61' ? '当前省份暂无真题' : '按年份选卷，完整作答',state.province === '61' && !!window.PastPaperStudio]];
    if (/英语|英文/.test(s)) {
      var papers = modes.find(function(mode){return mode[0]==='papers';});
      papers[1] = '模考：真题卷';
      modes = [
        ['vocabulary','基础训练：单词','每日新词、到期复习与词义测验',true],
        ['grammar','基础训练：语法','内容准备中',false],
        ['reading','专项训练：阅读','内容准备中',false],
        ['translation','专项训练：翻译','内容准备中',false],
        ['writing','专项训练：作文','内容准备中',false],
        papers,
        ['exam','模考：测试卷',count ? '限时组卷，交卷后复盘' : '本科目暂无可用题目',count>0]
      ];
    }
    var region=(provinces.find(function(p){return p.code===state.province;})||{}).name||'';
    function modeCard(m){return '<button type="button" class="pz-mode-card" data-action="subject-mode" data-mode="'+m[0]+'"'+(!m[3]?' disabled':'')+'><div class="pz-mode-copy"><span class="pz-mode-subject">'+esc(s)+'</span><h3>'+m[1]+'</h3><p>'+m[2]+'</p></div><span class="pz-mode-state">'+(!m[3]?'整理中':'<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9 5l7 7-7 7"/></svg>')+'</span></button>';}
    var content;
    if (/英语|英文/.test(s)) {
      var groups=[{title:'考点练习',ids:['vocabulary','grammar']},{title:'题型训练',ids:['reading','translation','writing']},{title:'试卷模考',ids:['papers','exam']}];
      var stage=state.practiceStage||0;
      var filters='<div class="pz-stage-filters student-segmented" role="group" aria-label="练习分类">'+groups.map(function(g,i){return '<button type="button" class="pz-stage-filter'+(stage===i?' is-current':'')+'" data-action="stage-filter" data-stage="'+i+'" aria-pressed="'+(stage===i)+'">'+g.title+'</button>';}).join('')+'</div>';
      content=filters+groups.filter(function(group,i){return i===stage;}).map(function(group){
        var cards=modes.filter(function(m){return group.ids.indexOf(m[0])>=0;}).map(function(m){var item=m.slice();item[1]=item[1].replace(/^(基础训练|专项训练|模考)[：:]\s*/, '');return modeCard(item);}).join('');
        return '<section class="pz-mode-group" aria-label="'+group.title+'"><div class="pz-mode-grid">'+cards+'</div></section>';
      }).join('');
    } else content='<div class="pz-mode-grid">'+modes.map(modeCard).join('')+'</div>';
    return '<section class="pz-subject-directory" aria-label="'+esc(s)+'练习项目">'+content+'</section>';
  }
  function homeView() {
    if(state.error)return alert(state.error,'retry');
    if(state.loading)return empty('正在准备题库');
    if(!state.subjects.length)return empty('该省科目正在准备中');
    state.activeSubject=state.subjects[0];state.subject=state.activeSubject;state.wrong.subject=state.activeSubject;
    return subjectWorkspace();
  }
  function newSession(questions, title, kind) {
    return { questions: questions, title: title, kind: kind || 'practice', idx: 0, selected: {}, results: {}, busy: false, error: '', complete: false, review: false };
  }
  function startPractice(questions, title) {
    if (!questions.length) return;
    state.session = newSession(questions, title); state.mode = 'practice'; render();
  }
  function answerCount(session) {
    return session.kind === 'exam' ? Object.keys(session.selected).length : Object.keys(session.results).length;
  }
  function answerSheet(session) {
    return '<aside class="pz-panel pz-answer-sheet"><div class="pz-section-heading"><h3>答题卡</h3><span>' + answerCount(session) + ' / ' + session.questions.length + '</span></div><div class="pz-number-grid">' + session.questions.map(function (q, index) {
      var result = session.results[q.id];
      var cls = result ? (result.correct ? ' is-correct' : ' is-wrong') : session.selected[q.id] !== undefined ? ' is-answered' : '';
      return '<button type="button" class="pz-number' + cls + (index === session.idx ? ' is-current' : '') + '" data-action="jump" data-index="' + index + '" aria-label="第 ' + (index + 1) + ' 题"' + (index === session.idx ? ' aria-current="step"' : '') + (session.busy ? ' disabled' : '') + '>' + (index + 1) + '</button>';
    }).join('') + '</div><p class="pz-sheet-note">' + (session.kind === 'exam' ? '深色为已答题目，交卷前可随时修改。' : '绿色为答对，红色为待巩固。点击题号可回看解析。') + '</p></aside>';
  }
  function sessionView(session) {
    if (session.complete && !session.review) return summaryView(session);
    var q = session.questions[session.idx];
    var result = session.results[q.id];
    var selected = session.selected[q.id];
    var count = answerCount(session);
    var exam = session.kind === 'exam';
    var backLabel = exam ? (session.complete ? '返回自测设置' : '结束自测') : '返回练习首页';
    var html = '<div class="pz-session-heading">' + ('<button type="button" class="pz-back-button" data-action="leave" aria-label="' + backLabel + '" title="' + backLabel + '"' + (session.busy ? ' disabled' : '') + '><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5m6-6-6 6 6 6"/></svg></button>') + '<span>' + esc(session.title) + '</span>' + (exam && !session.complete ? '<strong id="pzExamTimer" class="pz-timer">' + time((session.deadline - Date.now()) / 1000) + '</strong>' : '<span>已完成 ' + count + ' / ' + session.questions.length + '</span>') + '</div>';
    html += '<div class="pz-progress-track"><div style="width:' + Math.round(count / session.questions.length * 100) + '%"></div></div>';
    html += '<div class="pz-training-layout"><article class="pz-question"><div class="pz-meta"><span>' + esc(q.subject || '课时练习') + ' <i>单选题</i></span><span>' + String(session.idx + 1).padStart(2, '0') + ' / ' + session.questions.length + '</span></div><h3 class="pz-question-title">' + esc(q.content) + '</h3><div class="pz-options">';
    html += q.options.map(function (option, index) {
      var cls = result ? (index === result.answer ? ' is-correct' : index === selected ? ' is-wrong' : '') : index === selected ? ' is-selected' : '';
      return '<button type="button" class="pz-option' + cls + '" data-action="option" data-index="' + index + '" aria-pressed="' + (index === selected) + '"' + (result || session.busy || (exam && Date.now() >= session.deadline) ? ' disabled' : '') + '><span class="pz-option-letter">' + String.fromCharCode(65 + index) + '</span><span>' + esc(option) + '</span>' + (result && index === result.answer ? '<b>✓</b>' : '') + '</button>';
    }).join('') + '</div>';
    if (result) html += '<div class="pz-explanation" role="status"><strong class="' + (result.correct ? 'pz-text-correct' : 'pz-text-wrong') + '">' + (result.correct ? '回答正确' : '这道题还需要巩固') + ' · 正确答案 ' + String.fromCharCode(65 + result.answer) + '</strong><p>' + esc(result.explanation || '本题暂无解析。') + '</p>' + (session.wrongIds && result.correct ? button('标记已掌握', 'resolve-current', 'pz-btn-text', session.resolved && session.resolved[q.id] ? 'disabled' : '') : '') + '</div>';
    if (session.error) html += alert(session.error);
    html += '<div class="pz-question-footer">' + button('上一题', 'prev', 'pz-btn-ghost', session.idx === 0 || session.busy ? 'disabled' : '') + '<div>';
    if (!exam && !result) html += button(session.busy ? '正在判分…' : '确认答案', 'answer', 'pz-btn-primary', selected === undefined || session.busy ? 'disabled' : '');
    else if (session.idx < session.questions.length - 1) html += button('下一题 →', 'next', 'pz-btn-primary', session.busy ? 'disabled' : '');
    if (exam && !session.complete) html += button(session.busy ? '正在交卷…' : '交卷并查看结果', 'submit-exam', 'pz-btn-primary', session.busy ? 'disabled' : '');
    if ((!exam && count === session.questions.length) || session.complete) html += button('查看本轮总结', 'summary', 'pz-btn-primary');
    html += '</div></div></article>' + answerSheet(session) + '</div>';
    return html;
  }
  function summaryView(session) {
    var total = session.questions.length;
    var correct = Object.keys(session.results).filter(function (id) { return session.results[id].correct; }).length;
    return '<section class="pz-completion"><span class="pz-eyebrow">每一份努力都算数</span><h2>这一轮，完成了。</h2><p>回顾错题，比只看分数更有收获。</p><div class="pz-result-metrics">' + metric(total, '本轮题量', '题') + metric(correct, '答对', '题') + metric(Math.round(correct / total * 100), '正确率', '%') + '</div><div class="pz-actions">' + button('逐题复盘', 'review', 'pz-btn-primary') + button('再练一组', 'again', 'pz-btn-ghost') + button('返回练习首页', 'home', 'pz-btn-text') + '</div><p class="pz-save-note">' + (signedIn() ? '作答记录已保存，答错的题已收录到错题本。' : '本轮为游客体验，登录后可保存后续练习记录。') + '</p></section>';
  }
  function activeSession() { return state.mode === 'exam' ? state.exam : state.session; }
  function submitAnswer() {
    var session = state.session;
    if (!session || session.busy) return;
    var q = session.questions[session.idx];
    var selected = session.selected[q.id];
    if (selected === undefined || session.results[q.id]) return;
    session.busy = true; session.error = ''; render();
    api('/answer', { questionId: q.id, selected: selected }).then(function (data) {
      session.results[q.id] = data; session.busy = false;
      // Keep final feedback visible; the user opens the round summary explicitly.
      render(); refreshStats();
    }).catch(function (error) { session.busy = false; session.error = error.message; render(); });
  }
  function examHome() {
    var html = heading('TIMED PRACTICE / 限时自测', '给自己一次专注作答的时间', '选择范围，独立完成；交卷后，再逐题复盘。');
    if (!signedIn()) return html + login('登录后参加限时自测，成绩和错题会自动保存。');
    if (state.loading) return html + empty('正在准备题库');
    if (state.error) return html + alert(state.error, 'retry');
    var available = pool(state.subject).length;
    return html + '<div class="pz-setup-layout"><section class="pz-panel pz-exam-setup"><h3>组一份适合自己的练习卷</h3><label class="pz-field"><span>练习科目</span>' + subjectSelect(state.subject, 'exam-subject') + '</label><div class="pz-field"><span>题目数量</span><div class="pz-counts">' + [5, 10, 20, 30].map(function (n) { return button(n + ' 题', 'exam-count', n === state.count ? 'is-selected' : '', 'data-count="' + n + '" aria-pressed="' + (n === state.count) + '"'); }).join('') + '</div></div><div class="pz-setup-summary"><b>' + Math.min(state.count, available) + ' 道题</b><span>10 分钟 · 单选题 · 交卷后查看解析</span></div><p class="pz-muted">当前范围共有 ' + available + ' 题，题目不足时按实际数量组卷。</p>' + (state.examError ? alert(state.examError) : '') + button(state.starting ? '正在组卷…' : '准备好了，开始自测 →', 'exam-start', 'pz-btn-primary', state.starting || !available ? 'disabled' : '') + '</section><aside class="pz-panel"><span class="pz-eyebrow">作答前的小提醒</span><h3>把这 10 分钟留给自己</h3><ol class="pz-tips"><li>作答时不显示答案，试着独立完成。</li><li>答题卡可自由跳题，交卷前可以修改。</li><li>切换页签仍会计时，到时自动交卷。</li><li>请保持页面打开，刷新会丢失本轮进度。</li></ol></aside></div>';
  }
  function startExam() {
    if (state.starting || !signedIn()) return;
    state.starting = true; state.examError = ''; render();
    api('/exam/start', { subject: state.subject, count: state.count }).then(function (data) {
      state.starting = false;
      var session = newSession(data.questions, (data.exam.province ? data.exam.province.name + ' · ' : '') + '限时自测', 'exam');
      session.id = data.exam.id; session.duration = data.exam.durationSeconds;
      session.deadline = Date.now() + session.duration * 1000;
      state.exam = session; render();
      clearInterval(timer); timer = setInterval(tick, 500);
    }).catch(function (error) { state.starting = false; state.examError = error.message; render(); });
  }
  function tick() {
    var session = state.exam;
    if (!session || session.complete) { clearInterval(timer); return; }
    var el = document.getElementById('pzExamTimer');
    var remaining = Math.max(0, (session.deadline - Date.now()) / 1000);
    if (el) { el.textContent = time(remaining); el.classList.toggle('is-urgent', remaining < 60); }
    if (remaining <= 0 && !session.busy && !session.autoFailed) submitExam(true);
  }
  function submitExam(auto) {
    var session = state.exam;
    if (!session || session.busy || session.complete) return;
    var missing = session.questions.length - answerCount(session);
    if (!auto && !window.confirm((missing ? '还有 ' + missing + ' 题未答。' : '') + '确定交卷并查看结果？')) return;
    session.busy = true; session.error = ''; render();
    api('/exam/' + session.id + '/submit', {
      answers: session.questions.map(function (q) { return { questionId: q.id, selected: session.selected[q.id] === undefined ? null : session.selected[q.id] }; }),
      durationSeconds: Math.min(session.duration, Math.round((Date.now() - session.deadline) / 1000 + session.duration))
    }).then(function (data) {
      data.result.items.forEach(function (item) { session.results[item.questionId] = item; });
      session.busy = false; session.complete = true; clearInterval(timer); render(); refreshStats();
    }).catch(function (error) { session.busy = false; session.autoFailed = true; session.error = error.message + '，请点击交卷重试。'; render(); });
  }
  function wrongView() {
    var wrong = state.wrong;
    var html = heading('REVIEW / 错题巩固', '把错过的题，变成拿得稳的分', '答错自动收录。重做、理解，再标记掌握。');
    if (!signedIn()) return html + login('登录后查看错题，建立属于自己的复习清单。');
    html += '<div class="pz-toolbar">' + subjectSelect(wrong.subject, 'wrong-subject') + '<span>' + wrong.total + ' 道待巩固</span>' + button('练习本页错题', 'wrong-train', 'pz-btn-primary', !wrong.rows.length || wrong.loading ? 'disabled' : '') + '</div>';
    if (wrong.error) return html + alert(wrong.error, 'wrong-retry');
    if (wrong.loading) return html + empty('正在整理错题');
    if (!wrong.rows.length) return html + empty('这里很清爽', wrong.subject ? '这个科目暂无待巩固错题。' : '还没有待巩固的错题，去做一组练习吧。', 'home');
    html += '<div class="pz-wrong-list">' + wrong.rows.map(function (row, index) {
      return '<article class="pz-wrong-row"><span class="pz-row-index">' + String((wrong.page - 1) * 10 + index + 1).padStart(2, '0') + '</span><div><div class="pz-meta"><span>' + esc(row.subject) + '</span><span>累计答错 ' + row.wrongCount + ' 次</span></div><h3>' + esc(row.content) + '</h3><small>最近答错 ' + esc(row.lastWrongAt.slice(0, 10)) + '</small></div><div class="pz-row-actions">' + button('重做这题', 'wrong-redo', 'pz-btn-ghost', 'data-id="' + row.questionId + '"') + button('已掌握', 'wrong-resolve', 'pz-btn-text', 'data-id="' + row.questionId + '"') + '</div></article>';
    }).join('') + '</div>';
    var pages = Math.ceil(wrong.total / 10);
    return html + '<div class="pz-pager">' + button('上一页', 'wrong-prev', 'pz-btn-ghost', wrong.page <= 1 ? 'disabled' : '') + '<span>' + wrong.page + ' / ' + pages + '</span>' + button('下一页', 'wrong-next', 'pz-btn-ghost', wrong.page >= pages ? 'disabled' : '') + '</div>';
  }
  var wrongVersion = 0;
  function loadWrong() {
    if (!signedIn()) return;
    var wrong = state.wrong; var version = ++wrongVersion;
    wrong.loading = true; wrong.error = ''; render();
    api('/wrong-book?page=' + wrong.page + '&pageSize=10&subject=' + encodeURIComponent(wrong.subject)).then(function (data) {
      if (version !== wrongVersion) return;
      wrong.total = data.total; wrong.rows = data.rows; wrong.loading = false;
      if (!wrong.rows.length && wrong.page > 1) { wrong.page--; loadWrong(); return; }
      render();
    }).catch(function (error) { if (version === wrongVersion) { wrong.loading = false; wrong.error = error.message; render(); } });
  }
  function wrongQuestions(rows) { return rows.map(function (row) { return { id: row.questionId, subject: row.subject, content: row.content, options: row.options }; }); }
  function trainWrong(rows) {
    if (!rows.length) return;
    startPractice(wrongQuestions(rows), '错题专项');
    if (state.session) state.session.wrongIds = true;
  }
  function resolve(id) {
    api('/wrong-book/' + id + '/resolve', {}).then(function () {
      var session = state.session;
      if (session && session.wrongIds) { session.resolved = session.resolved || {}; session.resolved[id] = true; }
      loadWrong(); refreshStats(); render();
    }).catch(function (error) { if (state.mode === 'wrong') state.wrong.error = error.message; else if (state.session) state.session.error = error.message; render(); });
  }
  function recordsView() {
    var html = heading('PROGRESS / 学习记录', '进步，藏在每一次认真作答里', '从真实记录中，发现值得继续坚持的方向。');
    if (!signedIn()) return html + login('登录后查看练习统计、各科表现和自测记录。');
    if (state.statsError) return html + alert(state.statsError, 'stats-retry');
    var stats = state.stats;
    if(state.activeSubject&&stats){var row=(stats.bySubject||[]).find(function(r){return r.subject===state.activeSubject;});return html+'<section class="pz-panel"><h3>'+esc(state.activeSubject)+' · 学习记录</h3><div class="pz-metrics">'+metric(row?row.total:0,'累计作答','题')+metric(row?row.correct:0,'答对','题')+metric(row?row.accuracy:0,'正确率','%')+'</div></section>';}
    if (!stats) return html + empty('正在读取学习记录');
    if (!stats.total) return html + empty('第一份记录，从现在开始', '完成一组练习，回来看看你的表现。', 'home');
    html += '<div class="pz-metrics">' + metric(stats.total, '累计作答', '题') + metric(stats.accuracy, '累计正确率', '%') + metric(stats.streakDays, '连续练习', '天') + metric(stats.wrongCount, '待巩固', '题') + '</div><div class="pz-home-columns"><section class="pz-panel"><h3>各科表现</h3>';
    html += (stats.bySubject || []).map(function (row) {
      return '<div class="pz-subject-stat"><div><b>' + esc(row.subject) + '</b><span>' + row.correct + ' / ' + row.total + ' 题 · ' + row.accuracy + '%</span></div><div class="pz-progress-track"><div style="width:' + row.accuracy + '%"></div></div>' + button('继续练习 →', 'subject-start', 'pz-btn-text', 'data-subject="' + esc(row.subject) + '"') + '</div>';
    }).join('') + '</section><section class="pz-panel"><h3>最近自测</h3>';
    html += stats.exams.length ? '<div class="pz-exam-records">' + stats.exams.map(function (exam) { return '<div><span>' + esc(exam.createdAt.slice(0, 10)) + '</span><strong>' + exam.score + '<small> / ' + exam.total + ' 题</small></strong></div>'; }).join('') + '</div>' : '<p class="pz-muted">还没有自测记录，准备好了就来试试。</p>' + button('去限时自测 →', 'mode', 'pz-btn-text', 'data-mode="exam"');
    return html + '</section></div>';
  }
  function open(mode) {
    if(mode==='library'){if(state.starting||(state.exam&&!state.exam.complete)){state.scopeError='请先完成当前自测并交卷。';render();return;}state.showLibrary=false;state.session=null;state.exam=null;mode='subject';}

    state.mode = ['subject', 'practice', 'papers', 'exam', 'wrong', 'records', 'vocabulary'].indexOf(mode) >= 0 ? mode : 'practice';
    if (state.mode === 'wrong') loadWrong();
    if (state.mode === 'records' || state.mode === 'practice') refreshStats();
    render();
  }
  function home() { state.session = null; state.mode = state.activeSubject ? 'subject' : 'practice'; refreshStats(); render(); }
  function handle(action, target) {
    var session = activeSession();
    if (session && session.busy && ['option', 'jump', 'prev', 'next', 'leave', 'summary', 'again', 'home'].indexOf(action) >= 0) return;
    var index = Number(target.getAttribute('data-index'));
    if (action === 'login') { if (window.openAuthModal) window.openAuthModal(); }
    else if (action === 'retry') loadQuestions();
    else if (action === 'stats-retry') refreshStats();
    else if (action === 'mode') open(target.getAttribute('data-mode'));
    else if (action === 'home') home();
    else if (action === 'quick-start') { startPractice(shuffle(state.questions).slice(0, 10), '每日快练'); if (state.session) state.session.source = state.questions; }
    else if(action==='subject-open'){if(state.starting||(state.exam&&!state.exam.complete)){state.scopeError='请先完成当前自测并交卷。';render();return;}state.scopeError='';state.showLibrary=false;state.activeSubject=target.getAttribute('data-subject');state.subject=state.activeSubject;state.wrong.subject=state.activeSubject;state.wrong.page=1;state.session=null;open('subject');}
    else if(action==='stage-filter'){state.practiceStage=Number(target.getAttribute('data-stage'));render();}
    else if(action==='subject-mode'){var mode=target.getAttribute('data-mode');state.subject=state.activeSubject;state.wrong.subject=state.activeSubject;if(mode==='practice')startPractice(pool(state.activeSubject),state.activeSubject+' · 科目练习');else open(mode);}
    else if (action === 'subject-start') { var subject = target.getAttribute('data-subject'); startPractice(pool(subject), subject + ' · 科目练习'); }
    else if (action === 'option' && session) {
      var q = session.questions[session.idx];
      if (!session.results[q.id] && (!session.deadline || Date.now() < session.deadline) && index >= 0 && index < q.options.length) session.selected[q.id] = index;
      render();
    }
    else if ((action === 'jump' || action === 'prev' || action === 'next') && session) {
      var next = action === 'jump' ? index : session.idx + (action === 'prev' ? -1 : 1);
      if (next >= 0 && next < session.questions.length) session.idx = next;
      render();
    }
    else if (action === 'answer') submitAnswer();
    else if (action === 'summary' && session) { session.complete = true; session.review = false; render(); }
    else if (action === 'review' && session) { session.review = true; session.idx = 0; render(); }
    else if (action === 'leave' && session) {
      if (session.kind === 'exam' && !session.complete) { submitExam(false); return; }
      if (!session.complete && answerCount(session) && !window.confirm('返回首页将结束本轮练习，已提交的作答记录会保留。继续？')) return;
      if (state.mode === 'exam') state.exam = null; else state.session = null;
      render();
    }
    else if (action === 'again' && session) {
      if (session.kind === 'exam') { state.exam = null; render(); }
      else { var questions = shuffle(session.source || session.questions); var wrongIds = session.wrongIds; startPractice(questions.slice(0, 10), session.title); state.session.wrongIds = wrongIds; state.session.source = session.source; }
    }
    else if (action === 'exam-count') { state.count = Number(target.getAttribute('data-count')); render(); }
    else if (action === 'exam-start') startExam();
    else if (action === 'submit-exam') submitExam(false);
    else if (action === 'wrong-retry') loadWrong();
    else if (action === 'wrong-train') { trainWrong(state.wrong.rows); render(); }
    else if (action === 'wrong-redo') { trainWrong(state.wrong.rows.filter(function (row) { return row.questionId === Number(target.getAttribute('data-id')); })); render(); }
    else if (action === 'wrong-resolve') resolve(Number(target.getAttribute('data-id')));
    else if (action === 'resolve-current' && session) resolve(session.questions[session.idx].id);
    else if (action === 'wrong-prev' || action === 'wrong-next') { state.wrong.page += action === 'wrong-prev' ? -1 : 1; loadWrong(); }
  }
  box.addEventListener('click', function (event) {
    var target = event.target.closest('[data-action]');
    if (target && box.contains(target) && !target.disabled) handle(target.getAttribute('data-action'), target);
  });
  box.addEventListener('change', function (event) {
    var action = event.target.getAttribute('data-change');
    if (action === 'province') changeProvince(event.target.value);
    if (action === 'exam-subject') { state.subject = event.target.value; render(); }
    if (action === 'wrong-subject') { state.wrong.subject = event.target.value; state.wrong.page = 1; loadWrong(); }
  });
  if (tabs) tabs.addEventListener('click', function (event) { var target = event.target.closest('[data-mode]'); if (target) open(target.getAttribute('data-mode')); });
  window.addEventListener('beforeunload', function (event) {
    if (state.exam && !state.exam.complete) { event.preventDefault(); event.returnValue = ''; }
  });
  window.openLessonPractice = function (lessonId) {
    var id = Number(lessonId);
    if (!Number.isSafeInteger(id) || id <= 0) return;
    if (window.switchView) window.switchView('practice');
    var ready = state.loading || state.error ? loadQuestions() : Promise.resolve();
    ready.then(function () {
      var list = state.questions.filter(function (q) { return Number(q.lessonId) === id; });
      if (list.length) startPractice(list, '课后练习');
      else { home(); state.error = '本课时暂时没有可用练习题'; render(); }
    });
  };
  window.switchPractice = open;
  window.PracticeStudio = {
    hasLesson: function (id) { return state.lessonIds.indexOf(Number(id)) >= 0; },
    open: open,
    refresh: function (mode) { open(mode || state.mode); return loadQuestions(); }
  };
  if (provinceField) provinceField.addEventListener('change', function () { changeProvince(provinceField.value); });
  loadQuestions(); refreshStats();
})();
